import Data.List
import Data.Maybe

data Tree a = Leaf a | Node (Tree a) (Tree a) deriving Show

unfoldTree :: (s -> Either a (s, s)) -> s -> Tree a
unfoldTree next x = case next x of
    Left y       -> Leaf y
    Right (l, r) -> Node (unfoldTree next l) (unfoldTree next r)

iterate :: (a -> a) -> a -> [a]
iterate f x = unfoldr g x
    where g y = Just (f y, f y)

map :: (a -> b) -> [a] -> [b]
map f xs = unfoldr g xs
    where g (y:ys) = Just (f y, ys);
          g []     = Nothing

balanced :: Int -> Tree ()
balanced n = unfoldTree f n
    where f 0 = Left ();
          f n = Right (n-1, n-1)

sized :: Int -> Tree Int
sized n = unfoldTree f (Right n)
    where f (Left n) = Left n;
          f (Right 0) = Left 0;
          f (Right n) = Right (Right (n-1), Left n)
