{-
Implementation in which count returns the number of arguments.
-}

class C a where
    count :: a

    -- `post_increment` is like `count` but also keeps
    -- track of the number of arguments using the 
    -- first argument.
    post_increment :: Int -> a

instance C Int where
    count = 0
    post_increment i = i
    
instance C b => C (a -> b) where
    -- For `count` we get rid of the first argument by
    -- instantiating `post_increment` with 1.
    count _ = post_increment 1
    
    -- Increments the argument counter and discards
    -- the first argument (just like the old `count`).
    post_increment i _ = post_increment (i+1)

test :: [Int]
test = [count, count 1 2 3, count "" [True, False] id (+)]


