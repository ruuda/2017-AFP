{-
Implementation in which count always returns 0.
-}

class C a where
    count :: a

instance C Int where
    count = 0

{-
The trick is in the following instance declaration. We define count recursively, like:
    count :: a -> Int
    count :: b -> (a -> Int)
    count :: c -> (b -> (a -> Int))
    ...
Note that in the following definition, the type variable `a` is free. Given an instance `C b`, we define count for `a -> b` by simply discarding whatever value of type `a` is given and return `count :: b`, which is defined by using recursion.
-}
instance C b => C (a -> b) where
    count _ = count

{-
The type declaration for test here is essential. Without it, type inference fails because the return type is not known. E.g.:
    *Main> :type count
    count :: C a => a
    *Main> :type count 'x'
    count 'x' :: C a => a
Forcing the type `a` in these examples to be `Int` solves the type ambiguity.
-}
test :: [Int]
test = [count, count 1 2 3, count "" [True, False] id (+)]


