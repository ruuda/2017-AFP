module SmoothPerms (smooth_perms) where

-- This data structure stores the permutations. To find permutations, start
-- at the root. Each edge corresponds to the next element that can be added
-- to the permutation. Actual elements are stored in the edges.
data Tree a = Leaf | Node [(a, Tree a)] deriving (Show, Eq)

-- Build a permutation tree for the given list.
build :: Eq a => [a] -> Tree a
build [] = Leaf
build xs = Node [(x, build [y | y <- xs, y /= x]) | x <- xs]

-- Prune the tree, i.e. remove edges if they can not be part of a smooth
-- permutation path. This does two things actually:
--  1. If an edge e1 is followed by an edge e2 and the distance of e1 and
--     e2 is too large, then the tree starting at e2 is removed.
--  2. If e is an edge for which all child edges are removed, then e is
--     removed as well.
prune :: (Num a, Ord a) => a -> Tree a -> Tree a
prune n Leaf      = Leaf
prune n (Node es) = Node (nonEmpty es)
    where nonEmpty es = [(ci, pruneWithParent cv ci)
                        | (ci, cv) <- es
                        , pruneWithParent cv ci /= Node []];
          pruneWithParent (Node es) i = Node (nonEmpty [(ci, cv)
                                        | (ci, cv) <- es
                                        , distance i ci <= n]);
          pruneWithParent  Leaf _     = Leaf

-- The usual distance function.
distance :: Num a => a -> a -> a
distance a b = abs(a-b)

-- Traverse the tree from root to leafs in all possible ways and output
-- all paths.
perms :: Tree a -> [[a]]
perms Leaf      = [[]]
perms (Node es) = [i : p | (i, v) <- es, p <- perms v]

-- Generate smooth permutations by building a permutation tree, pruning
-- it, and finally generating all permutations based on that tree.
smooth_perms :: (Num a, Ord a) => a -> [a] -> [[a]]
smooth_perms n = perms . prune n . build
