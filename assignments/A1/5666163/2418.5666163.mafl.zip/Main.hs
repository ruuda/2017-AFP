{-# LANGUAGE GeneralizedNewtypeDeriving #-} -- For deriving Num instance later on

module AFPAssignmentSet1 where

import Prelude hiding (map, iterate)
import Data.List (unfoldr)
import qualified Data.Tree as T

main :: IO ()
main = undefined

--------------------------------------------------------------------------------
-- Assignment 2.2.2 | Tree unfold

data Tree a
 = Leaf a
 | Node (Tree a) (Tree a)
 deriving Eq

instance Functor Tree where
 f `fmap` (Leaf x) = Leaf (f x)
 f `fmap` (Node l r) = Node (f `fmap` l) (f `fmap` r)

instance Show a => Show (Tree a) where
  show t = let convert (Leaf x) = T.Node (show x) []
               convert (Node l r) = T.Node "+" [convert l, convert r]
               in T.drawTree $ convert t

unfoldTree :: (s -> Either a (s, s)) -> s -> Tree a
unfoldTree next x =
  case next x of
    Left y       -> Leaf y
    Right (l, r) -> Node (unfoldTree next l) (unfoldTree next r)

iterate :: (a -> a) -> a -> [a]
iterate f = unfoldr (\x -> return (x, f x))

map :: (a -> b) -> [a] -> [b]
map f = unfoldr (\xs ->
  case xs of
    []     -> Nothing
    (y:ys) -> Just (f y, ys))

balanced :: Int -> Tree ()
balanced i = unfoldTree (\s ->
  case () of
    _ | s == i    -> Left ()
      | otherwise -> Right (succ s, succ s)) 0

sized :: Int -> Tree Int
sized i = unfoldTree (\(s, l) ->
  case () of
    _ | s == i    -> Left l
      | otherwise -> Right ((i, l), (s + 1, l + 1))) (0, 0)

--------------------------------------------------------------------------------
-- Assignment 2.2.5 | Type Hiding

-- | Int wrapper for making the first test evaluate to [0, 0, 0],
-- the GeneralizedNewtypeDeriving language extension is required to derive Num
newtype SpecialInt = SpecialInt { unSpecialInt :: Int }
  deriving (Eq, Ord, Num)

instance Show SpecialInt where
  show = show . unSpecialInt

class Countable a where
  count :: a
  more  :: a -> a

-- The base case for countable integers
instance Countable Int where
  count = 0
  more  = (+1)

instance Countable SpecialInt where
  count = 0
  more  = (+0)

-- | A `recursive` case for functions
instance Countable b => Countable (a -> b) where
  count   = const (more count)
  more f  = more . f

-- Evaluates to [0, 0, 0]
test0 :: [SpecialInt]
test0 =
  [ count
  , count 1 2 3
  , count "" [True, False] id (+)
  ]

-- Evaluates to [0, 3, 4]
test1 :: [Int]
test1 =
  [ count
  , count 1 2 3
  , count "" [True, False] id (+)
  ]

--------------------------------------------------------------------------------
-- Assignment 2.7.1 | Algorithm design
-- ... See other file


--------------------------------------------------------------------------------
-- Assignment 2.9.1 | Proofs

{-
*** Proof for the lemma on lengths of concatenated lists ***

forall (xs : [a]) (ys : [a]) . length (xs ++ ys) = length xs + length ys

case xs = []
  length ([] ++ ys) = length [] + length ys

  by the definition of length:
    length [] = 0

  by the definition of (++)
    [] ++ ys = ys

  length ys = 0 + length ys

  0 is the neutral element in the sum monoid

  x + 0 = x

  conclusion:
    length ys = length ys

case xs = (x:xs)
  IH: length (xs ++ ys) = length xs + length ys

  length ((x:xs) ++ ys) = length (x:xs) + length ys

  by the definition of length
    length (x:xs) = 1 + length xs

  by the definition of (++)
    (x:xs) ++ ys = x : (xs ++ ys)

  1 + length ((xs ++ ys)) = 1 + length xs + length ys

  reduce 1 on both sides:
    length (xs ++ ys) = length xs + ys

  Theorem proven by the IH

*** Proof on trees ***

forall (x : a) . length (flatten (Leaf x)) = size (Leaf x)

  1) by the definition of flatten
    flatten (Leaf x) = [x]

  length [x] = size (Leaf x)

  2) by the definitin of size:
    size (Leaf _) = 1

  length [x] = 1

  3) by the definition of length
    length (x:xs) = 1 + length xs

  4) x was the singleton list, therefore xs is []. By the definition of length
    length [] = 0

  5) 0 is the neutral element of the sum monoid
    length (x:[]) = 1 + 0 = 1

  6) observe that the value of this expression logically evaluates to the same
  value as step (2), the two expressions therefore have to be equal.

forall (l' : Tree a) (r : Tree a) .
     length (flatten l) = size l
  && length (flatten r) = size r
  ==> length (flatten (Node l' r)) = size (Node l' r)

case l = Leaf a
  H1: length (flatten (Leaf a)) = size (Leaf a)
  H2: length (flatten r) = size r

  prove: length (flatten (Node (Leaf a) r)) = size (Node (Leaf a) r)

  1) by the definition of flatten
    length (flatten (Leaf a) ++ flatten r) = size (Node (Leaf a) r)
    length ([a] ++ flatten r) = size (Node (Leaf a) r)

  2) by the definition of (++)
    length ( a : ([] ++ flatten r)) = size (Node (Leaf a) r)
    length ( a : (flatten r)) = size (Node (Leaf a) r)

  3) by the definition of length
    1 + length (flatten r) = size (Node (Leaf a) r)

  4) definition of size
    1 + length (flatten r) = size (Leaf a) + size r
    1 + length (flatten r) = 1 + size r

  5) eliminate 1 on both sides
    length (flatten r) = size r

  Theorem proven by H2.

case l = Node q w
  H1: length (flatten (Node q w)) = size (Node q w)
  H2: length (flatten r) = size r

  prove: length (flatten (Node (Node q w) r)) = size (Node (Node q w) r)

  1) by the definition of flatten
    length (flatten (Node q w) ++ flatten r) = size (Node (Node q w) r)

  2) by the lemma on list lengths (first proof)
    length (flatten (Node q w)) + length (flatten r) = size (Node (Node q w) r)

    where xs = flatten (Node q w)
          ys = flatten r

  3) by H2
    length (flatten (Node q w)) + size r = size (Node (Node q w) r)

  4) by the definition of size
    length (flatten (Node q w)) + size r = size (Node q w) + size r

  5) remove (size r) from both sides
    length (flatten (Node q w)) = size (Node q w)

  Theorem proven by H1.
-
-}

