module SmoothPermutations
  ( Rose (..)
  , paths
  , prune
  , smooth_perms
  , toTree
  ) where

import qualified Data.Tree as T

data Rose a
  = a :> [Rose a]
  | Init [Rose a] -- for the first node, it holds only children
  deriving Eq

value (v :> _) = v

-- | Nice show instance stolen from Data.Tree
instance Show a => Show (Rose a) where
  show rose = let convert (n :> cs) = T.Node (show n) (convert <$> cs)
                  convert (Init cs) = T.Node "+" (convert <$> cs)
              in T.drawTree (convert rose)

-- | Generate the smooth permutations via transformation to a permutation tree.
-- Sometimes the result is not equal to the smooth_perms from the exercise but
-- these always happen when there are no results left. [] or [[]] collision, so
-- to say
smooth_perms :: Int -> [Int] -> [[Int]]
smooth_perms n xs =
  paths . prune (length xs) . toTree n $ xs

-- | Flatten a permutationtree to a list of lists, the resulting list of lists
-- is _not sorted_.
paths :: Rose a -> [[a]]
paths (Init []) = [[]]
paths (Init cs) = concat (paths <$> cs)
paths (v :> []) = [[v]]
paths (v :> cs) = concatMap ((v:) <$>) (paths <$> cs)

-- | Prune branches in the tree that do not have at least one child that go down
-- to the bottom. The init excludes top-level branches without children
-- that go down to the bottom from the second rule of the helper function.
prune :: BranchDepth -> Rose Int -> Rose Int
prune d' = prune' d' . labelTree
  where
    prune' d (Init xs) =
      Init . fmap (prune' d) . filter (\(v :> _) -> snd v == d) $ xs
    prune' d (v :> cs) =
      fst v :> (fmap (prune' (pred d)) . filter (\(r :> _) -> snd r == (pred d)) $ cs)

type BranchDepth = Int

-- | Label all the nodes in the tree with a depth marker, starting at 1 for
-- leaves. The value boils up to the top of the tree so that the branches at the
-- top, that do not have the required depth, can be easily pruned
labelTree :: Rose a -> Rose (a, Int)
labelTree (Init xs) = Init $ map labelTree' xs
  where
    labelTree' (v :> []) = (v, 1) :> []
    labelTree' (v :> cs) =
      let subtrees = labelTree' <$> cs
          maxDepth = maximum (map (snd . value) subtrees)
      in (v, maxDepth+1) :> subtrees

-- | Build a tree that represents possible permutations of an input list by
-- following a path to a leaf. Branches that are _not `smooth`_ are not built.
toTree :: Int -> [Int] -> Rose Int
toTree n =
  let -- | For each element in the list, pick that element as the first element
      -- and tuple it with the rest of the list.
      heads g xs = let f xs m = let (ys, (z:zs)) = splitAt m xs
                                in (z, ys ++ zs)
                   in filter (\(q, _) -> g q) $ fmap (f xs) [0 .. length xs - 1]

      -- Map each of the elements of the remaining list to a Node with the
      -- children as a node. The first pass accepts all elements as a first
      -- choice, but after the first pass only `smooth` elements are considered
      toTree' f = let isSmooth n x y = abs (x - y) <= n
                  in fmap (\(v, cs) -> v :> toTree' (isSmooth n v) cs) . heads f
  in Init . toTree' (const True)

