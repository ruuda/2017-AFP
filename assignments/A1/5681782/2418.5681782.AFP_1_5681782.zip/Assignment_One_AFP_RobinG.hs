module Assignment_One_AFP_RobinG where

import Prelude hiding (iterate, map, count)

data Tree a =     Leaf a
                | Node (Tree a) (Tree a)
    deriving Show

    
setup :: IO ()
setup = putStrLn "hi"
    
unfoldr :: (s -> Maybe (a,s)) -> s -> [a]
unfoldr next x = case next x of
                    Nothing     ->  []
                    Just (y,r)  ->  y : unfoldr next r
    
unfoldTree :: (s -> Either a (s,s)) -> s -> Tree a
unfoldTree next x =
    case next x of
        Left y          -> Leaf y
        Right (l, r)    -> Node (unfoldTree next l) (unfoldTree next r)
        

-- | Exercise 2.2.2

-- | iterate using unfoldr.
iterate :: (a -> a) -> a -> [a]
iterate f x = unfoldr (helper f) x
    where
        helper :: (a -> a) -> (a -> Maybe (a,a))
        helper f = \x -> Just (f x, f x)

testIterate :: [Int]
testIterate = iterate (+ 1) 0

-- | map using unfoldr.
-- # LANGUAGE Scopetype variables # <- Google
map :: (a -> b) -> [a] -> [b]
map f xs = unfoldr helper xs
    where
--        helper :: [a] -> Maybe (b,[a])
        helper []       = Nothing
        helper (x:xs')  = Just (f x, xs')

testMap :: [Int]
testMap = map (+ 1) [0,1,2,3]

-- | balanced using unfoldTree.
balanced :: Int -> Tree ()
balanced h = unfoldTree helper h
    where
        helper :: Int -> Either () (Int, Int)
        helper 0 = Left ()
        helper x = Right (x-1, x-1)
        
-- | sized using unfoldTree.
sized :: Int -> Tree Int
sized s = unfoldTree helper (s, 0)
    where
        helper :: (Int, Int) -> Either Int ((Int, Int), (Int, Int))
        helper (0,uid) = Left uid
        helper (x, uid) = Right ((x - 1, uid + x + 2), (0, uid + x + 1))
        
        
-- | Exercise 2.2.5

class CountAllType t where
    countAll :: [Int] -> t

{- | Before refinement (always use 0's).

instance CountAllType Int where
    countAll acc = 0  
    
-}

-- | After refinement (includes parameter length).
instance CountAllType Int where
    countAll acc = length acc
    
instance CountAllType r => CountAllType (a -> r) where
    countAll acc = \x -> countAll $ length acc : acc
    
count :: (CountAllType t) => t
count = countAll []

testCount :: [Int]
testCount = [count, count 1 2 3, count "" [True, False] id (+)]

-- | Exercise 2.7.1
data PruneTree = Root [PruneBranch]
    deriving Show

data PruneBranch =  PruneLeaf Int
                 |  PruneNode Int [PruneBranch]
    deriving Show
                 
                 
split [] = []
split (x:xs) = (x, xs) : [(y,x:ys) | (y,ys) <- split xs]

--perms [] = [[]]
--perms xs = [(v:p) | (v,vs) <- split id xs, p <- perms vs]

mapToTree :: [Int] -> PruneTree
mapToTree [] = Root []
mapToTree xs = Root $ mapToBranches xs 0

mapToBranches :: [Int] -> Int -> [PruneBranch]
mapToBranches (x:[]) 0 = [PruneLeaf x]
mapToBranches [] _ = [] 
mapToBranches (x:xs) n = [PruneNode x (mapToBranches xs 0)] ++ (mapToBranches (if length xs == n then [] else xs ++ [x]) newN)
    where
        newN = n + 1

pruneTree :: Int -> PruneTree -> PruneTree
pruneTree _ (Root []) = Root []
pruneTree n (Root xs) = Root $ (map (\x -> pruneBranches n x) xs)

pruneBranches :: Int -> PruneBranch -> PruneBranch
pruneBranches _ (PruneLeaf x) = PruneLeaf x
pruneBranches n (PruneNode x xs) = PruneNode x (map (\y -> pruneBranches n y) (filter (\y -> suffices y x) xs))
    where
        suffices (PruneLeaf x) p = abs (p - x) <= n
        suffices (PruneNode x _) p = abs (p - x) <= n
        
getPermsPerBranch :: PruneBranch -> [[Int]]
getPermsPerBranch (PruneLeaf x) = [[x]]
getPermsPerBranch (PruneNode x xs) = concat $ map (\y -> map (\z -> x : z) (getPermsPerBranch y)) xs

getPerms :: PruneTree -> [[Int]]
getPerms (Root xs) = filter (\x -> length x == originalLength) $ concat (map getPermsPerBranch xs)
    where
        originalLength = length xs

smooth_perms :: Int -> [Int] -> [[Int]]
smooth_perms n xs = getPerms $ pruneTree n (mapToTree xs)
        
testMapToTree :: PruneTree
testMapToTree = mapToTree [1,2,3]


testPruneTree :: PruneTree
testPruneTree = pruneTree 1 testMapToTree

pTest = PruneNode 1 [PruneNode 2 [PruneLeaf 3],PruneNode 3 [PruneLeaf 2]]

                    