import Assignment_One_AFP_RobinG
main = setup