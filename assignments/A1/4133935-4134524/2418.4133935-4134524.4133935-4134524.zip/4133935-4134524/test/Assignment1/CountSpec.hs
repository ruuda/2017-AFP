module Assignment1.CountSpec where

import Test.Hspec
import Assignment1.Count

spec :: Spec
spec = do
  it "discards all arguments" $ do
    countZero `shouldBe` (0::Int)
    countZero 'a' `shouldBe` (0::Int)
    countZero 'a' "wouter" `shouldBe` (0::Int)
    countZero "arian" "tim" 'a' `shouldBe` (0::Int)
  it "counts the amount of arguments" $ do
    count `shouldBe` (0::Int)
    count 'a' `shouldBe` (1::Int)
    count 'a' "wouter" `shouldBe` (2::Int)
    count "arian" "tim" 'a' `shouldBe` (3::Int)
  it "counts the example list correctly" $
    let
      -- lets force plus to be monomorphic,
      -- or GHC defaults to Integer, which is perhaps what we want
      -- but -Wall complains about defaulting behaviour being unexpected
      plus :: Int -> Int -> Int
      plus = (+)
    in do
      [count, count (1::Int) (2::Int) (3::Int), count "" [True, False] id plus] `shouldBe` ([0, 3, 4] :: [Int])
      [countZero, countZero (1::Int) (2::Int) (3::Int), countZero "" [True, False] id plus] `shouldBe` ([0, 0, 0] :: [Int])
