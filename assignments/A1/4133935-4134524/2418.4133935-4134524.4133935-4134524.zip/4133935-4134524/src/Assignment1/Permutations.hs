-- |Our solution to Exercise 2.7.1.
module Assignment1.Permutations where

-- *The reference implementation
-- As specified in the exercise, you could generate smooth permutations
-- by generating all permutations and filtering out the smooth ones.
-- This is very expensive, O(k!) in every case (where k is the length of the
-- list to be permuted), which can be reduced to something like O(k^n).

-- |Gives every way to split one element from the list.
-- Returns a pair of the removed element and the list without only that element.
split :: [a] -> [(a, [a])]
split [] = []
split (x:xs) = (x, xs):[(y, x:ys) | (y, ys) <- split xs]

-- |Is the given permutation smooth?
-- A permutation is smooth when all difference between succesive elements are
-- smaller than the specified parameter 'n'.
smooth :: Int -> [Int] -> Bool
smooth n (x:y:ys) = abs (y-x) <= n && smooth n (y:ys)
smooth _ _ = True

-- |Calculate all permutations of the given list.
perms :: [a] -> [[a]]
perms [] = [[]]
perms xs = [v:p | (v, vs) <- split xs, p <- perms vs]

-- |Give all smooth permutations of the list by discarding non-smooth ones.
-- This is the reference implementation that we want to improve on.
smoothPerms :: Int -> [Int] -> [[Int]]
smoothPerms n xs = filter (smooth n) (perms xs)

-- *Our own implementation
-- The problem with the reference implementation is that it performs the
-- same filtering checks repeatedly on the "same" problem.
-- When you know |x - y| > n, you may discard all permutations x:y:ys.
-- We use a tree structure to group permutations starting with the same elements
-- and prune this tree to find the smooth permutations efficiently.

-- |A rose tree, where each node has an arbitrary number of children.
-- A leaf is just a node with an empty list of children.
data Rose a = a :> RoseForest a deriving Show
-- |A rose tree where the root node has no data.
-- Alternatively, a rose tree where the edges have a label instead of the nodes.
-- (But the type [(a, RoseForest a)] has less useful functions to work with.)
type RoseForest a = [Rose a]

-- |Generate the tree representation of all permutations of a list.
-- A node at depth i specifies the permutation element at index i,
-- so all paths through this forest are exactly the permutations of the list.
-- Comparing this code with 'perms', the main difference is that we group
-- all permutations given an initial element into one node instead of
-- splitting them over the full list.
permsTree :: [a] -> RoseForest a
permsTree [] = []
permsTree (x:xs) = [v :> permsTree vs | (v,vs) <- split (x:xs)]

-- |List all paths of nodes reached when walking from the root to a leaf.
paths :: Rose a -> [[a]]
paths (x :> []) = [[x]] -- Special case: there is exactly one path in a leaf.
paths (x :> xs) = [x:ps | ps <- concatMap paths xs]

-- |List all paths of edges reached when walking from the root to a leaf.
forestPaths :: RoseForest a -> [[a]]
forestPaths = concatMap paths

-- |Use a RoseForest to generate all permutations of the given list.
-- This function should be exactly equivalent to the perms function above.
perms' :: [a] -> [[a]]
perms' [] = [[]]
perms' xs = forestPaths . permsTree $ xs

-- |List all paths of the given length over the edges.
-- This is useful when we start pruning, because simply calling forestPaths
-- on a pruned tree will also give paths that ended prematurely.
-- Alternatively, we could change the node data into either (Node a (Rose a))
-- or (DeadEnd) and discard paths that end in a DeadEnd.
-- This second option makes a pruning function more difficult to write.
fullPaths :: Int -> RoseForest a -> [[a]]
fullPaths len = filter (\path -> length path == len) . forestPaths

-- |Prune a rose tree (or forest) of permutations so all paths will be smooth.
-- Since successive nodes represent succesive elements of the permutation,
-- we can simply discard the children of a node whenever the difference
-- between the node's value and the child's value is too big.
prune :: Int -> Rose Int -> Rose Int
prune _ (x :> []) = x :> []
prune n (x :> xs) = x :> filter locallySmooth (map (prune n) xs)
  where
    -- A permutation is smooth when it is everywherelocally smooth:
    -- no big jumps between two adjacent children.
    -- This property is conserved when we look at the tree instead of paths.
    locallySmooth (y:>_) = abs (y-x) <= n

-- |Generate all smooth permutations of a list using a forest and pruning it.
-- This should be a faster equivalent of 'smoothPerms'.
smoothPerms' :: Int -> [Int] -> [[Int]]
smoothPerms' _ [] = [[]]
smoothPerms' n xs = fullPaths (length xs) $ map (prune n) $ permsTree xs
