# Inlevers

All the inleveropgaven of Arian (4133935) and Tim (4134524). See `src/Assignment1` for the code solutions to the first assignment, and `doc/Assignment1` for the non-code solutions to the first assignment.

* 2.1.1 (20%) - Cabal
  See [./inlevers.cabal](./inlevers.cabal)
* 2.2.2 (20%) - Unfold
  See [./src/Assignment1/Unfold.hs](./src/Assignment1/Unfold.hs)
  and [./test/Assignment1/UnfoldSpec.hs](./test/Assignment1/UnfoldSpec.hs)
* 2.2.5 (15%) - Count
  See [./src/Assignment1/Count.hs](./src/Assignment1/Count.hs)
  and [./test/Assignment1/CountSpec.hs](./test/Assignment1/CountSpec.hs)
* 2.7.1 (20%) - Permutations
  See [./src/Assignment1/Permutations.hs](./src/Assignment1/Permutations.hs)
  and [./test/Assignment1/PermutationsSpec.hs](./test/Assignment1/PermutationsSpec.hs)
* 2.9.1 (25%) - Proofs
  See [./doc/Reasoning.pdf](./doc/Reasoning.pdf) for Equational Reasonsing proof.
  See [./doc/Reasoning.tex](./doc/Reasoning.tex) for the LaTeX source files of this proof.
  See [./src/Assignment1/Reasoning.idr](./src/Assignment1/Reasoning.idr) for the Equational Reasoning
  proof implemented in the proof-assistent Idris.

# Setup

```
stack setup
stack build
stack test # run all the unit tests
```




