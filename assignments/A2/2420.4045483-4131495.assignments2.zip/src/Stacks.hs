module Stacks (
    start,
    store,
    add,
    mul,
    stop,
    start',
    store',
    add',
    mul',
    stop'
) where

-- version with rejection on runtime

data Stack a = Stack [a]

start :: (Stack a -> f) -> f
start function = function (Stack [])

store :: Stack a -> a -> (Stack a -> f) -> f
store (Stack xs) x function = function (Stack (x:xs))

fun :: (a -> a -> a) -> Stack a -> (Stack a -> f) -> f
fun operation (Stack (x:y:xs)) function = function (Stack (operation x y : xs))

add, mul :: Num a => Stack a -> (Stack a -> f) -> f
add = fun (+)
mul = fun (*)

stop :: Stack a -> a
stop (Stack (x:xs)) = x

-- version with rejection on compiletime

data StackR a b = End | Recursive a b

start' :: (StackR a Int -> f) -> f
start' function = function End

store' :: StackR a b -> a -> (StackR a (StackR a b) -> f) -> f
store' sr x function = function (Recursive x sr)

fun' :: (a -> a -> a) -> StackR a (StackR a (StackR a b)) -> (StackR a (StackR a b) -> f) -> f
fun' operation (Recursive x (Recursive y sr)) function = function (Recursive (operation x y) sr)

add', mul' :: Num a => StackR a (StackR a (StackR a b)) -> (StackR a (StackR a b) -> f) -> f
add' = fun' (+)
mul' = fun' (*)

stop' :: StackR a (StackR a b) -> a
stop' (Recursive x _) = x
