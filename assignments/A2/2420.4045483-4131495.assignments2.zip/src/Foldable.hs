module Foldable where

import Prelude hiding (Foldable, foldMap)
import Data.Monoid

data Rose a = a :> [Rose a]

class Functor f => Foldable f where
    fold :: Monoid m => f m -> m

    -- 3.3.4
    foldMap :: Monoid m => (a -> m) -> f a -> m
    foldMap f container = fold $ fmap f container

-- 3.3.3
instance Functor Rose where
    fmap f (x :> roses) = f x :> map (fmap f) roses

instance Foldable Rose where
    --fold :: (a -> b -> b) -> b -> Rose a -> b
    fold (x :> roses) = x <> mconcat (map fold roses)

-- 3.3.5
fsum, fproduct :: (Foldable f, Num a) => f a -> a
fsum = getSum . foldMap Sum
fproduct = getProduct . foldMap Product
