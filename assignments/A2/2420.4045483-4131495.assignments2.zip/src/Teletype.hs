module Teletype where

data GP a = End a
          | Get (Int->GP a)
          | Put Int (GP a)

echo :: GP a
echo = Get (`Put` echo)

run :: GP a -> IO a
run (End x) = return x
run (Get f) = (f <$> readLn) >>= run
run (Put x gp) = print x >>= const (run gp)
