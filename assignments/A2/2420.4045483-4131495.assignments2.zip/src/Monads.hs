{-# LANGUAGE MultiParamTypeClasses, FlexibleInstances, FunctionalDependencies #-}

module Monads (
    StateMonadPlus(..),
    modify,
    increment,
    runStateMonadPlus,
    fail,
    diagnostics,
    annotate
) where

import Prelude hiding (fail, print)

import Data.List

import Control.Applicative
import Control.Monad.State hiding (fail)
import Control.Monad.Except hiding (fail)
import Control.Monad.Identity hiding (fail)

import qualified Data.Map.Strict as Map

-- StateMonadPlus uses the State and Except monad transformers under the hood
type StateExcept s = StateT s (ExceptT String Identity)
data StateMonadPlus s a = StateMonadPlus {
    getStateMonadPlusInner :: StateExcept (s, Map.Map String Int, [s]) a
}

-- Instances
instance Functor (StateMonadPlus s) where
    fmap = liftM

instance Applicative (StateMonadPlus s) where
    pure = return
    (<*>) = ap

instance Monad (StateMonadPlus s) where
    -- return :: a -> StateMonadPlus s a
    return x = StateMonadPlus $ modify (increment "return") >>= const (return x)

    -- (>>=) :: StateMonadPlus s a -> (a -> StateMonadPlus s b) -> StateMonadPlus s b
    (StateMonadPlus f) >>= g = StateMonadPlus $ do
                                x <- f
                                modify (increment "bind")
                                getStateMonadPlusInner (g x)

instance MonadState s (StateMonadPlus s) where
    get = StateMonadPlus $ fmap (\(s, _, _) -> s) get
    put s = StateMonadPlus $ modify (\(_, d, h) -> (s, d, h))

class MonadState s m => StoreState s m | m -> s where
    saveState :: m ()
    loadState :: m ()

instance StoreState s (StateMonadPlus s) where
    saveState = StateMonadPlus $ modify (\(s, d, hs) -> (s, d, s : hs))
    loadState = StateMonadPlus $ do
                    (_, d, hs) <- get
                    case hs of
                        [] -> throwError "Attempted to pop empty stack"
                        h : hs' -> put (h, d, hs')

-- We get fail for free thanks to the ExceptT transformer
fail :: String -> StateMonadPlus s a
fail = StateMonadPlus . throwError

runStateMonadPlus :: StateMonadPlus s a -> s -> Either String (a, s)
runStateMonadPlus (StateMonadPlus smp) seed = let result = runExcept $ runStateT smp (seed, Map.empty, [])
                                                  f (a, (s, _, _)) = (a, s)
                                              in f <$> result

-- Diagnostics
diagnostics :: StateMonadPlus s String
diagnostics = StateMonadPlus $ do
    modify $ increment "diagnostics"
    (_, d, _) <- get
    return $ format d

format :: Map.Map String Int -> String
format m = "[" ++ intercalate ", " (map (\(k,v) -> k ++ "=" ++ show v ) (Map.toList m)) ++ "]"

annotate :: String -> StateMonadPlus s a -> StateMonadPlus s a
annotate msg (StateMonadPlus f) = StateMonadPlus $ do
    x <- f
    modify $ increment msg
    return x

increment :: String -> (a, Map.Map String Int, b) -> (a, Map.Map String Int, b)
increment key (a, map, b) = (a, Map.insertWith (+) key 1 map, b)

{-

- Exercise 2.3.1. Do the monad laws hold for StateMonadPlus? Explain your answer.

StateMonadPlus is NOT a monad. The three Monad laws are the following

1. Left identity: return a >>= f ≡ f a
2. Right identity: m >>= return ≡ m
3. Associativity: (m >>= f) >>= g ≡ m >>= (\x -> f x >>= g)

Below we show that the first of these properties does not hold. Consider the
following definitions:

f :: a -> StateMonadPlus s a
f = return -- any function from a to StateMonadPlus is possible

Now we can show that the law doesn't hold, by working out the right hand side of
the equation:

-------------------------------------------------------------------------------
(return x) >>= f = StateMonadPlus $ do
                                x <- return x
                                modify (increment "bind")
                                getStateMonadPlusInner (f x)
-------------------------------------------------------------------------------
(return x) >>= return = StateMonadPlus $ do
                                x <- return x
                                modify (increment "bind")
                                getStateMonadPlusInner (return x)
-------------------------------------------------------------------------------
(return x) >>= return = StateMonadPlus $   modify (increment "return") >>= const (return x)
                                       >>= modify (increment "bind")
                                       >>= modify (increment "return") >>= const (return x)
-------------------------------------------------------------------------------
(return x) >>= return = StateMonadPlus $   modify (increment "return")
                                       >>= modify (increment "bind")
                                       >>= modify (increment "return") >>= const (return x)

Whereas return is defined as follows:

return x = StateMonadPlus $ modify (increment "return")
                          >>= const (return x)

They are clearly not the same. From this we conclude that our datastructure is not a monadic datatype.

- Exercise 2.3.2. What are the advantages of hiding (constructor) functions? How important
is this for each of the three additional features supported by StateMonadPlus?

Hiding constructor functions is important to avoid leaking implementation details. This
has many benefits. For instance, it disallows a user from messing with the internal
state of the monad, which could lead to unexpected errors. On the side of maintainability,
hiding constructor functions allows changing them in the future without causing breakage
in client code.

- Exercise 2.3.3. What are the modifications required to make a monad transformer for
StateMonadPlus?

We would need to define:

1. A data type for the monad transformer
2. A type class for the monad transformer
3. Lots of instances of said type class to tell the compiler how it interacts
with other monad transformers

- Exercise 2.3.4. Suppose that we want to write a function
diagnosticsFuture :: StateMonadPlus s String
which provides information about the computations in StateMonadPlus that are still to
come. Explain how this would affect your code. If you feel that such a facility cannot be
implemented, then you should give some arguments for your opinion. If you believe it
can be done, then try to do so.

When we would execute a bind, f >>= g, it is possible to give information about the function g to the function f.
This way f could know what is yet to come, a bit of pseudo-code:
f@(SomeMonad c) >>= g = SomeMonad $ do
                                f (getSomeMonadFuture g)
                                x <- f
                                getSomeMonadInner (g x)

-}
