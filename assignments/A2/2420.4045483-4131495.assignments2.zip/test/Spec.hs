import Prelude hiding (Foldable, foldMap, foldMap)
import Data.Monoid

import Test.QuickCheck
import Foldable
import Monads
import Stacks

main :: IO ()
main = do
    quickCheck foldMapRoseWorks
    quickCheck fsumWorks
    quickCheck fproductWorks

    quickCheck monadSimpleWorks
    quickCheck monadExample1Works
    quickCheck monadExample2Works

    quickCheck stackP1Works
    quickCheck stackP2Works
    -- quickCheck stackP3Works
    quickCheck stackP1Works'
    quickCheck stackP2Works'
    -- quickCheck stackP3Works'

-- Tests for Foldable
rose42 :: Rose Int
rose42 = 5 :> [3 :> [], 8 :> [26 :> []]]

foldMapRoseWorks, fsumWorks, fproductWorks :: Bool
foldMapRoseWorks = getSum (foldMap Sum rose42) == 42
fsumWorks = fsum rose42 == 42
fproductWorks = fproduct rose42 == 3120

-- Tests for Monads
monadSimpleWorks = case runStateMonadPlus simple () of
                        Left s -> s == simpleAns
                        Right (s, _) -> s == simpleAns

simpleAns = "[bind=1, diagnostics=1, return=1]"
simple :: StateMonadPlus () String
simple = do return 5
            diagnostics

monadExample1Works = case runStateMonadPlus example1 () of
                        Left s -> s == example1Ans
                        Right (s, _) -> s == example1Ans
example1Ans = "[bind=3, diagnostics=1, return=3]"
example1 :: StateMonadPlus () String
example1 = do return 3 >> return 4
              return 5
              diagnostics

monadExample2Works = case runStateMonadPlus example2 () of
                        Left s -> s == example2Ans
                        Right (s, _) -> s == example2Ans
example2Ans = "[A=1, bind=3, diagnostics=1, return=3]"
example2 :: StateMonadPlus () String
example2 = do annotate "A" (return 3 >> return 4)
              return 5
              diagnostics

-- Tests for Stacks
stackP1Works, stackP2Works, stackP1Works', stackP2Works' :: Bool
stackP1Works = p1 == 8
stackP2Works = p2 == 15
stackP3Works = p3 == undefined
stackP1Works' = p1' == 8
stackP2Works' = p2' == 15
-- stackP3Works' = p3' == undefined

p1,p2 :: Int
p1 = start store 3 store 5 add stop
p2 = start store 3 store 6 store 2 mul add stop

p3 :: Int
p3 = start store 3 add stop -- throws error on runtime

p1',p2' :: Int
p1' = start' store' 3 store' 5 add' stop'
p2' = start' store' 3 store' 6 store' 2 mul' add' stop'

-- p3' :: Int
-- p3' = start' store' 3 add' stop' -- throws error on compiletime
