Assignment 2
============

The following solutions have their own module in the `src` directory:

* Monads (2.3)
* Foldable (3.3.3, 3.3.4 and 3.3.5)
* Teletype IO (2.2.8)
* Stacks (2.2.9)
