{- Exercise 2.2.9, where p3 fails at runtime. -}

type Stack = [Int]

start :: (Stack -> a) -> a
start f = f []

store :: Stack -> Int -> (Stack -> a) -> a
store s i f = f (i:s)

add :: Stack -> (Stack -> a) -> a
add (x:y:s) f = f (x+y:s)

mul :: Stack -> (Stack -> a) -> a
mul (x:y:s) f = f (x*y:s)

stop :: Stack -> Int
stop (x:s) = x

p1, p2, p3 :: Int
p1 = start store 3 store 5 add stop
p2 = start store 3 store 6 store 2 mul add stop
p3 = start store 2 add stop
