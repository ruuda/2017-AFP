module TestMonadExercise where

import Control.Monad.State
import Test.HUnit
import MonadExercise

testExample1 :: Test
testExample1 = 
    TestCase $ assertEqual ""
                           (Right ("[bind=3, diagnostics=1, return=3]", 0))
                           (runStateMonadPlus c 0)
    where c = do return 3 >> return 4
                 return 5
                 diagnostics

testExample2 :: Test
testExample2 = 
    TestCase $ assertEqual ""
                          (Right ("[A=1, bind=3, diagnostics=1, return=3]", 0))
                           (runStateMonadPlus c 0)
    where c = do annotate "A" (return 3 >> return 4)
                 return 5
                 diagnostics

testExample3 :: Test
testExample3 = 
    TestCase $ assertEqual ""
                           (Right ((1, 2, 4, 2, 1), 1) )
                           (runStateMonadPlus c 1)
    where c = do i1 <- get; saveState
                 modify (*2)
                 i2 <- get; saveState
                 modify (*2)
                 i3 <- get; loadState
                 i4 <- get; loadState
                 i5 <- get
                 return (i1, i2, i3, i4, i5)



main :: IO Counts
main = runTestTT $ TestList [testExample1, testExample2, testExample3]