{- Exercise 2.2.8: Enumeration -}

-- Required for having multiple parameters in MonadState
{-# LANGUAGE MultiParamTypeClasses #-}

import Control.Applicative
import Control.Monad (ap)
import Control.Monad.State.Class

data GP a =
    End a
  | Get (Int -> GP a)
  | Put Int (GP a)

run (End x) = return x
run (Get f) = do
  x <- getLine
  run (f (read x))
run (Put n gp) = do
  print n
  run gp

echo :: GP a
echo = Get (\n -> Put n echo)

sumGP :: IO ()
sumGP = run $ Get (\x -> Get (\y -> putEnd (x+y)))

accum :: IO ()
accum = run $ accum' 0 where
  accum' acc = Get (\x -> if x == 0 then putEnd acc
    else let acc' = acc + x in
      Put acc' (accum' acc'))

-- Put the provided Int and stop
putEnd :: Int -> GP ()
putEnd = flip Put $ End ()

simulate :: GP a -> [Int] -> (a, [Int])
simulate (End x)     _      = (x,[])
simulate (Get f)     (y:ys) = simulate (f y) ys
simulate (Put x gp)  ys     = (a,x:xs) where
  (a,xs) = simulate gp ys

instance Functor GP where
  fmap f (End x) = End (f x)
  fmap f (Get g) = Get (fmap f . g)
  fmap f (Put n x) = Put n (fmap f x)

{- In new versions of Haskell, it is required to make a class instance of Applicative before
   it can be a Monad. This defintion implements Applicative by pointing to the Monad functions
   so they do not have to be written again. See:
   http://stackoverflow.com/questions/31652475/defining-a-new-monad-in-haskell-raises-no-instance-for-applicative -}
instance Applicative GP where
  pure = End
  (<*>) = ap

instance Monad GP where
  (End x) >>= f = f x
  (Get x) >>= f = Get (\v -> x v >>= f)
  (Put int x) >>= f = Put int (x >>= f)
  return = End

instance MonadState Int GP where
  get = Get End
  put state = Put state (End ())

{- Difference between MonadState GP and regular State:
A state monad is usually used together with a function that updates the state,
and returns a value in combination with the updated state. This MonadState
returns a value (End), not a new state.}
