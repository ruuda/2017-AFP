{- Exercise 2.2.9, a solution that rejects programs that 
   require non-existing stack elements during type checking -}

data Stack a = Elem Int a | Leaf

-- A type describing an empty stack.
type EmptyStack = Stack ()

-- A type describing a stack with at least one element.
-- The reason we use Stack two times is 
-- because one stack acts as the leaf.
type Stack1 a =  Stack (Stack a)

-- A type describing a stack with at least two elements.
type Stack2 a =  Stack (Stack1 a)

start :: (EmptyStack -> b) -> b
start f = f Leaf

store :: Stack a -> Int -> (Stack1 a -> b) -> b
store s i f = f (Elem i s)

-- General function for taking two elements on the stack and reduce them to one.
twoop :: (Int -> Int -> Int) -> Stack2 a -> (Stack1 a -> b) -> b 
twoop f (Elem x (Elem y s)) g = g (Elem (f x y) s)

add :: Stack2 a -> (Stack1 a -> b) -> b
add = twoop (+)

mul :: Stack2 a -> (Stack1 a -> b) -> b
mul = twoop (*)

stop :: (Stack a) -> Int
stop (Elem x _) = x

p1, p2 :: Int
p1 = start store 3 store 5 add stop
p2 = start store 3 store 6 store 2 mul add stop
--p3 = start store 2 add stop
