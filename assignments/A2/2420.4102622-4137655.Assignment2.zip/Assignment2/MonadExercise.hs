{-# LANGUAGE FunctionalDependencies #-}
{-# LANGUAGE FlexibleInstances #-}

module MonadExercise (
      annotate, 
      diagnostics, 
      runStateMonadPlus, 
      StoreState(..), 
      -- Not re-exporting Control.Monad.State. This module is determined to not be in the Prelude, 
      -- so it's supposed to be imported before usage.
      -- module Control.Monad.State
    ) where 

import Control.Monad.State (MonadState, put, get)
import Data.List (sort, intercalate)

data StatePlus s = StatePlus { state :: s, stack :: [s], annotations :: [(String, Int)]}

data StateMonadPlus s a = StateMonadPlus { runState :: (StatePlus s) -> Either String (a, StatePlus s) }

instance Functor (StateMonadPlus s) where
    fmap f x = x >>= (return . f)
    
instance Applicative (StateMonadPlus s) where
    pure = return

    fm <*> xm = do f <- fm
                   x <- xm
                   return (f x)

instance Monad (StateMonadPlus s) where
    return x = StateMonadPlus (\s -> Right (x, incAnot "return" s))
    
    (StateMonadPlus f) >>= g = StateMonadPlus (\s1 -> 
        do (x, s2) <- f s1 -- We leverage the Either monad here to ease implementation.
           let StateMonadPlus h = g x in h (incAnot "bind" s2))

    fail e = StateMonadPlus (const (Left e))

-- This instance needs the FlexibleInstances extension.
instance MonadState s (StateMonadPlus s) where
    get   = StateMonadPlus (\sp -> Right (state sp, sp))
    put s = StateMonadPlus (\sp -> Right ((), sp {state = s}))

-- Requires the MultiParamTypeClasses extension.
class MonadState s m => StoreState s m | m -> s where
    saveState :: m ()
    loadState :: m ()

instance StoreState s (StateMonadPlus s) where
    saveState   = StateMonadPlus (\sp -> Right ((), sp { stack = state sp : stack sp }))
    loadState   = StateMonadPlus f
        where f sp@(StatePlus s [] as)  = MonadExercise.runState (fail "Failed to load state from an empty stack.") sp
              f (StatePlus _ (s:ss) as) = Right ((), StatePlus s ss as)

incAnot :: String -> StatePlus s -> StatePlus s
incAnot a sp = let as = annotations sp in
    sp { annotations = (case lookup a as of
    (Just i) -> (a, i+1) : [(k, v) | (k, v) <- as, k /= a]
    Nothing  -> (a , 1 ) : as)}

annotate :: String -> StateMonadPlus s a -> StateMonadPlus s a
annotate a (StateMonadPlus f) = StateMonadPlus (\s1 -> do (x, s2) <- f s1
                                                          return (x, incAnot a s2))

diagnostics :: StateMonadPlus s String
diagnostics = StateMonadPlus (\s1 -> 
    let sp = incAnot "diagnostics" s1 in
    Right ("[" ++ intercalate ", " [k ++ "=" ++ show v | (k, v) <- sort (annotations sp)] ++ "]", sp))

runStateMonadPlus :: StateMonadPlus s a -> s -> Either String (a, s)
runStateMonadPlus (StateMonadPlus f) si = do (x, sp) <- f (StatePlus si [] [])
                                             return (x, state sp)