{- Exercises 3.3.3-3.3.5 -}

import Prelude hiding (foldMap)

data Rose a = a :> [Rose a]

{-
Nb: since the creation of the assignments, the Foldable class has been incorperated
into the prulude. To make a distinction between the prelude implementation and our
own, our Foldable class is suffixed with a '.
-}
class Functor f => Foldable' f where
  fold          :: Monoid m => f m -> m
  foldMap       :: Monoid m => (a -> m) -> f a -> m
  foldMap f xs  =  fold (fmap f xs)

instance Functor Rose where
  fmap f (x :> xs) = f x :> map (fmap f) xs

instance Foldable' Rose where
  fold (x :> xs) = mappend x $ mconcat $ map fold xs

{-
In order to be able to use the fold functions over a
Foldable data structure, the items within the DS must be monoids.

The Sum and Product types are implementations of the monoids,
so folding over them computes the sum and product resp.
-}
newtype Sum a = Sum { getSum :: a }

instance Num a => Monoid (Sum a) where
  mempty = Sum 0
  mappend (Sum x) (Sum y) = Sum (x+y)

newtype Product a = Product {getProduct :: a}

instance Num a => Monoid (Product a) where
  mempty = Product 1
  mappend (Product x) (Product y) = Product (x*y)


{-
The fsum and fproduct functions turn the numeric items in the containers
into monoids, and then use fold function (implicit in foldMap) to calculate
either the sum or the product. The value is then extracted from the monodic
type.
-}
fsum :: (Foldable' f, Num a) => f a -> a
fsum = getSum . foldMap Sum

fproduct :: (Foldable' f, Num a) => f a -> a
fproduct = getProduct . foldMap Product
