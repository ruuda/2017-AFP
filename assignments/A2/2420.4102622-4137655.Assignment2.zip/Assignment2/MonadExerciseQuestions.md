# Exercise 2.3.1
No. They do not hold because of diagnostic information being inserted in the state. For example, for the left identity we have to prove that `return a >>= f` is equivalent to `f a` (for all values `a` and `f` with correct types). However, `return a >>= f` will add a bind and a return to the diagnostic information, wheras `f a` does not.

# Exercise 2.3.2
It makes sure that the constructors are not initialized incorrectly. Also it guarantees that datatypes are in a certain known state, as they are only used within the module. This is important for the diagnostics feature, as it stores a list of diagnostics info. Finally the instances would have to be modified to cope with the general underlying monad.

# Exercise 2.3.3
The data declaration for `StateMonadPlus` would have to take an additional monad type parameter. `runStateMonadPlus` would have to be modified to return a result in the underlying monad. 

# Exercise 2.3.4
No. This cannot be done because the evaluation after `diagnosticsFuture` can depend on the string that `diagnosticsFuture` returns. In more detail, from the string that `diagnosticsFuture` returns the number of, for example, binds can be determined. This could be followed by an if statement, where both branches contain functions with a different number of binds. Then the if statement could always select the branch with a number of binds unequal to what `diagnosticsFuture` returned.
