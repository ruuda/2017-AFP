module Assignment2 where 

import System.IO (hFlush, stdout)

import Prelude hiding (Foldable, Monoid, mempty, foldMap)

data GP a   = End a
            | Get (Int -> GP a)
            | Put Int (GP a)

readInt :: IO Int
readInt = do
        putStr("?")
        hFlush stdout
        readLn
    
-- Task 1 of 2.2.8 
-- Creating run function
run :: GP a -> IO a
run (End a) = return a
run (Get f) = do
        int <- readInt
        run $ f int
run (Put n f) = do
        putStrLn $ show n
        run f

-- Task 2 of 2.2.8
-- GP program, read 2 Ints, writes sum, returns() 
program = Get (\x -> Get (\y -> Put (x+y) ( End () )))


-- Provided types and classes
class Monoid a where
    mempty  :: a
    (<>)    :: a -> a -> a

instance Monoid [a] where
    mempty  = []
    (<>)    = (++) 

-- 3.3.3
-- Write a default implementation of foldMap
class Functor f => Foldable f where
    fold    :: Monoid m => f m -> m
    foldMap :: Monoid m => (a -> m) -> f a -> m
    foldMap g a = fold $ (fmap g a)

instance Foldable [] where
    fold    = foldr (<>)  mempty

-- 3.3.2
-- Write a Foldable instance for Rose

data Rose a = a :> [Rose a]

instance Functor Rose where
    fmap f (x :> xs)    = (f x) :> (map (fmap f) xs)

instance Foldable Rose where
    fold (x :> xs)      =  x <> fold (fmap fold xs)

-- 3.3.4
-- Write fsum and fproduct
newtype Sum  a =  Sum { getSum  :: a }  
    deriving (Eq, Ord, Read, Show, Bounded)  

instance Num a => Monoid (Sum  a) where  
    mempty = Sum 0
    (<>) (Sum x) (Sum y) = Sum (x + y)  

newtype Product  a =  Product { getProduct  :: a }  
    deriving (Eq, Ord, Read, Show, Bounded)  

instance Num a => Monoid (Product  a) where  
    mempty = Product 1
    (<>) (Product x) (Product y) = Product (x * y)  

fsum :: (Foldable f, Num a) => f a -> a 
fsum a = getSum $ fold (fmap Sum a)

fproduct :: (Foldable f, Num a) => f a -> a
fproduct a = getProduct $ fold (fmap Product a)
