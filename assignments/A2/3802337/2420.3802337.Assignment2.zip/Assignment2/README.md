# Assignment 2 - Jasper Robeer (3802337)

The `src/Assignment2` directory contains the Haskell code files for the assignments:

 * Exercise 2.3 (Monads): `StateMonadPlus.hs`
 * Exercise 3.3.3, 3.3.4, 3.3.5 (Foldable): `Foldable.hs`
 * Exercise 2.2.8 (Teletype IO): `TeletypeIO.hs`
 * Exercise 2.2.9 (Stacks): `Stacks.hs`

The `test/Assignment2` directory contains unit tests and QuickCheck tests for
the exercises. The unit tests use [Hspec](http://hspec.github.io/). The files
containing the tests are named in line with the original code files.

## Running the assignments

The assignments are built using [Stack](https://www.haskellstack.org/). Run the
following commands to setup, build and test the assignments.

```
$ stack setup
$ stack build
$ stack test
```
