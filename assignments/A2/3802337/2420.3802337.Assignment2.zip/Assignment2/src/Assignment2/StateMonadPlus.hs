{-# LANGUAGE MultiParamTypeClasses, FlexibleInstances, FunctionalDependencies #-}

module Assignment2.StateMonadPlus (
    StateMonadPlus,
    StoreState(..),
    annotate,
    diagnostics,
    runStateMonadPlus,
    -- Re-export Control.Monad.State
    MonadState(..),
    modify,
    gets,
    ) where

import Control.Monad.State
import qualified Data.Map as Map
import Data.List (intercalate)

{-- Exercise 2.3 --}

-- State is defined (as per the slides) as: s -> (a, s)
-- but we need to store some extra information here

type AnnotationMap = Map.Map String Int
type Stack a = [a]
type InternalState s = (AnnotationMap, Stack s)
data StateMonadPlus s a = StateMonadPlus {
    runStateMonadPlusT :: (s, InternalState s) -> Either String (a, s, InternalState s)
}

-- | Represents an empty internal state
empty = (Map.empty, [])

-- | Updates the given annotation in the internal state, by increasing its counter
--   by one. If the annotation does not yet exists, it is added to the map.
updateAnnotationMap :: String -> InternalState s -> InternalState s
updateAnnotationMap k (m, s) = (Map.insertWith (+) k 1 m, s)

-- | Annotate a given computation with a given label. If the label is 'new', it
--   will add it to the internal map (=1). Otherwise, it will increase the count
--   of the label (+1).
annotate :: String -> StateMonadPlus s a -> StateMonadPlus s a
annotate lbl (StateMonadPlus rhs) = StateMonadPlus $ \(s, m) ->
    rhs (s, updateAnnotationMap lbl m)

-- | Shows the diagnostics from the internal state as a string.
showDiagnostics :: InternalState s -> String
showDiagnostics (m, s) = "[" ++ intercalate ", " (map f (Map.toList m)) ++ "]"
    where f (k, v) = k ++ "=" ++ show v

-- | This function should count the number of binds (>>=) and returns (and other
--   primitive functions) that have been encountered, including the call to
--   diagnostics at hand.
diagnostics :: StateMonadPlus s String
diagnostics = annotate "diagnostics" $ StateMonadPlus $
    \(s, m) -> Right (showDiagnostics m, s, m)

-- | Running the monad
runStateMonadPlus :: StateMonadPlus s a -> s -> Either String (a, s)
runStateMonadPlus (StateMonadPlus lhs) s =
    case lhs (s, empty) of
        Left msg          -> Left msg
        Right (r, s', m') -> Right (r, s')

-- Monad instance for the `StateMonadPlus` type.
--
-- Real World Haskell Chapter 14 provides a brief introduction to the state
-- monad.
--  (http://book.realworldhaskell.org/read/monads.html#monads.state)

instance Functor (StateMonadPlus s) where
    -- fmap :: (a -> b) -> StateMonadPlus s a -> StateMonadPlus s b
    fmap f (StateMonadPlus rhs) = StateMonadPlus $ \(s, m) -> do
        (x, s', m') <- rhs (s, m)
        return (f x, s', m')

instance Applicative (StateMonadPlus s) where
    -- pure :: a -> StateMonadPlus s a
    pure = return

    -- (<*>) :: StateMonadPlus s (a -> b) -> StateMonadPlus s a -> StateMonadPlus s b
    -- Note: According to the slides (slides03.pdf -- 10), the given implementation is
    --          mf <*> mx = do f <- mf; x <- mx; return (f x)
    --       Within the `do-notation` we are in the `Either` monad!
    (StateMonadPlus lhs) <*> (StateMonadPlus rhs) = StateMonadPlus $ \(s, m) -> do
        (f, s', m')   <- lhs (s, m)
        (x, s'', m'') <- rhs (s', m')
        return (f x, s'', m'')

instance Monad (StateMonadPlus s) where
    -- return :: a -> StateMonadPlus s a
    return x = annotate "return" $ StateMonadPlus $ \(s, m) -> Right (x, s, m)

    -- (>>=) :: StateMonadPlus s a -> (a -> StateMondaPlus s b) -> StateMonadPlus s b
    -- Note: we are using the `do-notation` here, as the result of the
    --       `StateMonadPlus` type is in the `Either` monad.
    (StateMonadPlus lhs) >>= f = annotate "bind" $ StateMonadPlus $ \(s, m) -> do
        (x, s', m') <- lhs (s, m)
        runStateMonadPlusT (f x) (s', m')

    -- fail :: String -> StateMonadPlus s a
    fail msg = annotate "fail" $ StateMonadPlus $ \_ -> Left msg

-- | MonadState instance for the `StateMonadPlus` type. To have this work we need
--   to enable the FlexibleInstances language extension.
instance MonadState s (StateMonadPlus s) where
    -- get :: StateMonadPlus s s
    get = annotate "get" $ StateMonadPlus $ \(s, m) -> Right (s, s, m)

    -- put :: s -> StateMonadPlus s ()
    put s = annotate "put" $ StateMonadPlus $ \(_, m) -> Right ((), s, m)

-- | The StoreState class allows us to save the current state (`saveState`), and
--   to restore a previous state as the current state (`loadState`).
class MonadState s m => StoreState s m | m -> s where
    saveState :: m ()
    loadState :: m ()

instance StoreState s (StateMonadPlus s) where
    saveState = annotate "saveState" $ StateMonadPlus $ \(s, (m, sx)) -> Right ((), s, (m, s:sx))

    loadState = annotate "loadState" $ StateMonadPlus $ \(_, (m, sx)) -> pop m sx
        where pop _ []     = fail "empty stack"
              pop m (s:sx) = Right ((), s, (m, sx))

{-- Bonus Questions --}

-- 2.3.1: Do the monad laws hold for `StateMonadPlus`?
--
-- I would argue that the monad laws do not hold for `StateMonadPlus`. Let's
-- look at one of the monad laws, "`return` is the unit of `(>>=)`":
--      return a >>= f == f a
--      m >>= return   == m
-- The internal state is modified with the `return` and bind (`(>>=)`) functions.
-- Therefore, the given laws above cannot hold, as for the first example:
-- `f a` and `return a >>= f` differ, as the latter has an internal state
-- with counters for bind/return at least 1 bigger. This is a side effect of
-- annotating the functions.

-- 2.3.2: What are the advantages of hiding (constructor) functions? How
--        important is this for each of the additional features supported by
--        `StateMonadPlus`?
--
-- By hiding functions we can enforce a public interface for the module. Thus,
-- we can hide the internal functionality from the (potential) users. Our
-- `StateMonadPlus` can benefit from this, by preventing others from modifing
-- the internal state.

-- 2.3.3: What are the modifications required to make a monad transformer for
--        `StateMonadPlus`?
--

-- 2.3.4: Suppose that we want to write a function
--          `diagnosticsFuture :: StateMonadPlus s String`
--        which provides information about the computations in `StateMonadPlus`
--        that are still to come. Explain how this would affect your code. If
--        you feel that such a facility cannot be implemented, then you should
--        give some arguments for your opinion. If you believe it can be done,
--        then try to do so.
