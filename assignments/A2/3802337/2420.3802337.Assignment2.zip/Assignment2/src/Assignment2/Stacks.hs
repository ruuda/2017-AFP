module Assignment2.Stacks where

{-- Exercise 2.2.9 --}

-- "Find Haskell definitions for the functions `start`, `stop`, `store`, `add`
-- and `mul` such that you can embed a stack-based language into Haskell:
--
--  p1, p2, p3 :: Int
--  p1 = start store 3 store 5 add stop
--  p2 = start store 3 store 6 store 2 mul add stop
--  p3 = start store 2 add stop
--
-- Here, p1 should evaluate to 8 and p2 should evaluate to 15. The program p3
-- is allowed to fail at runtime. Once you have that, try to find a solution 
-- that rejects programs that require non-existing stack elements during type 
-- checking.
--
-- Hint:  Type classes are not required to solve this assignment. This is 
-- somewhat related to continuations. Try to first think about the types that
-- the operations should have, then about the implementation."


-- A stack can simply be represented by an array in Haskell. This implementation
-- does **NOT** reject programs that require non-existing stack elements during
-- type checking.
--
-- The continuation is described by (Stack -> a) -> a; we apply this `function`
-- to the result of the current computation. Therefore, we can embed such a
-- stack based language.
-- [0] https://wiki.haskell.org/Continuation
type Stack = [Int]

start :: (Stack -> a) -> a
start f = f []

stop :: Stack -> Int
stop (x:_) = x

store :: Stack -> Int -> (Stack -> a) -> a
store ss x f = f (x:ss)

add :: Stack -> (Stack -> a) -> a
add (x:y:ss) f = f (x + y:ss)

mul :: Stack -> (Stack -> a) -> a
mul (x:y:ss) f = f (x * y:ss)

-- For our solution where we reject programs that require non-existing stack
-- elements during type checking, we redefine our `Stack` type much like the
-- fashion in which the list type is defined.
-- We **HAVE** to split the `Empty` and `Cons` types in two different types,
-- to have the power of the type checker.
data Empty  = Empty            -- []
            deriving Show
data Cons a = Cons Int a       -- Int:a
            deriving Show

start' :: (Empty -> a) -> a
start' f = f Empty

stop' :: Cons k -> Int
stop' (Cons x _) = x

store' :: k -> Int -> (Cons k -> a) -> a
store' ss x f = f (Cons x ss)

add' :: Cons (Cons k) -> (Cons k -> a) -> a
add' (Cons x (Cons y ss)) f = f (Cons (x+y) ss)

mul' :: Cons (Cons k) -> (Cons k -> a) -> a
mul' (Cons x (Cons y ss)) f = f (Cons (x*y) ss)
