{-# LANGUAGE MultiParamTypeClasses #-}

module Assignment2.TeletypeIO where

import Control.Monad
import Control.Monad.State

{-- Exercise 2.2.8 --}

data GP a = End a
          | Get (Int -> GP a)
          | Put Int (GP a)

-- Example program that continuously reads integers and prints them
echo :: GP a
echo = Get (\n -> Put n echo)

-- Task 1: write a function that can run a GP-program in the IO monad. A `Get`
--         should read an integer from the console, and `Put` should write an
--         integer to the console.
run :: GP a -> IO a
run (End a)   = return a
run (Get f)   = do
    putStr "? "
    line <- getLine
    run . f $ read line
run (Put n r) = print n >> run r

-- Task 2: write a GP-program `add` that reads two integers, writes the sum of
--         the two integers, and ultimately returns ().
add :: GP ()
add = Get $ \a ->
    Get (\b ->
        Put (a + b) (End ()))

-- Task 3: write a GP-program `accum` that reads an integer. If the integer is
--         0, it returns the current total. If the integer is not 0, it adds
--         the integer to the current total, prints the current total, and
--         starts from the beginning.
accum :: GP Int
accum = f 0
    where f acc = Get (\n -> if n == 0 then End acc
                             else let total = acc + n
                                  in Put total (f total))

-- Task 4: Instead of running a GP-program in the IO monad, we can also
--         simulate the behaviour of such a program by providing a (possibly
--         infinite) list of input values. Write a function that takes such a
--         list of input values and returns the final result plus the
--         (possibly infinite) list of all the output values generated.
simulate :: GP a -> [Int] -> (a, [Int])
simulate (End a) _      = (a, [])
simulate (Get f) (x:xs) = simulate (f x) xs
simulate (Put n r) xs   = let (a, xs') = simulate r xs
                          in (a, n : xs')

-- Task 5: Define sensible instances of `Monad` and `MonadState` for GP.
--         How is the behaviour of the `MonadState` instance for GP different
--         from the usual State type?
--         See: https://hackage.haskell.org/package/base-4.9.1.0/docs/Control-Monad.html

instance Functor GP where
    fmap f (End x)   = End (f x)
    fmap f (Get g)   = Get (fmap f . g)
    fmap f (Put n x) = Put n (fmap f x)

instance Monad GP where
    -- return :: a -> GP a
    return = End
    -- (>>=) :: GP a -> (a -> GP b) -> GP b
    (End x)   >>= f = f x
    (Get g)   >>= f = Get (g >=> f)         -- Hlint suggestion: f >=> g = \x -> f x >>= g
    (Put n r) >>= f = Put n (r >>= f)

instance MonadState Int GP where
    -- get :: GP s
    get = Get End
    -- put :: s -> GP ()
    put n = Put n (End ())

-- Apparently the following explicit `Applicative` declaration is required,
-- as my ghc compiler throws an error. This is 1-on-1 equivalent with the
-- declaration described in the Control.Monad documentation --- described
-- in the section that relates Monad and Applicative.
instance Applicative GP where
    pure  = return
    (<*>) = ap
