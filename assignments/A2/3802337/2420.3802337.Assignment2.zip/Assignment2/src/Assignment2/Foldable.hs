module Assignment2.Foldable where

import Prelude hiding (Foldable, foldMap)

{-- Exercise 3.3.(3/4/5) --}
-- Note: for most of these functions, the default libraries of Haskell
--       provide similar and intuitive definitions. Possible implementations
--       are very limited.

data Rose a = a :> [Rose a]
    deriving Show

-- Sum & Product instance from exercise 3.3.2, to be able to test our `Foldable`
-- class for the `Rose` data type. Furthermore, the official Data.Foldable
-- module implements this in a similar manner.
newtype Sum a = Sum { unSum :: a }
newtype Product a = Product { unProduct :: a }

instance Num a => Monoid (Sum a) where
    mempty = Sum 0
    (Sum a) `mappend` (Sum b) = Sum (a+b)

instance Num a => Monoid (Product a) where
    mempty = Product 1
    (Product a) `mappend` (Product b) = Product (a*b)

class Functor f => Foldable f where
    fold :: Monoid m => f m -> m

    foldMap :: Monoid m => (a -> m) -> f a -> m
    foldMap f x = fold (fmap f x)

instance Functor Rose where
    -- fmap :: (a -> b) -> Rose a -> Rose b
    fmap f (a :> as) = f a :> map (fmap f) as

instance Foldable Rose where
    -- fold :: Rose a -> a
    fold (a :> []) = a `mappend` mempty
    fold (a :> as) = a `mappend` foldr (mappend . fold) mempty as

fsum :: (Foldable f, Num a) => f a -> a
fsum = unSum . foldMap Sum

fproduct :: (Foldable f, Num a) => f a -> a
fproduct = unProduct . foldMap Product
