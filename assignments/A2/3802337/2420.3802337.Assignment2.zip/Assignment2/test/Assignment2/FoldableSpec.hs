module Assignment2.FoldableSpec where

import Test.Hspec
import Assignment2.Foldable

rose0 = 0 :> [12 :> [], 42 :> []]
rose1 = 1 :> [64 :> [], 48 :> []]

spec :: Spec
spec = do
    it ("fsum (" ++ show rose0 ++ ") = 54") $ do
        fsum rose0 `shouldBe` 54
    
    it ("fsum (" ++ show rose1 ++ ") = 113") $ do
        fsum rose1 `shouldBe` 113
    
    it ("fproduct (" ++ show rose0 ++ ") = 0") $ do
        fproduct rose0 `shouldBe` 0
    
    it ("fproduct (" ++ show rose1 ++ ") = 3072") $ do
        fproduct rose1 `shouldBe` 3072
