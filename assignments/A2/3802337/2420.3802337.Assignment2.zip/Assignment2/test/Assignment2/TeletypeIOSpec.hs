module Assignment2.TeletypeIOSpec where

import Test.Hspec
import Test.QuickCheck
import Assignment2.TeletypeIO

-- Custom generator which only returns lists with integers > 0
genPositiveIntList :: Gen [Int]
genPositiveIntList = listOf1 ((arbitrary :: Gen Int) `suchThat` (>0))

spec :: Spec
spec = do
    it "echo" $ property $
        \xs -> take (length xs) (snd $ simulate echo xs) == xs

    it "add" $ property $
        \x y -> simulate add [x,y] == ((), [x + y])

    it "accum (n = 0)" $ do
        simulate accum [0] `shouldBe` (0, [])

    it "accum (n > 0)" $ property $
        forAll genPositiveIntList $ \xs ->
            let ls       = scanl1 (+) xs
            in simulate accum (xs ++ [0]) == (last ls, ls)
