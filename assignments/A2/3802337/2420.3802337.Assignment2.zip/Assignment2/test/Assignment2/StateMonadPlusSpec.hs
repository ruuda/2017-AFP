module Assignment2.StateMonadPlusSpec where

import Test.Hspec
import Assignment2.StateMonadPlus
import qualified Data.Map as Map

prgmExample1 = do return 3 >> return 4
                  return 5
                  diagnostics

prgmExample2 = do annotate "A" (return 3 >> return 4)
                  return 5
                  diagnostics

prgmFailure = do fail "help!"
                 diagnostics

prgmStoreState = do i1 <- get; saveState
                    modify (*2)
                    i2 <- get; saveState
                    modify (*2)
                    i3 <- get; loadState
                    i4 <- get; loadState
                    i5 <- get
                    return (i1, i2, i3, i4, i5)

spec :: Spec
spec = do
    it "example program 1" $ do
        runStateMonadPlus prgmExample1 () `shouldBe` Right ("[bind=3, diagnostics=1, return=3]", ())

    it "example program 2 (w/ annotation)" $ do
        runStateMonadPlus prgmExample2 () `shouldBe` Right ("[A=1, bind=3, diagnostics=1, return=3]", ())

    it "failure" $ do
        runStateMonadPlus prgmFailure () `shouldBe` Left "help!"

    it "StoreState" $ do
        runStateMonadPlus prgmStoreState 1 `shouldBe` Right ((1,2,4,2,1), 1)
