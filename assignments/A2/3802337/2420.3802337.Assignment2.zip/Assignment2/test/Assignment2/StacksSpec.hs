module Assignment2.StacksSpec where

import Test.Hspec
import Control.Exception (evaluate)
import Assignment2.Stacks

spec :: Spec
spec = do
    describe "not type-checked" $ do
        it "p1 (= start store 3 store 5 add stop)" $ do
            start store 3 store 5 add stop `shouldBe` 8

        it "p2 (= start store 3 store 6 store 2 mul add stop)" $ do
            start store 3 store 6 store 2 mul add stop `shouldBe` 15

        it "p3 (= start store 2 add stop)" $ do
            evaluate (start store 2 add stop) `shouldThrow` anyException

    describe "type-checked" $ do
        it "p1 (= start store 3 store 5 add stop)" $ do
            start' store' 3 store' 5 add' stop' `shouldBe` 8

        it "p2 (= start store 3 store 6 store 2 mul add stop)" $ do
            start' store' 3 store' 6 store' 2 mul' add' stop' `shouldBe` 15
