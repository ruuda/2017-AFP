{-# LANGUAGE FlexibleInstances, FunctionalDependencies, MultiParamTypeClasses #-}

-- |Our solution to exercise 2.3.
module Assignment2.Monad
  ( StateMonadPlus, annotate, diagnostics, runStateMonadPlus
  , StoreState(..)
  , module Control.Monad.State
  ) where

import Control.Monad.State
import Data.List (intercalate)
import Data.MultiSet (MultiSet)
import qualified Data.MultiSet as MultiSet

-- |Represents the diagnostics that were annotated during a stateful computation.
type Diagnostics = MultiSet String

-- |A stack of previous stored state.
type History s = [s]

-- |Information that the 'StateMonadPlus' stores along with the state.
-- Placed in a data type to help with refactoring and extending features.
data AuxillaryState s = AuxillaryState
  { toDiags :: Diagnostics -- ^Labels that were annotated during computation.
  , toHist :: History s -- ^States that were saved during computation.
  }

-- |The state we start out with in 'runStateMonadPlus'.
-- Should act like an identity element under composition of computation.
initialState :: AuxillaryState s
initialState = AuxillaryState MultiSet.empty []

-- |A state monad with some extra features.
newtype StateMonadPlus s a = StateMonadPlus {
  unStatePlus :: (s, AuxillaryState s) -> Either String (a, s, AuxillaryState s)
  }
-- Note that we could also write this as:
-- (s, Diagnostics) -> Either String ([s], Diagnostics),
-- but that would also allow the stack to be empty,
-- so we'll put the stack in the auxillary state.

-- *Feature 1
-- |Add a new string to the diagnostics.
annotate :: String -> StateMonadPlus s a -> StateMonadPlus s a
-- Note that >>= uses annotate so we can't rely on the Monad instance yet
annotate label (StateMonadPlus ma) = StateMonadPlus $ \(st, aux) ->
  ma (st, aux { toDiags = MultiSet.insert label (toDiags aux) })

-- |Represent diagnostics in a human-readable format.
-- (Unfortunately, the format means we can't just use an existing Show instance.)
showDiagnostics :: Diagnostics -> String
showDiagnostics diags = "[" ++ intercalate ", " (map showOccur occurs) ++ "]"
  where
    occurs = MultiSet.toAscOccurList diags
    showOccur (name, count) = name ++ "=" ++ show count

-- |Get the diagnostics up to now as a 'String'.
-- Counts the number of primitive operations like '>>=' and 'pure'.
-- Also counts the usage of 'diagnostics' itself.
diagnostics :: StateMonadPlus s String
diagnostics = annotate "diagnostics" $ StateMonadPlus $ \(st, aux) ->
  Right (showDiagnostics $ toDiags aux, st, aux)

-- *Feature 2
-- |Lift a function to 'StateMonadPlus' by evaluating its argument in the monad.
instance Functor (StateMonadPlus s) where
  fmap f (StateMonadPlus mx) = StateMonadPlus $ \(st, aux) -> do
    (x, st', aux') <- mx (st, aux)
    pure (f x, st', aux')

-- |Unwrap a 'StateMonadPlus' function by evaluating it before its argument.
instance Applicative (StateMonadPlus s) where
  pure x = annotate "return" $
    StateMonadPlus $ \(st, aux) -> Right (x, st, aux)
  -- Note that we annotate with return to match the specification.

  (StateMonadPlus mf) <*> (StateMonadPlus mx) = annotate "ap" $
    StateMonadPlus $ \(st, aux) -> do
      (f, st', aux') <- mf (st, aux)
      (x, st'', aux'') <- mx (st', aux')
      pure (f x, st'', aux'')

-- |Bind a 'StateMonadPlus' computation by running its argument before the bind function.
-- Also provides a better failure case than a simple exception.
instance Monad (StateMonadPlus s) where
  (StateMonadPlus mx) >>= f = annotate "bind" $ StateMonadPlus $ \(st, aux) -> do
    (x, st', aux') <- mx (st, aux)
    unStatePlus (f x) (st', aux')
  fail message = annotate "fail" $ StateMonadPlus $ \_ -> Left message

-- |Perform a regular stateful computation without diagnostics or history.
instance MonadState s (StateMonadPlus s) where
  state f = annotate "state" $ StateMonadPlus $ \(st, aux) -> do
    let (x, st') = f st
    pure (x, st', aux)

-- *Feature 3
-- |Represents a stateful computation where an intermediate state can be stored
-- and later on read out again.
class MonadState s m => StoreState s m | m -> s where
  -- |Store the current state for later.
  -- The instance can define the number of stored states and in which order they are loaded.
  saveState :: m ()

  -- |Retrieve a stored state.
  -- If there is no stored state, the implementation may throw an error.
  loadState :: m ()

-- |Store states on a stack.
instance StoreState s (StateMonadPlus s) where
  saveState = annotate "saveState" $ StateMonadPlus $ \(st, aux) ->
    pure ((), st, aux { toHist = st : toHist aux })
  loadState = annotate "loadState" $ StateMonadPlus $ \(_, aux) ->
    case toHist aux of
      [] -> Left "loadState: no state saved"
      (st:sts) -> pure ((), st, aux { toHist = sts })

-- *Running the monad
-- |Given a computation in the 'StateMonadPlus' and an initial state,
-- returns either an error message if the computation failed, or
-- the result of the computation and the final state.
runStateMonadPlus :: StateMonadPlus s a -> s -> Either String a
runStateMonadPlus (StateMonadPlus mx) state = do -- Use the Either monad.
  (a, _, _) <- mx (state, initialState)
  pure a

-- *Bonus questions
-- Exercise 2.3.1
--  The monad laws do not hold! It's the diagnostics that mess everything up.
--  E.g. the law that m >>= return should be equivalent to m,
--  since (m >>= return) >> diagnostics will differ from m >> diagnostics,
--  reporting an extra bind and an extra return.
-- Exercise 2.3.2
--  Hiding constructors means hiding implementation details.
--  Because we do not export the precise AuxillaryState,
--  we are free to implement more state-based functionality.
--  In fact, we used this to implement feature #3 without touching previous code.
-- Exercise 2.3.3
--  The only real change would be to replace Either with EitherT,
--  since we already make use of the Either monad to implement our states.
-- Exercise 2.3.4
--  This might be possible under certain circumstances,
--  namely that control flow is not affected by the diagnostics returned.
--  Consider a program like:
--    flip runStateMonadPlus () $ do
--      diagFuture <- diagnosticsFuture
--      if contains "foo" diagFuture
--      then return "No foo here!"
--      else annotate "foo" (return "Foo here!")
--  There is no path through the function where the diagnostics match
--  the control flow, which means it should not terminate.
--
--  Excluding these nasty cases, we can implement this feature exploiting laziness:
--  add a record for "all diagnostics that will happen" in the AuxillaryState,
--  modify runStateMonadPlus to pass this in the initalState,
--  read the record in a new diagnosticsFuture function.
--  Of course, runStateMonadPlus now needs to know the computations that are to
--  come before it can run these computations, but you can put a variable
--  on both sides of an equation in Haskell, and this will only go wrong
--  by non-termination, which would occur exactly in the cases mentioned above.

