module Assignment2.Foldable where

import Data.Monoid
import Prelude hiding (Foldable, foldr, foldMap, fold)

-- | A copy of foldr from the old haskell prelude
foldr :: (a -> b -> b) -> b -> [a] -> b
foldr _f b [] = b
foldr f b (x:xs) =  x `f` foldr f b xs

class Functor f => Foldable f where
  foldMap :: Monoid m => (a -> m) -> f a -> m
  fold :: Monoid m => f m -> m
  foldMap f =  fold . fmap f
  fold = foldMap id

-- | The obvious instance
instance Foldable [] where
  fold = foldr mappend mempty

-- |A rose tree, where each node has an arbitrary number of children.
-- A leaf is just a node with an empty list of children.
data Rose a = a :> RoseForest a deriving Show

-- |A rose tree where the root node has no data.
-- Alternatively, a rose tree where the edges have a label instead of the nodes.
-- (But the type [(a, RoseForest a)] has less useful functions to work with.)
type RoseForest a = [Rose a]

-- |The obvious Functor instance. preserves structure but updates elements
instance Functor Rose where
  fmap f (a :> xs) = f a :> fmap (fmap f) xs

-- | Foldable is defined by appending the fold of the children to the root
instance Foldable Rose where
  fold (a :> xs) = a <> fold (fmap fold xs)

-- | We use the  Sum Monoid  (+,0) to fold
-- a collection of numbers to its sum
fsum :: (Foldable f, Num a) => f a -> a
fsum = getSum . foldMap Sum

-- | We use the Prod Monoid (*,1) to fold a collection
-- of numbers to its product
fproduct :: (Foldable f, Num a) => f a -> a
fproduct = getProduct . foldMap Product
