module Assignment2.TeletypeSpec where

import Test.Hspec
import Test.Hspec.QuickCheck
import Test.QuickCheck

import Assignment2.Teletype

spec :: Spec
spec = do
  -- TODO: can we test 'run'?
  describe "simulate" $ do
    it "handles composition of puts" $ do
      simulate (Put 0 (Put 1 (End ()))) [] `shouldBe` ((), [0, 1])
      simulate (Put 0 (Put 1 (End ()))) [12, 34] `shouldBe` ((), [0, 1])
    it "handles composition of put and get" $ do
      simulate (Put 0 (Get (\n -> End n))) [37] `shouldBe` (37, [0])
      simulate (Get (\n -> Put 0 (End n))) [37] `shouldBe` (37, [0])
      simulate (Get (\n -> Put n (End n))) [37] `shouldBe` (37, [37])
    it "handles composition of gets" $ do
      simulate (Get (\a -> Get (\b -> Put a (End b)))) [37, 42] `shouldBe` (42, [37])

  describe "echo" $ do
    it "puts back what it gets" $ do
      simulate' echo [0..10] `shouldBe` ((Nothing :: Maybe ()), [0..10])
      simulate' echo [] `shouldBe` ((Nothing :: Maybe ()), [])

  -- Note that we use 'simulate' for testing the programs
  describe "add" $ do
    prop "read two ints and output their sum" $ \a b ->
      simulate add [a, b] === ((), [a+b])
    prop "is equivalent to add'" $ \xs ->
      simulate' add xs === simulate' add' xs
  describe "accum" $ do
    it "stops immediately with a 0" $ do
      simulate accum [0] `shouldBe` (0, [])
      simulate accum [0, 1, 2, 3] `shouldBe` (0, [])
    it "adds a couple of numbers" $ do
      simulate accum [1, 2, 3, 0] `shouldBe` (6, [1, 3, 6])
      simulate accum [1, 2, 3, 0, 42, 37] `shouldBe` (6, [1, 3, 6])
    prop "is equivalent to accum'" $ \xs ->
      simulate' accum xs === simulate' accum' xs
