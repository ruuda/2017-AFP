module Assignment2.StacksSpec where

import Test.Hspec
import Test.Hspec.QuickCheck
import Test.QuickCheck

import Assignment2.Stacks

spec :: Spec
spec = do
  describe "stacks" $ do
    it "stores an int" $ do
      start store 3 stop `shouldBe` 3
    it "does the first two examples" $ do
      start store 3 store 5 add stop `shouldBe` 8
      start store 3 store 6 store 2 mul add stop `shouldBe` 15

