{-# LANGUAGE KindSignatures #-}
{-# LANGUAGE GADTs          #-}

module Assignment4 where

import System.IO.Unsafe
import Data.IORef
import Control.Monad (ap)
import Test.QuickCheck


--------------------------------------------------------------------------------
-- Unsafe IO

runningTotal :: IO ()
runningTotal =
  let rt' :: IORef Int -> IO ()
      rt' ref = do
        putStr "? "
        n <- readLn :: IO Int
        o <- readIORef ref
        let total = n + o
        writeIORef ref total
        putStrLn ("total: " ++ show total)
        rt' ref
  in newIORef 0 >>= rt'

{-# NOINLINE anything #-}
anything :: IORef a
anything = unsafePerformIO (newIORef undefined)
--
-- The thing with anything is that you really don't know anything about a, and
-- you have no IORef to read from. So you're just left (forall a. IORef a) which
-- you cannot satisfy for any a.

cast :: a -> b
cast x = unsafePerformIO (writeIORef anything x >> readIORef anything)

--------------------------------------------------------------------------------
-- Partiality Monad

data Partial a
  = Now a
  | Later (Partial a)
  deriving Show

loop :: Partial a
loop = Later loop

runPartial :: Int -> Partial a -> Maybe a
runPartial _ (Now x)  = Just x
runPartial 0 (Later _) = Nothing
runPartial n (Later p) = runPartial (n - 1) p

unsafeRunPartial :: Partial a -> a
unsafeRunPartial (Now x) = x
unsafeRunPartial (Later p) = unsafeRunPartial p

instance Functor Partial where
  f `fmap` (Now   x) = Now (f x)
  f `fmap` (Later x) = Later (f `fmap` x)

instance Applicative Partial where
  pure  = Now
  (<*>) = ap

instance Monad Partial where
  Now   x >>= f = f x
  Later p >>= f = Later (p >>= f)

tick :: Partial ()
tick = Later (Now ())

psum :: [Int] -> Partial Int
psum = fmap sum . mapM (\x -> tick >> return x)

class Monad m => MonadPlus m where
  mzero :: m a
  mplus :: m a -> m a -> m a

instance MonadPlus Partial where
  mzero = loop
  mplus = merge

merge :: Partial a -> Partial a -> Partial a
merge (Now x)   _ = Now x
merge (Later p) q =
  let next (Now   x) = Now x
      next (Later x) = merge p x
  in Later . next $ q

firstsum :: [[Int]] -> Partial Int
firstsum = foldr (mplus . psum) mzero


ls :: [[Int]]
ls =
  [ repeat 1
  , [1, 2, 3]
  , [4, 5]
  , [6, 7, 8]
  , cycle [5, 6]
  ]

ex_partial1, ex_partial2, ex_partial3 :: Maybe Int
ex_partial1 = (runPartial 100 . firstsum) ls
ex_partial2 = (runPartial 200 . firstsum . cycle) ls
ex_partial3 = (runPartial 200 . firstsum . concat)
  [ replicate 100 (repeat 1)
  , [[1]]
  , repeat (repeat 1)
  ]

--------------------------------------------------------------------------------
-- Contracts

data Contract :: * -> * where
  Pred :: (a -> Bool) -> Contract a
  DFun :: Contract a -> (a -> Contract b) -> Contract (a -> b) -- Looks very >>=
  List :: Contract a -> Contract [a]

assert :: Contract a -> a -> a
assert (DFun pre post) f = \x -> assert (post x) . f $ assert pre x
assert (Pred p)        x = if p x then x else error "Contract violation"
assert (List c)       xs = assert c <$> xs

(-->) :: Contract a -> Contract b -> Contract (a -> b)
a --> b = DFun a (const b)

pos :: (Num a, Ord a) => Contract a
pos = Pred (>0)

posTest :: IO ()
posTest = quickCheck posTrueNegOrZeroFalse
  where
    posTrueNegOrZeroFalse :: Int -> Property
    posTrueNegOrZeroFalse x = x > 0 ==> assert pos x == x

ex_contracts1, ex_contracts2 :: Int
ex_contracts1 = assert pos 2
ex_contracts2 = assert pos 0

-- Always returns a
true :: Contract a
true = Pred (const True)

{-  Pred (const True) will cause `if p x then ...` to reduce to `if True then
 -  ...`, whatever the value of x is,  so the `else` branch is never considered.
 -  QED
 -}

-- pseudoconstructor for a contract without precondition
pass :: (a -> Contract b) -> Contract (a -> b)
pass = DFun true

-- Consume a value and return a contract that always returns another value
-- unaltered
skip :: a -> Contract b
skip = const true

trueTest :: IO ()
trueTest = quickCheck alwaysId
  where
    alwaysId :: Int -> Bool
    alwaysId x = assert true x == x

ix :: Contract ([a] -> (Int -> a))
ix =
  let pre       n xs = 0 <= n && n < length xs -- predicate that has to be fulfilled
      assertIndex xs = Pred (`pre` xs)        -- Contract of pred
  in pass $ \xs -> DFun (assertIndex xs) skip

preserves :: Eq b => (a -> b) -> Contract (a -> a)
preserves f =
  let post x = Pred (\y -> f x == f y)
  in pass post

preservesPos :: (Num a, Ord a) => Contract (a -> a)
preservesPos  = preserves (>0)
{- inlined:
assert DFun (Pred (\_ -> True)) (\x -> Pred (\y -> f x == f y)) f =
  assert (\x -> Pred (\y -> f x == f y)) . f . assert (Pred (\_ -> True))
-}

preservesPos' :: (Ord b, Ord a, Num b, Num a) => Contract (a -> b)
preservesPos' = pos --> pos
{- inlined:
assert DFun (Pred (>0) (\_ ->(Pred (>0))) f =
  assert (\_ -> Pred (>0)) . f . assert (Pred (>0))
-}

{- In the inlined definitions it is clear that preservesPos has no precondition
 - and will perform the test after the function has been evaluated. Whereas
 - preservesPos' does have a precondition, the assertion will fail if the
 - precondition is not met and the function will not be evaluated.
 -
 - A good example of this is when these functions are evaluated
 - assert preservesPos  id (-1)    returns -1 (because False == False)
 - assert preservesPos' id (-1)    fails because the precondition of positivity
 -                                 is not met
 -
 -}

allPos :: (Ord a, Num a) => Contract [a]
allPos  = List pos

allPos' :: (Num a, Ord a, Foldable t) => Contract (t a)
allPos' = Pred (all (>0))

{- assert (List c) xs = map (assert c) xs
 - assert (Pred f)  x = if f x then x else ...
 -
 - List is more lazy than Pred because to choose a branch in Pred, f x has to be
 - evaluated which works on the whole list. Infinite lists will not work with
 - Pred due to this (a branch is never chosen)
 -
 - List would support lists of functions but Pred does not becaues there is the
 - Bool constraint
 -
 -}


