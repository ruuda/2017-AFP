module GenericRead where

import Generics.Deriving.Base
import Generics.Deriving.Instances

class GenRead a where
    genRead :: String -> a

instance GenRead (U1 a) where
    genRead _ = U1

instance (GenRead (f a), GenRead (g a)) => GenRead ((:+:) f g a) where
    genRead ('R':'1':xs) = R1 $ genRead xs
    genRead ('L':'1':xs) = L1 $ genRead xs

instance (GenRead (f p), GenRead (g p)) => GenRead ((:*:) f g p) where
    genRead = undefined

-- ik gooi de handdoek in de ring. 's allemaol moiielek
