module Trie
  ( Trie (..)
  , delete
  , empty
  , insert
  , lookup
  , null
  , valid
  ) where

import Prelude hiding (lookup, null)
import Data.Maybe
import Data.Char
import qualified Data.Map  as M
import qualified Data.Tree as T

data Trie a = Node (Maybe a) (M.Map Char (Trie a))
  deriving Eq

type Forest a = M.Map Char (Trie a)

value :: Trie a -> Maybe a
value (Node v _) = v

children :: Trie a -> Forest a
children (Node _ m) = m

-- | Nice `tree-like' show instance of Tries
instance Show a => Show (Trie a) where
  show = T.drawTree . convert

convert :: Show a => Trie a -> T.Tree String
convert = convert' '$'

convert' :: Show a => Char -> Trie a -> T.Tree String
convert' c (Node Nothing m) =
  let mapL = M.toList m
  in  T.Node [c] (uncurry convert' <$> mapL)
convert' c (Node (Just v) m) =
  let mapL = M.toList m
  in  T.Node (c : '-' : show v) (uncurry convert' <$> mapL)

instance Functor Trie where
  f `fmap` (Node v m) = Node (fmap f v) (fmap f `fmap`  m)

{- Delete a value from a trie with a key. The trie will be returned /unaltered/
 - if the key does not hold a value. This function will perform the lookup check
 - only once and then use the unexposed delete' function to do the actual work.
 -
 - NOTE:
 -  * res will only be evaluated lazily so it is safe
 -
 - A delete either deletes a value before a leaf, in which case the trie remains
 - valid, or it deletes a leaf in which case it has to be pruned in order to
 - remain valid.
 -
 - Law: forall str `notElem` trie . delete str trie == trie
 -}
delete :: Eq a => String -> Trie a -> Trie a
delete str t =
  let res = prune $ delete' str t
  in maybe t (const res) (lookup str t)

-- | Actual work function for deletion. This will only be called when there is
-- an actual value held at the key.
--
-- NOTE: the unsafe ! operator is guaranteed to be safe in this case because the
-- function that calls the helper checks that a path exists.
delete' :: Eq a => String -> Trie a -> Trie a
delete' []     (Node _ m) = Node Nothing m
delete' (s:tr) (Node v m) =
  Node v . (\y -> M.insert s y m) . delete' tr $ m M.! s

-- Subforests have to be replaced with the empty trie if none of their children
-- contain values.
prune :: Eq a => Trie a -> Trie a
prune (Node v m) =
  let newM = M.filter (\x -> countValues x > 0) m
  in Node v (prune <$> newM)

-- Count the amount of values in a trie. This is a helper function for pruning
-- and validity checking.
countValues :: Eq a => Trie a -> Int
countValues (Node v m) =
  sum (countValues <$> m) + case v of
    Nothing -> 0
    Just _  -> 1

-- | The empty trie
empty :: Trie a
empty = Node Nothing M.empty

{- Insert a value into a trie with a key.
 -
 - Law: str `elem` trie AND v == lookup str trie
 -          ==> insert str v trie == trie
 - "If you insert the same value at already existing position, the trie remains
 - the same"
 -
 - insert str v trie will /overwrite/ any existent value on the position if it
 - already exists. If the trie before the operation was valid, then the tree
 - after the operation either inserts before a `leaf value' in which case it
 - remains valid, or it creates a new leaf, in which case it is once again
 - valid. QED.
 -
 -}
insert :: String -> a -> Trie a -> Trie a
insert []      x (Node _ m) = Node (Just x) m
insert (s:tr) x (Node v m) =
  Node v . (\y -> M.insert s y m) . insert tr x $ if M.member s m
  then -- The path exists, so update the trie that resides there
    m M.! s
  else -- The path does not exist, so create a new branch to recurse on
    empty

-- | Easy, either find the value at the root in case of the empty string or
-- follow the path down the focus character if it exists. Nothing otherwise
lookup :: String -> Trie a -> Maybe a
lookup []     = value
lookup (s:tr) = maybe Nothing (lookup tr) . M.lookup s . children

-- | A trie contains nothing if it is equal to the empty Trie. Enforced by the
-- invariant.
null :: Eq a => Trie a -> Bool
null = (==empty)

{- The null trie is always valid. If the trie is not null, then the tree holds
 - at least one value in a leaf. If another key is added with a length more than
 - the current key, and they share the whole first key as prefix, then they add
 - a new leaf.
 -
 -          value in leaf
 -          |
 -          v  new value in leaf
 - broom - ()  |
 -             v
 - broomstick-()
 -     |
 -     () <- old value in leaf
 -}
valid :: Eq a => Trie a -> Bool
valid t = null t
  || validLeaf t
  || and (valid <$> children t)

-- A leaf is valid if it holds a value and the children-map is m
validLeaf :: Trie a -> Bool
validLeaf (Node (Just _) m) = M.null m
validLeaf _                 = False

-- Fun function, pass it a string!
trieFromText :: String -> Trie ()
trieFromText =
  let pass x = if x `elem` (['a'..'z'] ++ " ") then x else ' '
      pp = foldr (\x y -> pass (toLower x) : y) []
  in foldl (\x y -> insert y () x) empty . words

