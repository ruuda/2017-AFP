{-#Language GADTs, KindSignatures #-}

data Contract :: * -> * where
  Pred :: (a -> Bool) -> Contract a
  List :: Contract a  -> Contract [a]
  DFun :: Contract a  -> (a -> Contract b) -> Contract (a -> b)
  --Fun  :: Contract a  -> Contract b -> Contract (a -> b)

assert :: Contract a -> a -> a
assert (Pred p)         x  = if p x then x else error "contract violation"
assert (List c)         xs = map (assert c) xs
assert (DFun pre post)  f  = \x -> let apx = assert pre x in
                                    assert (post apx) $ f apx
--assert (Fun pre post)   f = \x -> assert post $ f $ assert pre x

pos :: (Num a, Ord a) => Contract a
pos = Pred (>0)

true :: Contract a
true  = Pred (const True)

(-->) :: Contract a -> Contract b-> Contract (a -> b)
a --> b = DFun a (const b)

safeListIndex :: Contract ([a] -> Int -> a)
safeListIndex = DFun true (\xs -> DFun (Pred (\x -> length xs > x)) (const true))
-- usage: assert safeListIndex (!!) [1..100] 100

preserves :: Eq b => (a -> b) -> Contract (a -> a)
preserves f = DFun true (\x -> Pred (\y -> f y == f x))

preservesPos :: Contract (Integer -> Integer)
preservesPos  = preserves (>0)

preservesPos' :: Contract (Integer -> Integer)
preservesPos' = pos --> pos

neg :: Integer -> Integer
neg x = x * (-1)

examplePreservesPos :: Integer
examplePreservesPos  = assert preservesPos  (neg.neg) (neg 1)

examplePreservesPos' :: Integer
examplePreservesPos' = assert preservesPos' (neg.neg) (neg 1)

allPos', allPos :: Contract [Integer]
allPos  = List pos
allPos' = Pred (all (>0))
