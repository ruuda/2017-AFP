{-# language TypeOperators #-}
{-# language DeriveGeneric #-}
{-# language FlexibleInstances #-}
{-# language ScopedTypeVariables #-}
{-# language FlexibleContexts #-}
{-# language UndecidableInstances #-}

import GHC.Generics
import Data.Maybe
import Prelude hiding (read) -- We write our own
import qualified Prelude (read)

data Syntax = Con String [Syntax] | Val String deriving Show

class Readable f where
    read :: f p -> Syntax -> Maybe (f p)

-- Instance for constructors with no arguments
instance Readable U1 where
    read p (Con _ []) = Just U1

-- Datatypes.
instance Readable f => Readable (D1 c f) where
    read p s = Just $ M1 $ fromJust $ read (undefined :: f p) s

-- Choice between constructors. The Maybe value is used to select the actual constructor.
instance (Readable l, Readable r) => Readable (l :+: r) where
    read p s = let l = read (undefined :: l p) s in
               let r = read (undefined :: r p) s in
               if isJust l
               then Just $ L1 $ fromJust l
               else Just $ R1 $ fromJust r

-- Constructor. Returns an actual C1 datatype if the constructor matches with
-- the expected Syntax, or Nothing if it does not.
instance (Constructor c, Readable f) => Readable (C1 c f) where
    read p (Con c as) = if c == conName p
    then Just $ M1 $ fromJust $ read (undefined :: f p) (Con "" as)
    else Nothing

-- Selectors.
instance Readable f => Readable (S1 c f) where
    -- Happens in case this is the only or last selector.
    read p (Con "" [s]) = read p s

    read p s = Just $ M1 $ fromJust $ read (undefined :: f p) s

-- Multiple arguments. Arguments from the Con(structor) are passed on one by one.
instance (Readable l, Readable r) => Readable (l :*: r) where
    read p (Con _ (a:as)) = Just $ fromJust (read (undefined :: l p) a) :*: fromJust (read (undefined :: r p) (Con "" as))

-- Instances for primitives (int, bool, float, ...)
instance Readable (K1 i Int) where
    read p (Val v) = Just (K1 parseInt)
        where parseInt = Prelude.read v :: Int

-- The instance for datatypes of kind (* -> *)
instance (Readable (Rep b), Generic (a b), Readable (Rep (a b))) => Readable (K1 i (a b)) where
    read p s = Just $ K1 $ to $ fromJust $ read (from (undefined:: (a b))) s


-- class to define a function `readSyntax` which takes a Syntax of an arbitrary Generic and produces its value.
class SyntaxReader a where
    readSyntax :: Syntax -> a

instance (Generic a, Readable (Rep a)) => SyntaxReader a where
    readSyntax = to . fromJust . read (from (undefined::a))

-- Note: for the actual read function we also must tokenize a string to a Syntax,
-- but this does not seem relevant for the exercise.

-- Example

data Tree a = Leaf a | Node (Tree a) (Tree a)
    deriving (Generic, Show)

example :: Tree Int
example = readSyntax $
    Con "Node" [Con "Leaf" [Val "1"], Con "Leaf" [Val "2"]]