import Control.Applicative
import Control.Monad
import Data.Maybe

data Partial a = Now a | Later (Partial a)
    deriving Show

-- Mandatory instance, required by the compiler
instance Functor Partial where
    fmap = liftM

-- Mandatory instance
instance Applicative Partial where
    pure  = return
    (<*>) = ap

instance Monad Partial where
    return        = Now
    Now x  >>= f  = f x
    Later p >>= f = Later (p >>= f)

-- Mandatory instance
instance Alternative Partial where
    (<|>) = mplus
    empty = mzero

instance MonadPlus Partial where
    mzero = loop
    mplus = merge

loop = Later loop

runPartial :: Int -> Partial a -> Maybe a
runPartial _ (Now x)   = Just x
runPartial 0 (Later p) = Nothing
runPartial n (Later p) = runPartial (n - 1) p

unsafeRunPartial :: Partial a -> a
unsafeRunPartial (Now x)   = x
unsafeRunPartial (Later p) = unsafeRunPartial p

-- The merge implementation given in the assignment
{-
merge :: Partial a -> Partial a -> Partial a
merge (Now x)   _         = Now x
merge _         (Now x)   = Now x
merge (Later p) (Later q) = Later (merge p q)
-}

-- Our unfair implementation
merge :: Partial a -> Partial a -> Partial a
merge (Now x)   _         = Now x
merge (Later p) q         = Later (merge' p q)
    where merge' p (Later q) = merge p q
          merge' p (Now x)   = Now x

tick = Later (Now ())

psum :: [Int] -> Partial Int
psum xs = liftM sum (mapM (\x -> tick >> return x) xs)

firstsum :: [[Int]] -> Partial Int
firstsum = foldr (\x a -> mplus (psum x) a) mzero

example = runPartial 100 $ firstsum [repeat 1, [1, 2, 3], [4, 5], [6, 7, 8], cycle [5, 6]]
example2 = runPartial 200 $ firstsum (cycle [repeat 1, [1, 2, 3], [4, 5], [6, 7, 8], cycle [5, 6]])
example3 = runPartial 200 $ firstsum (replicate 100 (repeat 1) ++ [[1]] ++ repeat (repeat 1))