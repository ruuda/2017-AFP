import Control.Monad
import Data.IORef
import System.IO.Unsafe

-- Exercise 2.10.5
main :: IO ()
main = do
    r <- newIORef 0
    forever $ do
        putStr "Add: "
        l <- getLine
        t <- readIORef r
        writeIORef r (t + read l :: Int)
        t' <- readIORef r
        putStrLn $ "Running total: " ++ show t'

-- Exercise 2.10.6
anything :: IORef a
anything = unsafePerformIO (newIORef undefined)

 -- Exercise 2.10.7
cast :: a -> b
cast x = unsafePerformIO $ do
    writeIORef anything x
    readIORef anything

-- `cast False :: Int` returns some random looking number, probably internal memory.

-- Run code below at your own risk.

-- Evaluating `crash` gives a SIGABRT on my PC.
crash :: String
crash = cast (2^64)

-- Another one. Note that if the datatype `X` is defined without `()` or without `Show`, it will not crash.
data X = Y () deriving Show
crash2 = cast (2^64)