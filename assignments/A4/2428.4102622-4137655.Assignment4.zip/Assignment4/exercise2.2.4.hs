import qualified Data.Map
import Data.Maybe

import Prelude hiding (null, lookup) -- Avoid name clashes with the trie functions

data Trie a = Node (Maybe a) (Data.Map.Map Char (Trie a)) deriving (Show, Eq)

empty  :: Trie a
empty = Node Nothing Data.Map.empty

null   :: Trie a -> Bool
null (Node Nothing m) = Data.Map.null m
null _                = False

valid  :: Trie a -> Bool
valid (Node v m) = all valid (Data.Map.elems m) && case v of
    Nothing -> not (all null (Data.Map.elems m))
    Just _  -> True

insert :: String -> a -> Trie a -> Trie a
insert ""     v (Node _ m) = Node (Just v) m
insert (k:ks) v (Node x m) = Node x $ Data.Map.alter (Just . insert ks v . fromMaybe empty) k m

lookup :: String -> Trie a -> Maybe a
lookup ""     (Node v _) = v
lookup (k:ks) (Node _ m) = Data.Map.lookup k m >>= lookup ks

delete :: String -> Trie a -> Trie a
delete ""     (Node _ m) = Node Nothing m
delete (k:ks) (Node v m) = Node v $ Data.Map.update (\t ->
    let t' = delete ks t in
    if null t' then Nothing else Just t') k m