module Assignment1.UnfoldSpec where

import Prelude hiding (iterate, map)

import Test.Hspec
import Test.Hspec.QuickCheck
import Test.QuickCheck hiding (labels, sized)
import Assignment1.Unfold

spec :: Spec
spec = do
  it "iterates function application" $
    iterate (+1) 0 `shouldMatchPart` [0::Int ..]
  it "maps like usual" $ do
    map (*2) [0..5] `shouldBe` [0::Int, 2 .. 10]
    map ("Hello, " ++) ["world", "haskell"] `shouldBe` ["Hello, world", "Hello, haskell"]
  prop "builds balanced trees" $
    forAll (resize 10 arbitrary :: Gen Int) $ -- Avoid exponentially large trees
    \n -> (n >= 0 && n < 10) ==> balanced n === balanced' n
  prop "sized trees have the right size" $ \n -> (n >= 0) ==> treeSize (sized n) === n
  prop "sized trees have unique labels" $ \n -> (n >= 0) ==> unique (labels $ sized n)
  where
  -- |Some arbitrary length after which we say lists are equivalent.
  startLength = 10
  -- |Check that two infinite lists start the same.
  shouldMatchPart x y = take startLength x `shouldBe` take startLength y

  -- |Generate a balanced tree in a straightforward recursive way.
  balanced' n | n < 0 = error "tree depth must be a natural number"
  balanced' 0 = Leaf ()
  balanced' n = Node (balanced' $ n-1) (balanced' $ n-1)

  -- |Count the number of nodes in the tree.
  treeSize (Leaf _) = 0
  treeSize (Node l r) = treeSize l + treeSize r + 1

  -- |Get all leaf labelings in the tree.
  labels (Leaf x) = [x]
  labels (Node l r) = labels l ++ labels r

  -- |Are all elements of the list unique?
  unique [] = True
  unique (x:xs) = x `notElem` xs && unique xs
