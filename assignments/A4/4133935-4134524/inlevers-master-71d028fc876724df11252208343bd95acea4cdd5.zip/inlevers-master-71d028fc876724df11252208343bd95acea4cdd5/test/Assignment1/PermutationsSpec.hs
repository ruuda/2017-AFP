module Assignment1.PermutationsSpec where

import Test.Hspec
import Test.Hspec.QuickCheck
import Test.QuickCheck

import Assignment1.Permutations

spec :: Spec
spec = do
  prop "perms and perms' are equal, for lists of length at most 5" $
    upto 5 $ \xs -> perms xs === (perms' xs :: [[Int]])

  prop "smoothPerms' gives the correct length lists" $
    upto 10 $ \xs n -> all (\perm -> length perm == length xs) $ smoothPerms' n xs

  prop "smoothPerms' gives only permutations" $
    upto 5 $ \xs n -> all (`elem` perms xs) $ smoothPerms' n xs

  prop "smoothPerms and smoothPerms' are equal, for lists of length at most 10" $
    upto 5 $ \xs n -> smoothPerms n xs === smoothPerms' n xs

  it "there is exactly (smooth) permutation of the empty list" $ do
    perms ([] :: [Int]) `shouldBe` [[]]
    perms' ([] :: [Int]) `shouldBe` [[]]
    smoothPerms 0 ([] :: [Int]) `shouldBe` [[]]
    smoothPerms' 0 ([] :: [Int]) `shouldBe` [[]]
  where
    -- |Test the property on lists up to a given length.
    upto :: (Arbitrary a, Show a, Testable prop) => Int -> ([a] -> prop) -> Property
    upto n p = forAll (vector n >>= sublistOf) $
        \xs -> length xs <= n ==> p xs
