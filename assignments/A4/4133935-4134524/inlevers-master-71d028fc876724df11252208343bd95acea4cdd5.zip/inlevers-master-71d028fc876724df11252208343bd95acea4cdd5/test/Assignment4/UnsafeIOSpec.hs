module Assignment4.UnsafeIOSpec where

import Test.Hspec
import Data.IORef

import Assignment4.UnsafeIO

spec :: Spec
spec = do
  describe "anything" $ do
    it "has various instances" $ do
      let anyInt = anything :: IORef Int
      let anyBool = anything :: IORef Bool
      let anyList = anything :: IORef [a]
      let anyA = anything :: IORef a
      True `shouldBe` True
  describe "runTotal" $ do
    totalRef <- runIO $ newIORef 0
    it "stops immediately with a 0" $ do
      runTotal totalRef 0 `shouldReturn` Right 0; readIORef totalRef `shouldReturn` 0
    it "adds a couple of numbers" $ do
      runTotal totalRef 1 `shouldReturn` Left 1; readIORef totalRef `shouldReturn` 1
      runTotal totalRef 2 `shouldReturn` Left 3; readIORef totalRef `shouldReturn` 3
      runTotal totalRef 3 `shouldReturn` Left 6; readIORef totalRef `shouldReturn` 6
      runTotal totalRef 0 `shouldReturn` Right 6; readIORef totalRef `shouldReturn` 6
  describe "runningTotal" $ do
    it "works interactively" $ do
      pendingWith "fire up GHCi and test against the inputs '1; 2; 3; 0'"
