{-# LANGUAGE LambdaCase #-}

module Assignment4.TrieSpec where

import Data.Map (Map)
import qualified Data.Map as Map
import Data.Maybe
import qualified Data.List as List
import Test.Hspec
import Test.Hspec.QuickCheck
import Test.QuickCheck

import Assignment4.Trie (Trie)
import qualified Assignment4.Trie as Trie

exampleTrie :: Trie Int
exampleTrie = Trie.Node Nothing (Map.fromList
  [ ('b', Trie.Node Nothing (Map.fromList
    [ ('a', Trie.Node Nothing (Map.fromList
      [ ('r', Trie.Node (Just 2) Map.empty)
      , ('z', Trie.Node (Just 3) Map.empty)
      ]))
    ]))
  , ('f', Trie.Node (Just 0) (Map.fromList
    [ ('o', Trie.Node Nothing (Map.fromList
      [ ('o', Trie.Node (Just 1) Map.empty)
      ]))
    ]))
  ])

invalidTrie :: Trie Int
invalidTrie = Trie.Node Nothing (Map.fromList
  [ ('b', Trie.Node Nothing (Map.fromList
    [ ('a', Trie.Node Nothing (Map.fromList
      [ ('r', Trie.Node (Just 2) Map.empty)
      , ('z', Trie.Node (Just 3) Map.empty)
      ]))
    ]))
  , ('f', Trie.Node (Just 0) (Map.fromList
    [ ('o', Trie.Node (Just 1) (Map.fromList
      [ ('o', Trie.Node Nothing Map.empty)
      ]))
    ]))
  ])

-- |Directly get the keys of a 'Trie'.
keys' :: Trie a -> [String]
keys' (Trie.Node a cs) = addHead a $ Trie.mapConcatMapWithKey startingChar cs
  where
  -- Add the empty string to the list of keys if this node has a value.
  addHead :: Maybe a -> [String] -> [String]
  addHead (Just _) = ("" :)
  addHead Nothing = id
  -- Add the given starting character to all the keys in the subtrie.
  startingChar :: Char -> Trie a -> [String]
  startingChar k trie = map (k:) $ keys' trie
-- |Directly get the values of a 'Trie'.
values' :: Trie a -> [a]
values' (Trie.Node (Just a) cs) = a : Trie.mapConcatMap values' cs
values' (Trie.Node Nothing cs) = Trie.mapConcatMap values' cs


-- |Generate any instance of 'Trie', not necessarily valid.
genAnyTrie :: Arbitrary a => Gen (Trie a)
genAnyTrie = sized $ \case
  0 -> pure Trie.empty
  n -> resize (n-1) $ Trie.Node <$> arbitrary <*> arbitrary
-- |Shrink any instance of 'Trie', not necessarily valid.
shrinkAnyTrie (Trie.Node a cs) = Map.elems cs ++
    [Trie.Node a' cs' | (a', cs') <- shrink (a, cs)]

-- |Generate a valid instance of 'Trie'.
genValidTrie :: Arbitrary a => Gen (Trie a)
genValidTrie = oneof [pure Trie.empty, sized genNonzeroTrie]
  where
  genNonzeroTrie n = do
    stopping <- arbitrary
    if n <= 1 || stopping
    then (\a -> Trie.Node (Just a) Map.empty) <$> arbitrary
    else do
      count <- choose (1, n-1)
      -- Don't let the trie grow exponentially large.
      children <- vectorOf count $ (,) <$> arbitrary <*> genNonzeroTrie (n `div` count)
      a <- arbitrary
      pure $ Trie.Node a $ Map.fromList children
-- |Shrink a valid 'Trie' into valid subtries.
shrinkValidTrie :: Arbitrary a => Trie a -> [Trie a]
shrinkValidTrie = filter Trie.valid . shrinkAnyTrie

forAllValid :: (Arbitrary a, Show a, Testable prop) => (Trie a -> prop) -> Property
forAllValid = forAllShrink genValidTrie shrinkValidTrie

-- Generate an arbitrary valid trie.
instance Arbitrary a => Arbitrary (Trie a) where
  arbitrary = genValidTrie
  shrink = shrinkValidTrie

spec :: Spec
spec = do
  describe "valid" $ do
    it "verifies the example tries" $ do
      Trie.valid Trie.empty `shouldBe` True
      Trie.valid exampleTrie `shouldBe` True
      Trie.valid invalidTrie `shouldBe` False
  describe "Arbitrary instance" $ do
    prop "generates valid tries" $ forAll genValidTrie $ \trie ->
      Trie.valid (trie :: Trie Int)
    prop "shrinks valid tries correctly" $ forAll genValidTrie $ \trie ->
      all Trie.valid $ shrinkValidTrie (trie :: Trie Int)
  describe "nonzero" $ do
    it "works on the example tries" $ do
      Trie.nonzero Trie.empty `shouldBe` False
      Trie.nonzero exampleTrie `shouldBe` True
      Trie.nonzero invalidTrie `shouldBe` True
  describe "null" $ do
    it "correctly identifies the empty trie" $ do
      Trie.null Trie.empty
    it "correctly rejects the exampleTrie" $ do
      not $ Trie.null exampleTrie
    prop "identifies valid tries" $ \trie ->
      Trie.nonzero (trie :: Trie Int) == not (Trie.null trie)
  describe "toList" $ do
    it "finds the items of the example tries" $ do
      Trie.toList (Trie.empty :: Trie Int) `shouldMatchList` []
      Trie.toList exampleTrie `shouldMatchList` [("f", 0), ("foo", 1), ("bar", 2), ("baz", 3)]
    prop "gives no items iff the trie is zero" $ \trie ->
      Trie.null (trie :: Trie Int) == null (Trie.toList trie)
  describe "keys" $ do
    prop "is equivalent to keys'" $ \trie ->
      Trie.keys (trie :: Trie Int) `shouldMatchList` keys' trie
  describe "values" $ do
    prop "is equivalent to values'" $ \trie ->
      Trie.values (trie :: Trie Int) `shouldMatchList` values' trie
  describe "lookup" $ do
    it "can lookup in the exampleTrie" $ do
      Trie.lookup "f" exampleTrie `shouldBe` Just 0
      Trie.lookup "foo" exampleTrie `shouldBe` Just 1
      Trie.lookup "bar" exampleTrie `shouldBe` Just 2
      Trie.lookup "baz" exampleTrie `shouldBe` Just 3
      Trie.lookup "" exampleTrie `shouldBe` Nothing
      Trie.lookup "ba" exampleTrie `shouldBe` Nothing
      Trie.lookup "boo" exampleTrie `shouldBe` Nothing
      Trie.lookup "far" exampleTrie `shouldBe` Nothing
    prop "finds nothing in the empty trie" $ \key ->
      isNothing $ Trie.lookup key (Trie.empty)
    prop "looks up existing keys" $ \trie ->
      Trie.nonzero (trie :: Trie Int) ==> forAll (elements $ Trie.keys trie) $ \key ->
        isJust $ Trie.lookup key trie
    prop "commutes with toList" $ \trie key ->
      Trie.lookup key (trie :: Trie Int) == List.lookup key (Trie.toList trie)
  describe "insert" $ do
    prop "preserves the invariant" $ \trie key val ->
      Trie.valid $ Trie.insert key val (trie :: Trie Int)
    prop "adds a new value to the trie" $ \trie key val ->
      Trie.lookup key (Trie.insert key val (trie :: Trie Int)) === Just val
    prop "replaces existing keys" $ \trie val ->
      Trie.nonzero trie ==> forAll (elements $ Trie.keys trie) $ \key ->
        Trie.lookup key (Trie.insert key val (trie :: Trie Int)) === Just val
  describe "delete" $ do
    prop "works on the empty trie" $ \key ->
      Trie.delete key (Trie.empty) === (Trie.empty :: Trie Int)
    prop "gets rid of a value" $ \trie ->
      Trie.nonzero trie ==> forAll (elements $ Trie.keys trie) $ \key ->
        Trie.lookup key (Trie.delete key (trie :: Trie Int)) === Nothing
    prop "works on any key" $ \trie key ->
      Trie.lookup key (Trie.delete key (trie :: Trie Int)) === Nothing
    prop "preserves the invariant" $ \trie ->
      Trie.nonzero trie ==> forAll (elements $ Trie.keys trie) $ \key ->
        Trie.valid $ Trie.delete key (trie :: Trie Int)
