module Assignment4.GenericsSpec where

import Test.Hspec
import Test.Hspec.QuickCheck
import Test.QuickCheck


import qualified Assignment4.Generics as Generics

instance (Arbitrary a, Arbitrary b) => Arbitrary (Generics.Tuple a b) where
  arbitrary = Generics.MkTuple <$> arbitrary <*> arbitrary

instance (Arbitrary a, Arbitrary b) => Arbitrary (Generics.Result a b) where
  arbitrary = oneof [Generics.Error <$> arbitrary,  Generics.Success <$> arbitrary]

instance Arbitrary a => Arbitrary (Generics.List a) where
  arbitrary = (foldr Generics.Cons Generics.Nil :: [a] -> Generics.List a)  <$> arbitrary

instance Arbitrary Generics.Condition where
  arbitrary = oneof [pure Generics.Bad, pure Generics.Good]
instance Arbitrary Generics.User where
  arbitrary = Generics.MkUser <$> arbitrary <*> arbitrary <*> arbitrary <*> arbitrary

spec :: Spec
spec = do
  prop "Tuple"  ((\x -> Generics.gread (Generics.gshow x) === x) :: Generics.Tuple Int String -> Property)
  prop "Result"  ((\x -> Generics.gread (Generics.gshow x) === x) :: Generics.Result Int String -> Property)
  prop "List"  ((\x -> Generics.gread (Generics.gshow x) === x) :: Generics.List Int -> Property)
  prop "User"  ((\x -> Generics.gread (Generics.gshow x) === x) :: Generics.User -> Property)
