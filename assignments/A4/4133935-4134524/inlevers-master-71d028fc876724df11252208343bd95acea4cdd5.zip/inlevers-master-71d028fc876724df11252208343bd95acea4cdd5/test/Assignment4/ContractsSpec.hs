module Assignment4.ContractsSpec where

import Test.Hspec
import Test.Hspec.QuickCheck
import Test.QuickCheck

import Assignment4.Contracts

-- |Sets the expectation that evaluating @x@ throws an exception.
pureShouldThrow x sel = seq x (pure x) `shouldThrow` sel
contractFails x = x `pureShouldThrow` errorCall "contract violation"

spec :: Spec
spec = do
  describe "pos" $ do
    it "works on the examples" $ do
      assert pos 2 `shouldBe` 2
      contractFails $ assert pos 0
  describe "true" $ do
    prop "holds on all ints" $ \x ->
      assert true x === (x :: Int)
    it "holds on all values" $
      pendingWith "is verified using equational reasoning"
  describe "index" $ do
    prop "fails on negative ints" $ \(Positive i) xs ->
      contractFails $ assert index (!!) (xs :: [Int]) (-i)
    prop "accepts the expected range" $ \(Positive n) ->
      forAll (vector $ n+1) $ \xs -> forAll (choose (0, n)) $ \i ->
        assert index (!!) xs i `shouldBe` (xs !! i :: Int)
    prop "rejects too large numbers" $ \(Positive i) xs ->
      contractFails $ assert index (!!) (xs :: [Int]) (length xs + i)
  describe "preserves" $ do
    it "works on the examples" $ do
      assert (preserves length) reverse "Hello" `shouldBe` "olleH"
      assert (preserves length) (take 5) "Hello" `shouldBe` "Hello"
      contractFails $ assert (preserves length) (take 5) "Hello world"
  describe "the difference between preservesPos and preservesPos'" $ do
    it "is in the precondition" $ do
      assert preservesPos (+1) (-2) `shouldBe` -1
      contractFails $ assert preservesPos' (+1) (-2)
  describe "the difference between allPos and allPos'" $ do
    it "is in non-termination" $ do
      take 5 (assert (allPos -|> allPos) (map (+1)) [10, 9 ..]) `shouldBe` [11, 10, 9, 8, 7]
      contractFails $ take 5 $ assert (allPos' -|> allPos') (map (+1)) [10, 9 ..]
      take 5 (assert (allPos -|> allPos) (map (+1)) [1, 2 ..]) `shouldBe` [2, 3, 4, 5, 6]
