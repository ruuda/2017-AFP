module Assignment4.PartialSpec where

import Test.Hspec
import Test.Hspec.QuickCheck
import Test.QuickCheck

import Control.Applicative 
import Assignment4.Partial

instance Arbitrary a => Arbitrary (Partial a) where
  arbitrary = sized arbitrary'
    where
      arbitrary' 0 = Now <$> arbitrary
      arbitrary' n = Later <$> arbitrary' (n-1)

spec :: Spec
spec = do
  it "example1" $ do
    runPartial 100 ( firstsum [repeat 1, [1, 2, 3], [4, 5], [6, 7, 8], cycle [5, 6]])
    `shouldBe` Just 9
  it "unfair" $ do
    runPartial 200 ( firstsum (cycle  [repeat 1, [1, 2, 3], [4, 5], [6, 7, 8], cycle [5, 6]]))
    `shouldBe` Just 9
  it "unfair2" $ do
    runPartial 200 (firstsum (replicate 100 (repeat 1) ++ [[1]] ++ repeat (repeat 1)))
    `shouldBe` Just 1
  prop "<|> is associative" assoc
  where
    assoc :: Partial Int -> Partial Int -> Partial Int -> Property
    assoc x y z = (x <|> (y <|> z)) === ((x <|> y) <|> z)
