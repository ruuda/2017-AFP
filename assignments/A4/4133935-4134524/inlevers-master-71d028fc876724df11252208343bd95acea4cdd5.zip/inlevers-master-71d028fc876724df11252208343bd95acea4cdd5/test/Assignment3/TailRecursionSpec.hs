module Assignment3.TailRecursionSpec where

import Test.Hspec
import Test.Hspec.QuickCheck
import Test.QuickCheck

import Assignment3.TailRecursion

instance Arbitrary a => Arbitrary (Tree a) where
    arbitrary = sized $ \n -> case n of
        0 -> Leaf <$> arbitrary
        n -> do
            k <- choose (0, n-1)
            oneof
                [ Leaf <$> arbitrary
                , Node <$> resize k arbitrary <*> resize (n-k-1) arbitrary
                ]
    shrink (Leaf a) = [Leaf a' | a' <- shrink a]
    shrink (Node l r) = l : r : [Node l' r' | (l', r') <- shrink (l, r)]

spec :: Spec
spec = do
  describe "splitleft'" $ do
    prop "is the same as splitleft" $ ((\tree ->
      splitleft tree === splitleft' tree) :: (Tree Int -> Property))

