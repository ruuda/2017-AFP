module Assignment3.FixpointSpec where

import Test.Hspec
import Test.Hspec.QuickCheck
import Test.QuickCheck

import Prelude
import qualified Prelude as Their
import qualified Assignment3.Fixpoint as Our

spec :: Spec
spec = do
  describe "our foldr" $ do
    prop "gives the right toList" ((\xs ->
      Our.foldr (:) [] xs === xs) :: [Int] -> Property)
    prop "is the same as their foldr" ((\xs ->
      Our.foldr (++) "" xs === Their.foldr (++) "" xs) :: [String] -> Property)

