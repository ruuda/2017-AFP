-- |Our solution to exercise 2.2.4
module Assignment4.Trie where

import Prelude hiding (null, lookup)

import Data.Map (Map)
import qualified Data.Map as Map

-- *Utility functions on 'Map'
allElems, anyElems :: (v -> Bool) -> Map k v -> Bool
-- |Does the predicate hold on all elements of this map?
allElems pred = Map.foldr (\x r -> pred x && r) True
-- |Does the map have an element which satisfies the predicate?
anyElems pred = Map.foldr (\x r -> pred x || r) False

-- |Equivalent to 'concatMap' on the values in this map.
mapConcatMap :: (v -> [a]) -> Map k v -> [a]
mapConcatMap f = Map.foldr (\x ys -> f x ++ ys) []
-- |Equivalent to 'concatMap' on the key, value pairs in this map.
mapConcatMapWithKey :: (k -> v -> [a]) -> Map k v -> [a]
mapConcatMapWithKey f = Map.foldrWithKey (\k x ys -> f k x ++ ys) []

-- |From the exercise:
-- The type of trees mapping a string to values by following the string as a path.
-- The invariant is that any 'Trie' with children contains a 'Just _' descendant.
data Trie a = Node (Maybe a) (Map Char (Trie a))
  deriving (Eq, Show)

-- |The canonical empty 'Trie'.
empty :: Trie a
empty = Node Nothing Map.empty

-- |Is this 'Trie' empty? (i.e. is this 'Trie' equal to 'empty'?)
-- Note that we assume the invariant holds, so a 'Trie' that does not
-- respect the invariant can have no keys but still be considered non-'null'.
null :: Trie a -> Bool
null (Node Nothing cs) = Map.null cs
null _ = False

-- |Does this 'Trie' contain an element?
-- Also works for invalid 'Trie's.
nonzero :: Trie a -> Bool
nonzero (Node (Just _) _) = True
nonzero (Node Nothing cs) = anyElems nonzero cs

-- |Does the invariant hold in this 'Trie'?
valid :: Trie a -> Bool
valid (Node _ cs) = Map.null cs || (anyElems nonzero cs && allElems valid cs)

-- |Get all the (key, value) pairs inserted in this 'Trie'.
toList :: Trie a -> [(String, a)]
toList (Node a cs) = addHead a $ mapConcatMapWithKey startingChar cs
  where
  -- Add the empty string as a key if this node has a value.
  addHead :: Maybe a -> [(String, a)] -> [(String, a)]
  addHead (Just a) = (("", a) :)
  addHead Nothing = id
  -- Add the given starting character to all the items in the subtrie.
  startingChar :: Char -> Trie a -> [(String, a)]
  startingChar k trie = map (\(ks, v) -> (k:ks, v)) $ toList trie
-- |Get all the keys inserted in this 'Trie'.
keys :: Trie a -> [String]
keys = map fst . toList
-- |Get all the values inserted in this 'Trie'.
values :: Trie a -> [a]
values = map snd . toList

-- |Insert a new value into the 'Trie'.
-- Replaces any existing value with the same key.
insert :: String -> a -> Trie a -> Trie a
insert [] v (Node _ cs) = Node (Just v) cs
insert (x:xs) v (Node a cs) = Node a $ Map.alter insertHere x cs
  where
  insertHere Nothing = Just $ insert xs v empty
  insertHere (Just trie) = Just $ insert xs v trie

-- |Find the value with the given key in a 'Trie'.
-- If the key does not exist, returns 'Nothing'.
lookup :: String -> Trie a -> Maybe a
lookup [] (Node a _) = a
lookup (x:xs) (Node _ cs) = Map.lookup x cs >>= lookup xs

-- |Get rid of the value with the given key in a 'Trie'.
-- If the string isn't a key, returns the original 'Trie'.
-- Also ensures the invariant remains valid.
delete :: String -> Trie a -> Trie a
delete [] (Node _ cs) = Node Nothing cs
delete (x:xs) (Node a cs) = Node a $ Map.update deleted x cs
  where
  -- Throw away tries that are empty, so the invariant holds.
  deleted trie = let trie' = delete xs trie in
    if null trie'
    then Nothing
    else Just trie'
