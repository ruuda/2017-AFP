{-#LANGUAGE DeriveGeneric #-}
{-#LANGUAGE DefaultSignatures #-}
{-#LANGUAGE FlexibleInstances #-}
{-#LANGUAGE FlexibleContexts #-}
{-#LANGUAGE TypeOperators #-}
{-#LANGUAGE ScopedTypeVariables #-}

-- |Our solution to exercise 2.11.2
module Assignment4.Generics
( Unit (..)
, Result (..)
, Tuple (..)
, List  (..)
, Condition (..)
, User (..)
, module GHC.Generics
, GShow' (..)
, GShow (..)
, gread
, gshow
) where

import Text.Show
import Text.ParserCombinators.ReadP
import GHC.Generics
import Control.Applicative

-- * Generics
-- we are not interested in Haskell's syntax shenanigans so we ignore the fact
-- that tuples, lists and record syntax exist
-- we also ignore the fact that operators exist. they just make stuff more difficult

-- |The type with a unique member.
data Unit = Unit deriving (Generic, Eq)
instance GShow Unit
instance Show Unit where show = gshow
instance GRead Unit

-- |The type with two members.
data Condition
  = Bad
  | Good
  deriving (Generic, Eq)
instance GShow Condition
instance Show Condition where show = gshow
instance GRead Condition

-- |The coproduct of two types.
data Result a b
  = Error a
  | Success b
  deriving (Generic, Eq)

instance (GShow a, GShow b) => GShow (Result a b)
instance (GShow a, GShow b) => Show (Result a b) where show = gshow
instance (GRead a, GRead b) => GRead (Result a b)

-- |The product of two types.
data Tuple a b
  = MkTuple a b
  deriving (Generic, Eq)
instance (GShow a, GShow b) => GShow (Tuple a b)
instance (GShow a, GShow b) => Show (Tuple a b) where show = gshow
instance (GRead a, GRead b) => GRead (Tuple a b)

-- |A list of a certain type, without all the special-cased syntax.
data List a
  = Nil
  | Cons a (List a)
  deriving (Generic, Eq)
instance (GShow a) => GShow (List a)
instance (GShow a) => Show (List a) where show = gshow
instance (GRead a) => GRead (List a)

-- * User
type Name = String
type Tags = List String
type Inventory = List (Tuple String Int)

-- |A nontrivial example data type.
data User
  = MkUser
      Name
      Tags
      Inventory
      Condition
  deriving (Generic, Eq)
instance GShow User
instance Show User where show = gshow
instance GRead User

-- |An example 'User'.
arian :: User
arian = MkUser "arian" (Cons "haskell" (Cons "fp" Nil)) (Cons (MkTuple "bread" 5) Nil) Bad
-- |How to show the representation of a constructor.
class GShow' rep where
  gshows' :: rep a -> ShowS

-- | Constructor with no arguments, like 'False' or 'True'.
instance GShow' U1 where
  gshows' U1 = id

-- |Constant value.
instance GShow c => GShow' (K1 i c) where
  gshows' (K1 a) = gshows a

-- |Show a data constructor name and its body recursively.
instance (GShow' a, Constructor c) => GShow' (M1 C c a) where
  gshows' c@(M1 x) =
    showParen True
      ( showString (conName c) . showChar ' ' . gshows' x )

-- |Show the fields of a data constructor.
-- We ignore selector names, i.e. we don't care about record fields.
instance (GShow' a, Selector s) => GShow' (M1 S s a) where
  gshows' (M1 x) = gshows' x

-- |Ignore the datatype name.
instance (GShow' a) => GShow' (M1 D d a) where
  gshows' (M1 x) = gshows' x

-- |Either show the left hand side or the right hand side.
instance (GShow' a, GShow' b) => GShow' (a :+: b) where
  gshows' (L1 x) = gshows' x
  gshows' (R1 x) = gshows' x

-- |Show left and then right.
instance (GShow' a, GShow' b) => GShow' (a :*: b) where
  gshows' (a :*: b) = gshows' a . showChar ' ' . gshows' b

-- |Our version of Show. with a default instance for Generic
class GShow a where
  gshows :: a -> ShowS
  default gshows :: (Generic a, GShow' (Rep a)) => a -> ShowS
  gshows = gshows' . from

-- |Generically show a value, equivalent to 'show'.
gshow :: GShow a => a -> String
gshow x = gshows x ""

instance GShow Int where
  gshows = shows

instance GShow String where
  gshows = shows

instance GRead Int where
  greadp = readS_to_P reads

instance GRead String where
  greadp = readS_to_P reads

class GRead' rep where
  greadp' :: ReadP (rep a)

-- |Constructors without fields: U1 there is nothing to parse
instance GRead' U1 where
  greadp' = pure U1

-- Constants and recursion.
-- 'greadp' is defined in terms of 'greadp''.
instance GRead c => GRead' (K1 i c) where
  greadp' = K1 <$> greadp

-- |Parse the symbol between two parentheses.
parens = between (char '(') (char ')')

-- |We extract the name of the data constructor
instance (GRead' a, Constructor c) => GRead' (M1 C c a) where
  -- we use scoped variables here such that we can get the conName
  -- out of the type.
  greadp' =
    let name = conName (undefined :: M1 C c a p)
    in M1 <$> parens (string name *> char ' ' *> greadp')

-- | Reading a field is trivial
instance (GRead' a, Selector s) => GRead' (M1 S s a) where
  greadp' = M1 <$> greadp'

-- | We discard the type constructor name
instance GRead' a => GRead' (M1 D d a) where
  greadp' = M1 <$> greadp'

-- | We either read an InR of an InL of the coproduct
instance (GRead' a, GRead' b) => GRead' (a :+: b) where
  greadp' =   L1 <$> greadp'
         <|>  R1 <$> greadp'

-- | We read both components of the product separated by a space
instance (GRead' a, GRead' b) => GRead' (a :*: b) where
  greadp' = (:*:) <$> greadp' <*> (char ' ' *> greadp')

-- |A value that can be read from a string, the equivalent of 'Read'.
-- Class for plumbing the 'GRead'' through our data types.
class GRead a where
  greadp :: ReadP a
  default greadp :: (Generic a, GRead' (Rep a)) => ReadP a
  greadp = to <$> greadp'

-- | See 'reads'
greads :: GRead a => ReadS a
greads = readP_to_S greadp

-- | See 'readEither'
greadEither :: GRead a => String -> Either String a
greadEither s =
  case [ x | (x,"") <- greads s ] of
    [x] -> Right x
    []  -> Left "Prelude.read: no parse"
    _   -> Left "Prelude.read: ambiguous parse"

-- |The function we really wanted to define: read a 'String' into a generic value.
gread :: GRead a => String -> a
gread s = either error id (greadEither s)
