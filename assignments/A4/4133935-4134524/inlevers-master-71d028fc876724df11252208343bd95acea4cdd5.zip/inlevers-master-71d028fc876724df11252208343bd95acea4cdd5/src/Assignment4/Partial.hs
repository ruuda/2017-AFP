-- |Our solution to exercise 2.2.6.
module Assignment4.Partial where

import Control.Applicative
import Control.Monad

-- |Can be used to describe possibly nonterminating computations in such a way
-- that they remain productive.
data Partial a
  = Now a
    -- ^The result has been found.
  | Later (Partial a)
    -- ^Insufficient data for meaningful answer.
  deriving (Show, Eq)

-- |Run a partial computation a number of steps.
-- (That is: remove @n@ layers of 'Later' from this computation.)
-- If there are still more 'Later's around this answer, returns 'Nothing'.
runPartial :: Int -> Partial a -> Maybe a
runPartial _ (Now x) = Just x
runPartial 0 (Later p) = Nothing
runPartial n (Later p) = runPartial (n-1) p

-- |An unsafe variant of 'runPartial' which diverges when the 'Later's
-- are nested infinitely deep.
unsafeRunPartial :: Partial a -> a
unsafeRunPartial (Now x) = x
unsafeRunPartial (Later p) = unsafeRunPartial p

-- |Perfom the function "instantly".
instance Functor Partial where
  fmap f (Now a) = Now (f a)
  fmap f (Later later) = Later (fmap f later)

-- |Basically just strict application of functions.
instance Applicative Partial where
  pure = Now
  -- First, let's fully evaluate the function.
  (Later f) <*> x = Later (f <*> x)
  -- Now fully evaluate the right hand side.
  (Now f) <*> (Later later) = Later (f <$> later)
  -- When we're done, simply apply the function.
  (Now f) <*> (Now now) = Now (f now)

-- |A left-biased choice for the first partial function that terminates.
instance Alternative Partial where
  empty = Later empty
  (Now x)   <|> _         = Now x
  -- bias to the left: pattern-matching q is also a computation step
  (Later p) <|> q = Later $ case q of
    Now q -> Now q
    Later q -> p <|> q

-- |Evaluate the argument before evaluating the function.
instance Monad Partial where
  Later p >>= f = Later (p >>= f)
  Now x >>= f = f x

-- |Exactly the same as the 'Alternative' instance.
instance MonadPlus Partial where
  mzero = empty
  mplus = (<|>)

-- |A computation that takes one unit of time.
tick :: Partial ()
tick = Later (Now ())

-- |Add all the values in the list, taking a tick per value in the list.
psum :: [Int] -> Partial Int
psum xs = sum <$> mapM (\x -> tick >> pure x) xs

-- |Take the first sum in the list that terminates.
firstsum :: [[Int]] -> Partial Int
firstsum = foldr (mplus . psum) mzero
