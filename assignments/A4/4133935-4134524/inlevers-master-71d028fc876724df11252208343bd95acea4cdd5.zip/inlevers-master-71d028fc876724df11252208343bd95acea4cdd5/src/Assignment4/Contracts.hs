{-# LANGUAGE GADTs, KindSignatures #-}
-- |Our solution to exercise 2.6.1.
module Assignment4.Contracts where

-- |From the exercise.
data Contract :: * -> * where
  Pred :: (a -> Bool) -> Contract a
    -- ^Predicate on arbitrary types.
  DFun :: Contract a -> (a -> Contract b) -> Contract (a -> b)
    -- ^Pre- and postcondition on functions.
  List :: Contract a -> Contract [a]
    -- ^Requires that the contract holds on each element of the list.

-- |From the exercise.
-- Causes a run-time failure if a contract is violated.
assert :: Contract a -> a -> a
assert (Pred p) x = if p x then x else error "contract violation"
assert (DFun pre post) f = \x -> assert (post x) $ f $ assert pre x
assert (List c) xs = map (assert c) xs

-- |From the exercise.
-- Asserts a value is positive.
pos :: (Num a, Ord a) => Contract a
pos = Pred (>0)

-- |Doesn't assert anything.
-- See Contracts.idr for the proof that asserting this is the identity operation.
true :: Contract a
true = Pred (const True)

-- |Reexpresses the behaviour of the old @Fun@ constructor in terms of
-- the new and more general one.
(-|>) :: Contract a -> Contract b -> Contract (a -> b)
pre -|> post = DFun pre (const post)

-- |Index a list using contracts.
-- Checks if the integer is a valid index for the given list.
index :: Eq a => Contract ([a] -> Int -> a)
index = DFun true $ \list -> DFun (Pred $ \n -> 0 <= n && n < length list) $ const true

-- |Asserts that a function preserves the given property.
preserves :: Eq b => (a -> b) -> Contract (a -> a)
preserves p = DFun true $ \x -> Pred $ \fx -> p x == p fx

-- |From the exercise.
preservesPos, preservesPos' :: (Num a, Ord a) => Contract (a -> a)
preservesPos  = preserves (>0)
preservesPos' = pos -|> pos

-- preservesPos' is different from preservesPos:
-- it asserts both the input value and output value are always positive,
-- while preservesPos doesn't require the input value to be positive,
-- and only requirs the output value to be positive when the input is.
-- For example:
-- assert preservesPos (+1) (-2) == -1
-- assert preservesPos' (+1) (-2) == _|_

-- |From the exercise.
allPos, allPos' :: (Num a, Ord a) => Contract [a]
allPos  = List pos
allPos' = Pred (all (>0))
-- The difference between these contracts is evaluation order:
-- before you can evaluate a list with allPos' (or any Pred-based list contract),
-- it must have validated all the elements of the list,
-- while allPos only validates the contract on the elements of the list
-- that really need to be evaluated.
-- So using allPos' on a non-terminating list (or containing non-terminating values,
-- or containing non-conforming values) makes your whole contract non-terminating,
-- while it's possible to use allPos on such lists.
--
-- For example, take 5 $ assert (allPos -|> allPos) (map (+1)) [10, 9 ..]
--  == [11, 10, 9, 8, 7]
-- but take 5 $ assert (allPos' -|> allPos') (map (+1)) [10, 9 ..] fails.
-- and take 5 $ assert (allPos -|> allPos) (map (+1)) [1, 2 ..] == [2, 3, 4, 5, 6]
-- but take 5 $ assert (allPos' -|> allPos') (map (+1)) [1, 2 ..] runs forever.
