-- |Our solution to exercise 2.10.5 - 2.10.7
module Assignment4.UnsafeIO where

import Data.IORef
import System.IO.Unsafe

-- |Perform one step of the running total program.
-- Given a reference to the total,
-- returns Right total if the input is 0,
-- adds to the total and returns Left total otherwise.
runTotal :: IORef Int -> Int -> IO (Either Int Int)
runTotal totalRef 0 = do
  total <- readIORef totalRef
  pure $ Right total
runTotal totalRef n = do
  -- Use strict modification since (+) is strict anyway.
  modifyIORef' totalRef (+n)
  newTotal <- readIORef totalRef
  pure $ Left newTotal

-- |A running total program, like the one in exercise 2.2.8.
-- Reads integers from stdin,
-- if it's equal to 0, return the total and stop;
-- otherwise add to total, write new total and repeat.
runningTotal :: IO Int
runningTotal = newIORef 0 >>= runningTotal'
  where
  runningTotal' :: IORef Int -> IO Int
  runningTotal' totalRef = do
    n <- readLn
    intermediate <- runTotal totalRef n
    case intermediate of
      Left total -> do
        print total
        runningTotal' totalRef
      Right result -> pure result

-- |A reference to some value of arbitrary type.
-- As all the terrifying names in the function definition imply,
-- this function is really dangerous.
anything :: IORef a
anything = unsafePerformIO $ newIORef undefined

-- |Interpret Haskell's representation of some value of type a
-- as a value of type b. This is incredibly dangerous and causes segfaults.
coerce :: a -> b
coerce x = unsafePerformIO $ do
  writeIORef anything x
  readIORef anything
