-- |Our solution to Exercise 2.2.5.
module Assignment1.Count where

-- |The type class that contains 'count' and 'countZero'.
-- Since 'count == 0' and 'count 1 2 3 == 3', we need some type class.
-- The cleverness really is in choosing the 'a' to instantiate 'Countable'.
class Countable a where
  -- |Give the number of arguments passed to 'count'.
  -- (In general, you will need to write 'count x y :: Int' to get an answer.)
  count :: a
  -- |Accept an arbitrary amount of arguments and return 0.
  -- (Again, you will need type hinting to fully make use of it.)
  countZero :: a
  -- |An internal method used by 'count' whenever it detects a new argument.
  -- You can't just write '\x -> count + 1' because 'a -> b' is not a 'Num'.
  -- In general, you will want to implement this only in the base instances,
  -- and any inductive instances can just call the base ones.
  -- This setup will allow you to write instances for e.g. 'Float'
  -- and not worry about those cases in the instances for 'a -> b'.
  incr :: a -> a

-- |It's easy to count zero arguments, just return zero.
instance Countable Int where
  countZero = 0
  count = 0
  incr x = x + 1 -- This is the base case for 'incr' as described in Countable.

-- |Count an additional argument compared to the base instance.
instance Countable b => Countable (a -> b) where
  -- This is the instance where all the magic happens.
  -- Since the '->' operator associates to the right, we want the 'count' in
  -- 'count 1 2 3' to have a type 'a -> (b -> (c -> Int))'.
  -- You should see that the following instance is a good choice for that case.

  -- Just discard all arguments until you arrive at countZero :: Int.
  countZero = const countZero

  -- But to really count the arguments, discard the first argument,
  -- count the remaining arguments and increment that number by one.
  -- (Note that you could also write this as 'count = const $ incr count',
  -- which you can see by applying the definition of 'incr'.)
  count = incr $ const count

  -- Descend the inductive definitions until you reach 'Int'.
  -- Expanding the types gives 'incr :: Countable b => (a -> b) -> a -> b',
  -- so to avoid trivial implementations, we really want to use
  -- the 'incr :: Countable b => b -> b' somewhere. Just follow the types
  -- to arrive at the following definition:
  incr f x = incr $ f x -- (More unreadably: 'incr = (incr .)'.)
  -- Note: because we apply 'incr' to 'const count' here, the 'x' is just
  -- something to pass through the types, not a useful argument.
