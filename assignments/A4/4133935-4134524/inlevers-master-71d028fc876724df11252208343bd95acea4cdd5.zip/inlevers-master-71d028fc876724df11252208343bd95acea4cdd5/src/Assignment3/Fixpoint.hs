{-# LANGUAGE LambdaCase #-}
module Assignment3.Fixpoint where

import Prelude hiding (foldr)
import Data.Function (fix)

-- |The canonical list catamorphism.
-- Uses a fixpoint combinator instead of explicit recursion.
foldr :: (a -> b -> b) -> b -> [a] -> b
foldr f e = fix $ \foldr' -> \case
    [] -> e
    (x:xs) -> x `f` foldr' xs
