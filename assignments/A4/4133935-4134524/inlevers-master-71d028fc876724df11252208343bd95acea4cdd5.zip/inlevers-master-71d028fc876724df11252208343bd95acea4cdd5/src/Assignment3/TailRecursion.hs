module Assignment3.TailRecursion where

import Data.Function (fix)

-- |Leaf-labelled binary trees
data Tree a = Leaf a | Node (Tree a) (Tree a)
    deriving (Eq, Show)

-- |Splits off the leftmost entry of the tree and returns that entry
-- as well as the remaining tree.
splitleft, splitleft' :: Tree a -> (a, Maybe (Tree a))
-- |Non tail-recursive edition of 'splitleft'.
splitleft (Leaf a) = (a, Nothing)
splitleft (Node l r) = case splitleft l of
  (a, Nothing) -> (a, Just r)
  (a, Just l') -> (a, Just (Node l' r))

-- |Tail-recursive edition of 'splitleft'.
splitleft' = splitleft'' id
  where
  -- Given a function that adds all the missing right children to a subtree,
  -- split off the leftmost entry of a given tree and add back the children.
  splitleft'' :: ((a, Maybe (Tree a)) -> (a, Maybe (Tree a))) ->
    Tree a -> (a, Maybe (Tree a))
  splitleft'' acc (Leaf a) = acc (a, Nothing)
  splitleft'' acc (Node l r) = splitleft'' (acc . addRight r) l

  -- Add the given tree as a right child of the tree.
  -- (If there is no left child, the right child is just the tree.)
  addRight :: Tree a -> (a, Maybe (Tree a)) -> (a, Maybe (Tree a))
  addRight r (x, Nothing) = (x, Just r)
  addRight r (x, Just l) = (x, Just (Node l r))
