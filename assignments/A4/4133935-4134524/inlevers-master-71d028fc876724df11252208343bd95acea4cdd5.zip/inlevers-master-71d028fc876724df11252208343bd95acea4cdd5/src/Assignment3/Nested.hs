{-# LANGUAGE FlexibleInstances, RankNTypes, TypeSynonymInstances #-}
-- |Our solutions to exercise 2.4.1 - 2.4.3.
module Assignment3.Nested where

-- |A recursive type of functions that look like '... -> a -> a -> a'
-- Used to replace value-level recursion with type-level recursion.
data F a = F { unF :: F a -> a }

-- |The Y combinator, expressed in Haskell.
-- Applies a function repeatedly to its own output, producing 'f $ f $ f $ ...'.
-- Note that this has no type in the λ-calculus (as it does not terminate),
-- but Haskell has a more advanced type system which does allow us to type it.
-- This also breaks some assumptions GHC makes, see below.
-- Eta-reducing after discarding 'F' and 'unF' should give the original definition.
y :: (a -> a) -> a
y f = xRedex (F xRedex)
    where
    -- Some extremely fragile hackery to not trigger a GHC bug.
    -- basically, GHC doesn't realize it will keep on inlining this 'xRedex'
    -- because it's not explicitly recursive.
    -- See also https://ghc.haskell.org/trac/ghc/ticket/5448
    -- (note that you can manually inline this expression to get the "official" form)
    {-# NOINLINE xRedex #-}
    xRedex x = f (unF x x)

-- |The type of finite square matrices.
type Square = Square' Nil
-- |The type of square cons-lists whose final element is some given other type.
data Square' t a = Zero (t (t a)) | Succ (Square' (Cons t) a)
-- |The empty cons-list at type level.
data Nil a = Nil
-- |The cons constructor of cons-lists at type level.
data Cons t a = Cons a (t a)

-- Make the 'Cons' function work more like list '(:)' consing.
infixr 5 `Cons`

-- |Two example square matrices.
matrix1, matrix2 :: Square Int
matrix1 = Succ $ Succ $ Zero $
    (1 `Cons` 0 `Cons` Nil) `Cons`
    (0 `Cons` 1 `Cons` Nil) `Cons`
    Nil
matrix2 = Succ $ Succ $ Succ $ Zero $
    (1 `Cons` 2 `Cons` 3 `Cons` Nil) `Cons`
    (4 `Cons` 5 `Cons` 6 `Cons` Nil) `Cons`
    (7 `Cons` 8 `Cons` 9 `Cons` Nil) `Cons`
    Nil

-- |From the exercise:
-- Decide whether two instances of 'Nil' are equal.
eqNil :: (a -> a -> Bool) -> Nil a -> Nil a -> Bool
eqNil eqA Nil Nil = True

-- |From the exercise:
-- Decide whether two instances of 'Cons' are equal.
--
-- Just deleting the string "forall b . " from the type gives a unification error,
-- since the variables a and b can be instantiated differently
-- according to the type, but not according to the code.
-- However, when we replace all instances of b with a and remove the forall,
-- then the function typechecks: we only use eqT to lift eqA.
-- We can't get rid of the forall in all types, since moving it out of the (->)
-- would turn it into an exists, which doesn't really exist in Haskell.
eqCons :: (forall b . (b -> b -> Bool) -> t b -> t b -> Bool)
    -> (a -> a -> Bool) -> Cons t a -> Cons t a -> Bool
eqCons eqT eqA (Cons x xs) (Cons y ys) = eqA x y && eqT eqA xs ys

-- |From the exercise:
-- Decide whether two instances of 'Square'' are equal.
--
-- In this case we can't get rid of the quantifier: eqT is used in two ways,
-- both to lift (a -> a -> Bool) to (t a -> t a -> Bool) and to lift
-- (t a -> t a -> Bool) to (t (t a) -> t (t a) -> Bool) for the same variable a.
eqSquare' :: (forall b . (b -> b -> Bool) -> t b -> t b -> Bool)
    -> (a -> a -> Bool) -> Square' t a -> Square' t a -> Bool
eqSquare' eqT eqA (Zero xs) (Zero ys) = eqT (eqT eqA) xs ys
eqSquare' eqT eqA (Succ xs) (Succ ys) = eqSquare' (eqCons eqT) eqA xs ys
eqSquare' eqT eqA _ _                 = False

-- |From the exercise:
-- Decide whether two instances of 'Square'' are equal.
eqSquare :: (a -> a -> Bool) -> Square a -> Square a -> Bool
eqSquare = eqSquare' eqNil

-- |From the exercise:
-- Use 'eqSquare' to compare equality of square matrices.
instance Eq a => Eq (Square a) where
    (==) = eqSquare (==)

-- *Our own code

-- |The 'Nil' instance for 'fmap'.
fmapNil :: (a -> b) -> Nil a -> Nil b
fmapNil f Nil = Nil
-- |Convert a 'Functor f' instance to a 'Functor (Nil . f)' instance.
-- Used to apply 'fmap' to recursive data types.
-- We need both a fmap and a lift since 'Cons' has an unlifted and a lifted
-- value inside it, and the base case has no functors around it at all.
-- In the 'Eq' case, everything was just 'Bool's so no lifting was needed.
liftNil :: ((a -> b) -> f a -> f b) -> (a -> b) -> Nil (f a) -> Nil (f b)
liftNil fmapF f Nil = Nil

-- |The 'Cons' instance for 'fmap'.
-- |Note how this looks very similar to 'Data.List.map' but without recursion.
fmapCons :: ((a -> b) -> t a -> t b) -> (a -> b) -> Cons t a -> Cons t b
fmapCons fmapT f (Cons x gx) = f x `Cons` fmapT f gx
-- |Lift a lifted function another 'Cons' step.
liftCons :: (forall s. ((a -> b) -> s a -> s b) -> (a -> b) -> t (s a) -> t (s b)) ->
    ((a -> b) -> s a -> s b) -> (a -> b) -> Cons t (s a) -> Cons t (s b)
liftCons liftT fmapT f (Cons x gx) = Cons (fmapT f x) (liftT fmapT f gx)

-- |Apply a lifted function if this 'Square'' is 'Zero',
-- or lift it another step if it's 'Succ'.
liftSquare' :: (forall s. ((a -> b) -> s a -> s b) -> (a -> b) -> t (s a) -> t (s b)) ->
    ((a -> b) -> t a -> t b) -> (a -> b) -> Square' t a -> Square' t b
liftSquare' liftT fmapT f (Zero gx) = Zero (liftT fmapT f gx)
liftSquare' liftT fmapT f (Succ gx) = Succ (liftSquare' (liftCons liftT) (fmapCons fmapT) f gx)

-- |Implement 'fmap' by lifting the 'Nil' functor a couple of times.
fmapSquare :: (a -> b) -> Square a -> Square b
fmapSquare = liftSquare' liftNil fmapNil

-- |Use 'fmapSquare' to define an endofunctor on Hask.
instance Functor Square where
    fmap = fmapSquare
