-- |Our solution to exercise 2.2.9.
module Assignment2.Stacks where

-- |Start a stack computation with an empty stack.
start :: (() -> comp) -> comp
start f = f ()
-- |Finish a stack based computation that left exactly one value on the stack.
stop :: (tos, ()) -> tos
stop = fst

-- |Store a new value on top of the stack, then continue the computation.
store :: stack -> tos -> ((tos, stack) -> comp) -> comp
store stack tos f = f (tos, stack)

add, mul :: Num tos => (tos, (tos, stack)) -> ((tos, stack) -> comp) -> comp
-- |Pop two values and push their sum, then continue the computation.
add (x, (y, xs)) f = f (x + y, xs)
-- |Pop two values and push their product, then continue the computation.
mul (x, (y, xs)) f = f (x * y, xs)
