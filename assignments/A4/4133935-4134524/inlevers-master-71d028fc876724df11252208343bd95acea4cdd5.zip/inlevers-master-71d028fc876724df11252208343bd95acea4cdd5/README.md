# Inlevers

All the inleveropgaven of Arian (4133935) and Tim (4134524). See `src/Assignment1` for the code solutions to the first assignment, and `doc/Assignment1` for the non-code solutions to the first assignment. You can hopefully guess the pattern for the next assignments.

# Setup

```
stack setup
stack build
stack test # run all the unit tests
```

# Set 1
* 2.1.1 (20%) - Cabal
  See [./inlevers.cabal](./inlevers.cabal)
* 2.2.2 (20%) - Unfold
  See [./src/Assignment1/Unfold.hs](./src/Assignment1/Unfold.hs)
  and [./test/Assignment1/UnfoldSpec.hs](./test/Assignment1/UnfoldSpec.hs)
* 2.2.5 (15%) - Count
  See [./src/Assignment1/Count.hs](./src/Assignment1/Count.hs)
  and [./test/Assignment1/CountSpec.hs](./test/Assignment1/CountSpec.hs)
* 2.7.1 (20%) - Permutations
  See [./src/Assignment1/Permutations.hs](./src/Assignment1/Permutations.hs)
  and [./test/Assignment1/PermutationsSpec.hs](./test/Assignment1/PermutationsSpec.hs)
* 2.9.1 (25%) - Proofs
  See [./doc/Reasoning.pdf](./doc/Reasoning.pdf) for Equational Reasonsing proof.
  See [./doc/Reasoning.tex](./doc/Reasoning.tex) for the LaTeX source files of this proof.
  See [./src/Assignment1/Reasoning.idr](./src/Assignment1/Reasoning.idr) for the Equational Reasoning
  proof implemented in the proof-assistent Idris.

# Set 2
* 2.3 (35%) - Monads
  See [./src/Assignment2/Monad.hs](./src/Assignment2/Monad.hs)
  and [./test/Assignment2/MonadSpec.hs](./src/Assignment2/MonadSpec.hs)
* 3.3.(3|4|5) (30%) - Foldable
  See [./src/Assignment2/Foldalbe.hs](./src/Assignment2/Foldable.hs)
  and [./test/Assignment2/FoldableSpec.hs](./test/Assignment2/FoldableSpec.hs)
* 2.2.8 (25%) - Teletype IO
  See [./src/Assignment2/Teletype.hs](./src/Assignment2/Teletype.hs)
  and [./test/Assignment2/TeletypeSpec.hs](./test/Assignment2/TeletypeSpec.hs)
* 2.2.9 (10%) - Stacks
  See [./src/Assignment2/Stacks.hs](./src/Assignment2/Stacks.hs)
  and [./test/Assignment2/StacksSpec.hs](./test/Assignment2/StacksSpec.hs)

# Set 3
* 2.2.1 - Tail Recursion
  See [./src/Assignment3/TailRecursion.hs](./src/Assignment3/TailRecursion.hs)
  and [./test/Assignment3/TailRecursionSpec.hs](./src/Assignment3/TailRecursionSpec.hs)
* 2.2.3 - Fixpoint
  See [./src/Assignment3/Fixpoint.hs](./src/Assignment3/Fixpoint.hs)
  and [./test/Assignment3/FixpointSpec.hs](./src/Assignment3/FixpointSpec.hs)
* 2.4 - Nested types
  See [./src/Assignment3/Nested.hs](./src/Assignment3/Nested.hs)
  and [./test/Assignment3/NestedSpec.hs](./src/Assignment3/NestedSpec.hs)
* 2.5.3 - Evidence translation
  See [./src/Assignment3/EvidenceTranslation.hs](./src/Assignment3/EvidenceTranslation.hs)
  and [./test/Assignment3/EvidenceTranslationSpec.hs](./test/Assignment3/EvidenceTranslationSpec.hs)
