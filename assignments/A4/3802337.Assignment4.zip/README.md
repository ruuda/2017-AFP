# Assignment 4 - Jasper Robeer (3802337)

The `src/Assignment4` and `src/Data` directories contain the Haskell code files for the assignments:

 * Exercise 2.10.5-2.10.7 (Unsafe IO): `Assignment4/UnsafeIO.hs`
 * Exercise 2.2.4 (Tries): `Data/Trie.hs`
 * Exercise 2.2.6 (Partiality Monad): `Assignment4/PartialComputation.hs`
 * Exercise 2.6.1 (Contracts): `Assignment4/Contracts.hs`

The `test/Assignment4` and `test/Data` directories contain unit tests and
QuickCheck tests for the exercises. The unit tests use [Hspec](http://hspec.github.io/).
The files containing the tests are named in line with the original code files.

## Running the assignments

The assignments are built using [Stack](https://www.haskellstack.org/). Run the
following commands to setup, build and test the assignments.

```
$ stack setup
$ stack build
$ stack test
```
