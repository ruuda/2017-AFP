{-# LANGUAGE GADTs, KindSignatures #-}

module Assignment4.Contracts where

{-- Exercise 2.6.1 --}

data Contract :: * -> * where
    Pred :: (a -> Bool) -> Contract a
    DFun :: Contract a -> (a -> Contract b) -> Contract (a -> b)
    List :: Contract a -> Contract [a]

-- | Assertion causes a run-time failure if the contract is violated.
assert :: Contract a -> a -> a
assert (Pred p)        x  = if p x then x else error "contract violation"
assert (DFun pre post) f  = \x -> (assert (post x) . f . assert pre) x
assert (List c)        xs = map (assert c) xs

-- | Contract which states that a number is positive.
pos :: (Num a, Ord a) => Contract a
pos = Pred (>0)

-- | Contract for which holds `assert true x == x`.
--
--   Proof:
--      assert true x
--    = (def. true)
--      assert (Pred (const True)) x
--    = (def. assert)
--      if (const True) x then x else error "contract violation"
--    = (def. const)
--      if True then x else error "contract violation"
--    =
--      x
true :: Contract a
true = Pred (const True)

-- | Combinator which re-expresses the behaviour of the 'old' Fun in terms of
--   the new and more general one: DFun.
(-->) :: Contract a -> Contract b -> Contract (a -> b)
pre --> post = DFun pre (const post)

-- | Contract which checks if an integer is a valid index for the given list.
index :: Contract ([a] -> Int -> a)
index = DFun true (\xs -> DFun true (\n -> Pred $ \_ -> 0 <= n && n < length xs))

-- | Contract which checks if the predicate holds for a value `x` before and
--   after applying a function to `x`.
--   Furthermore, `assert (preserves p) f x` fails if and only if `p x` differs
--   from `p (f x)`.
preserves :: (Eq b) => (a -> b) -> Contract (a -> a)
preserves p = DFun true (\x -> Pred (\y -> p x == p y))

-- | Is there a difference between `preservesPos` and `preservesPos'`?
--
--   Yes there is. `preservesPos'` requires both the pre-condition and post-
--   condition to be positive, whilst `preservePos` doesn't require the
--   pre-condition to be positive.
preservesPos  = preserves (>0)
preservesPos' = pos --> pos

-- | Is there a difference between `allPos` and `allPos'`?
--
--   Yes, there is. `allPos` lazily evaluates the list, where as `allPos'` has
--   to evaluate the condition for *all* elements in the list. Therefore, when
--   we look at the following example we can see how this affects us:
--      take 1 (assert allPos [1..]) == [1]
--      take 1 (assert allPos' [1..]) == ??
--   We cannot take any number of elements from the infinite list with `allPos'`.
allPos, allPos' :: (Num a, Ord a) => Contract [a]
allPos  = List pos
allPos' = Pred (all (>0))
