module Assignment4.UnsafeIO
    ( runningTotal
    , anything
    , cast
    ) where

import Data.IORef
import System.IO.Unsafe

{-- Exercise 2.10.5 --}

-- | Performs the running total program by passing around an `IORef` internally.
--   If the user enters a 0, the current total is printed.
runningTotal :: IO Int
runningTotal = newIORef 0 >>= runningTotal'

runningTotal' :: IORef Int -> IO Int
runningTotal' ref = do
    putStr "> "     -- Prompt to distinguish between input/output
    n  <- readLn
    n' <- updateRunningTotal ref n
    if n == 0
        then return n'
        else print n' >> runningTotal' ref

updateRunningTotal :: IORef Int -> Int -> IO Int
updateRunningTotal ref 0 = readIORef ref
updateRunningTotal ref n = modifyIORef' ref (+n) >> readIORef ref

{-- Exercise 2.10.6 --}

-- |
anything :: IORef a
anything = unsafePerformIO (newIORef undefined)

{-- Exercise 2.10.7 --}

-- |
cast :: a -> b
cast x = unsafePerformIO $ do
    writeIORef anything x
    readIORef anything
