module Assignment4.PartialComputation where

import Control.Monad
import Control.Applicative

{-- Exercise 2.2.6 --}

data Partial a = Now a
               | Later (Partial a)
               deriving Show

-- Instance required as superclass of `Monad Partial`.
instance Functor Partial where
    -- fmap :: (a -> b) -> Partial a -> Partial b
    fmap f (Now x)   = Now (f x)
    fmap f (Later p) = Later (fmap f p)

-- Instance required as superclass of `Monad Partial`.
instance Applicative Partial where
    -- pure :: a -> Partial a
    pure = Now

    -- (<*>) :: Partial (a -> b) -> Partial a -> Partial b
    (Now f)   <*> (Now x)   = Now (f x)
    (Now f)   <*> (Later p) = Later (fmap f p)
    (Later p) <*> q         = Later (p <*> q)

instance Monad Partial where
    -- return :: a -> Partial a
    return        = Now

    -- (>>=) :: Partial a -> (a -> Partial b) -> Partial b
    Now x   >>= f = f x
    Later p >>= f = Later (p >>= f)

-- Instance required as suoerclass of `MonadPlus Partial`.
instance Alternative Partial where
    empty = loop
    (<|>) = merge

-- Equivalent to `Alternative Partial`.
instance MonadPlus Partial where
    mzero = empty
    mplus = (<|>)

-- | A productive infinite loop.
loop :: Partial a
loop = Later loop

-- | Runs two computations in 'parallel', choosing the computation that returns
--   earlier.
merge :: Partial a -> Partial a -> Partial a
merge (Now x)   _ = Now x
merge (Later p) q = Later (f q)
    where f (Now x)   = Now x
          f (Later x) = merge p x 

-- | Runs a partial computation, given an upper-bound on the number of steps
--   it's allowed to perform.
runPartial :: Int -> Partial a -> Maybe a
runPartial _ (Now x)   = Just x
runPartial 0 (Later p) = Nothing
runPartial n (Later p) = runPartial (n-1) p

-- | Runs a partial computation with the risk of nontermination.
unsafeRunPartial :: Partial a -> a
unsafeRunPartial (Now x)   = x
unsafeRunPartial (Later p) = unsafeRunPartial p

-- | Introduces an explicit delay.
tick :: Partial ()
tick = Later (Now ())

-- | Computes the sum of a list of integers using the `Partial` computation
--   defined in this module.
psum :: [Int] -> Partial Int
psum xs = fmap sum (mapM (\x -> tick >> return x) xs)

-- | Performs `psum` on every list of integers and returns the result that can
--   be obtained with as few delays as possible.
firstsum :: [[Int]] -> Partial Int
firstsum = foldr (mplus . psum) mzero
