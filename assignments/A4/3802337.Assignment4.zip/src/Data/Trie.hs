module Data.Trie
    ( Trie(..)
    , empty
    , null
    , valid
    , insert
    , lookup
    , delete
    ) where

import Prelude hiding (null, lookup)
import Data.Map (Map)
import qualified Data.Map as Map

{-- Exercise 2.2.4 --}

data Trie a = Node (Maybe a) (Map Char (Trie a))
            deriving (Show, Eq)

-- | Represents an empty Trie.
empty :: Trie a
empty = Node Nothing Map.empty

-- | Returns True if a Trie is empty, False otherwise.
null :: Trie a -> Bool
null (Node Nothing m) = Map.null m
null _                = False

-- | Returns True if the invariant holds, False otherwise. The invariant is:
--   if a Trie (or sub-Trie) is empty, it should always be represented by
--      `Node Nothing Map.empty`
valid :: Trie a -> Bool
valid (Node _ m)  = Map.null m || Map.foldr (&&) True (Map.map valid m)

-- | Inserts the given string and value pair into a Trie.
insert :: String -> a -> Trie a -> Trie a
insert []     v (Node _ t)  = Node (Just v) t
insert (x:xs) v (Node v' m) = Node v' m'
    where m' = Map.insert x (insert xs v t') m
          t' = Map.findWithDefault empty x m

-- | Lookup the value of a string in the Trie. Returns `Just value` if the value
--   is found, or `Nothing` otherwise.
lookup :: String -> Trie a -> Maybe a
lookup [] (Node value _) = value
lookup (x:xs) (Node _ m) = do subTrie <- Map.lookup x m
                              lookup xs subTrie

-- | Delete a string from the Trie. If the string is not in the Trie, the original
--   Trie is returned.
--   To hold the invariant, we remove the values associated with the whole string
--   from the Trie, and then bottom-up delete the `null` nodes.
delete :: String -> Trie a -> Trie a
delete [] (Node _ m)         = Node Nothing m
delete (x:xs) (Node value m) = Node value (Map.update f x m)
    where f t = let t' = delete xs t
                in if null t' then Nothing else Just t'
