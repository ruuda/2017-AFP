module Assignment4.PartialComputationSpec where

import Test.Hspec
import Assignment4.PartialComputation

spec :: Spec
spec = do
    it "firstsum" $ do
        runPartial 100 (firstsum [repeat 1, [1,2,3], [4,5], [6,7,8], cycle [5,6]]) `shouldBe` Just 9
        runPartial 200 (firstsum (cycle [repeat 1, [1,2,3], [4,5], [6,7,8], cycle [5,6]])) `shouldBe` Just 9
        runPartial 200 (firstsum (replicate 100 (repeat 1) ++ [[1]] ++ repeat (repeat 1))) `shouldBe` Just 1
