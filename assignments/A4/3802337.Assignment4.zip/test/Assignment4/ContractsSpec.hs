module Assignment4.ContractsSpec where

import Test.Hspec
import Control.Exception (evaluate)
import Assignment4.Contracts

spec :: Spec
spec = do
    it "pos" $ do
        assert pos 1 `shouldBe` 1
        evaluate (assert pos 0) `shouldThrow` anyException

    it "true" $ do
        assert true 0 `shouldBe` 0
        assert true True `shouldBe` True

    it "index" $ do
        assert index (!!) [1..10] 0 `shouldBe` 1
        evaluate (assert index (!!) [1..10] 100) `shouldThrow` anyException

    it "preserves" $ do
        assert (preserves length) reverse  "Hello" `shouldBe` "olleH"
        assert (preserves length) (take 5) "Hello" `shouldBe` "Hello"
        evaluate (assert (preserves length) (take 5) "Hello world") `shouldThrow` anyException
