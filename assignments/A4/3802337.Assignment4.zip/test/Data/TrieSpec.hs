module Data.TrieSpec where

import Test.Hspec
import Data.Trie (Trie)
import qualified Data.Trie as Trie
import Data.Map (Map)
import qualified Data.Map as Map

example0 :: Trie Int
example0 = Trie.insert "f" 0 $ Trie.insert "foo" 1 $ Trie.insert "bar" 2 $ Trie.insert "baz" 3 Trie.empty

example1 :: Trie Int
example1 = Trie.Node Nothing (Map.fromList [('f',Trie.Node (Just 0) Map.empty)])

example2 :: Trie Int
example2 = Trie.Node Nothing (Map.fromList [
        ('f',Trie.Node (Just 0) (Map.fromList [
        ('o',Trie.Node Nothing (Map.fromList [
        ('o',Trie.Node (Just 1) Map.empty)]))]))
    ])

example3 :: Trie Int
example3 = Trie.insert "f" 0 $ Trie.insert "foo" 1 $ Trie.insert "baz" 3 Trie.empty

spec :: Spec
spec = do
    it "null" $ do
        Trie.null (Trie.empty :: Trie Int) `shouldBe` True
        Trie.null example0 `shouldBe` False

    it "valid" $ do
        Trie.valid (Trie.empty :: Trie Int) `shouldBe` True
        Trie.valid example0 `shouldBe` True
        Trie.valid example1 `shouldBe` True
        Trie.valid example2 `shouldBe` True

    it "insert" $ do
        Trie.insert "f" 0 Trie.empty `shouldBe` example1
        Trie.insert "foo" 1 example1 `shouldBe` example2

    it "lookup" $ do
        Trie.lookup "f" example0 `shouldBe` Just 0
        Trie.lookup "foo" example0 `shouldBe` Just 1
        Trie.lookup "bar" example0 `shouldBe` Just 2
        Trie.lookup "baz" example0 `shouldBe` Just 3
        Trie.lookup "b" example0 `shouldBe` Nothing

    it "delete" $ do
        Trie.delete "f" example1 `shouldBe` Trie.empty
        Trie.delete "bar" example0 `shouldBe` example3
