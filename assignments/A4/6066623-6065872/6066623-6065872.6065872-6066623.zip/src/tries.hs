module Data.Tries
  where

import Data.Map (Map)
import qualified Data.Map as Map
import Debug.Trace

data Trie a = Node (Maybe a) (Map Char (Trie a)) deriving (Eq, Show)

empty :: Trie a
empty = Node Nothing Map.empty

null :: Trie a -> Bool
null (Node Nothing map') = Map.null map'
null (Node (Just _) _ ) = False

valid :: Trie a -> Bool
valid _ = False

insert :: String -> a -> Trie a -> Trie a
insert [] n (Node _ map') = (Node (Just n) map')
insert (x:xs) n (Node mb map') = case Map.lookup x map' of
                                  --(Just a) -> trace("cont") (insert xs n a) --continue looking
                                  --(Nothing) -> trace("inserting") insert (x:xs) n (Node mb (Map.insert x empty map'))
                                  (Just a) -> (Node mb )
                                  (Nothing) ->

lookup' :: String -> Trie a -> Maybe a
lookup' [] (Node a _) = a
lookup' (x:xs) (Node _ map') = case Map.lookup x map' of
                                  (Just a) -> lookup' xs a
                                  Nothing -> Nothing

delete :: String -> Trie a -> Trie a
delete _ _ = empty

--let z = (Node (Just 1) [('b',(Node Nothing [('a',(Node Nothing [('j',(Node (Just 2) [()]))]))]) ), ('i',(Node (Just 3) []))])
