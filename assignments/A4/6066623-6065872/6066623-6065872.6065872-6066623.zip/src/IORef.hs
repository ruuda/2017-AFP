
import Data.IORef
import System.IO.Unsafe
import System.IO
import Debug.Trace


-- Exercise 2.10.5
readInt :: IO Int
readInt = do
        trace "china" putStr("?")
        hFlush stdout
        readLn

{-- 
running :: IORef Int -> IORef Int
running x = let
                theint  = trace "banana" unsafePerformIO $ readInt
                sum = trace "what the actual fuck" unsafePerformIO $ newIORef (theint + (unsafePerformIO (readIORef x)))
                in running sum

--}

run :: IORef Int -> IO Int
run num = do
         int <- readInt
         run $ newIORef  
         

-- Exercise 2.10.6
data Anything a = IORef a

-- Exercise 2.10.7


