module UnsafeIO where

import Data.IORef
import System.IO.Unsafe

-- 2.10.5
runningTotalMain :: IO ()
runningTotalMain = do
    total <- newIORef 0
    sequence_ . repeat $ iterate total
    where
    iterate :: IORef Int -> IO ()
    iterate total = do
        x <- readIORef total
        putStrLn $ "Current running total is " ++ show x
        putStr "Enter a number: "
        newNumber <- readLn
        modifyIORef' total (+ newNumber)

-- 2.10.6
-- Note: using head on an empty list is not a problem here. We never read the value
-- returned by head, and lazy evaluation ensures our program won't crash.
anything :: IORef a
anything = unsafePerformIO $ head <$> readIORef anyXs >>= newIORef
    where
    anyXs :: IORef [a]
    anyXs = unsafePerformIO $ newIORef []

-- 2.10.7
cast :: a -> b
cast a = unsafePerformIO $ do
    writeIORef anything a
    readIORef anything

-- Bonus: segmentation fault
-- We follow the classical and reliable approach of dereferencing a null pointer
segFault :: Int
segFault = let nullPointer = cast 0 :: IORef Int
           in unsafePerformIO $ readIORef nullPointer
