module PartialityMonad where
import Control.Applicative
import Control.Monad

data Partial a = Now a | Later (Partial a) deriving Show

-- We need Functor and Applicative instances for Monad
instance Functor Partial where
  fmap = liftM

instance Applicative Partial where
  pure  = return
  (<*>) = ap

instance Monad Partial where
    return          = Now
    Now x >>= f     = f x
    Later p >>= f   = Later (p >>= f)

-- We need an Alternative instance for MonadPlus
instance Alternative Partial where
    empty = mzero
    (<|>) = mplus

instance MonadPlus Partial where
    mzero = loop
    mplus = merge

-- Modified version of merge, so it is unfair. This allows resolving partials
-- contained in infinite lists.
merge :: Partial a -> Partial a -> Partial a
merge p q = fairMerge p $ tick >> q

-- This merge function gives the same priority to both partials
fairMerge :: Partial a -> Partial a -> Partial a
fairMerge (Now x)   _           = Now x
fairMerge _         (Now x)     = Now x
fairMerge (Later p) (Later q)   = Later (fairMerge p q)

runPartial :: Int -> Partial a -> Maybe a
runPartial _ (Now x)    = Just x
runPartial 0 (Later p)  = Nothing
runPartial n (Later p)  = runPartial (n - 1) p

unsafeRunPartial :: Partial a -> a
unsafeRunPartial (Now x)    = x
unsafeRunPartial (Later p)  = unsafeRunPartial p

loop :: Partial a
loop = Later loop

tick :: Partial ()
tick = Later (Now ())

psum :: [Int] -> Partial Int
psum xs = fmap sum (mapM (\x->tick>>return x) xs)

-- Take the psum of each sub list and return a partial result that will
-- resolve to the first psum that is finished computing
firstsum :: [[Int]] -> Partial Int
firstsum = msum . map psum
