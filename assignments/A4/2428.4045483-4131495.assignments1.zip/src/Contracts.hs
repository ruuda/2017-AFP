{-# LANGUAGE KindSignatures #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE RankNTypes #-}

module Contracts where

data Contract :: * -> * where
    Pred :: (a -> Bool) -> Contract a
    --Fun  :: Contract a -> Contract b -> Contract (a -> b)
    DFun :: Contract a -> (a -> Contract b) -> Contract (a -> b)
    List :: Contract a -> Contract [a]

assert :: Contract a -> a -> a
assert (Pred p)         x = if p x then x else error "contract violation"
--assert (Fun pre post) f = assert post . f . assert pre
assert (DFun pre post)  f = \x -> assert (post x) $ f $ assert pre x
assert (List c) xs = map (assert c) xs

(-->) :: Contract a -> Contract b -> Contract (a -> b)
(-->) a b = DFun a (const b)

-- assert pos 2 => 2
-- assert pos 0 => error
pos :: (Num a, Ord a) => Contract a
pos = Pred (>0)

true :: forall a . Contract a
true = Pred (const True)

{- Proof

assert true x = x
assert (Pred (const True)) x = x
if (const True) x then x else error "contract violation" = x
if True then x else error "contract violation" = x
x = x

-}

-- assert index (!!) [42] 0 => 42
-- assert index (!!) [] 0 => error "contract violation"
listIndex :: Contract ([a] -> Int -> a)
listIndex = DFun listNotNull (\xs -> indexBounds xs --> true)
    where
    listNotNull :: Contract [a]
    listNotNull = Pred (not . null)
    indexBounds :: [a] -> Contract Int
    indexBounds xs = Pred (length xs >)

-- assert (preserves length) reverse "Hello" => "olleH"
-- assert (preserves length) (take 5) "Hello" => "Hello"
-- assert (preserves length) (take 1) "Hello" => error "contract violation"
preserves :: Eq b => (a -> b) -> Contract (a -> a)
preserves fun = DFun true (\x -> Pred (\y -> fun x == fun y))

preservesPos, preservesPos' :: (Num a, Ord a) => Contract (a -> a)
preservesPos = preserves (>0)
preservesPos' = pos --> pos

{-

There is a difference between both implementations:

assert preservesPos (+1) (-2) = -1
assert preservesPos' (+1) (-2) = error "contract violation"

By replacing definitions and eta-reducing we can see the difference:

assert preservesPos f
= assert (preserves (> 0)) f
= assert (DFun true (\x -> Pred (\y -> x > 0 == y > 0))) f
= \x -> assert (Pred (\y -> x > 0 == y > 0)) $ f $ assert true x
= \x -> assert (Pred (\y -> x > 0 == y > 0)) $ f x
= \x -> if x > 0 == f x > 0 then x else error "contract violation"

assert preservesPos' f
= assert (pos --> pos) f
= assert (Pred (> 0) --> Pred (> 0)) f
= assert (DFun (Pred > 0) (const (Pred (> 0)))) f
= \x -> assert (Pred (> 0)) $ f $ assert (Pred > 0) x
= \x -> assert (Pred (> 0)) $ f (if x > 0 then x else error "contract violation")
= \x -> if f (if x > 0 then x else error "contract violation") > 0
        then f (if x > 0 then x else error "contract violation")
        else error "contract violation"

-}

allPos, allPos' :: (Num a, Ord a) => Contract [a]
allPos = List pos
allPos' = Pred (all (>0))

{- Differences between allPos and allPos'

allPos:
* Gives extra information to the implementation, since the type tells us that the predicate operates on a list
* Can be safely applied to infinite lists thanks to lazy evaluation (this can be especially useful when usin this as a building block for other contracts that don't need to evaluate the whole list)
* The elements of the list are reduced on a case-by-case basis, upon need

allPos':
* Cannot be applied to infinite lists, since we are using `all` (this would result in an infinite loop)
* Since we are using `all`, the first time an element of the list is queried, every element in the list will be reduced until the predicate can be checked

---

Semantics

assert allPos xs
= assert (List pos) xs
= map (assert pos) xs
= map (\x -> if x > 0 then x else error "contract violation") xs

assert allPos' xs
= assert (Pred (all (> 0))) xs
= if all (> 0) xs then xs else error "contract violation"

-}