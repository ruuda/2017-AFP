module Tries where

import Data.Maybe
import Data.Map.Strict as M

data Trie a = Node (Maybe a) (Map Char (Trie a)) deriving Show

-- The empty trie
empty :: Trie a
empty = Node Nothing M.empty

-- Returns true if the trie is empty
null :: Trie a -> Bool
null (Node Nothing empty)   = M.null empty
null _                      = False

-- Check the trie invariant
valid :: Trie a -> Bool
valid = valid' True
    where valid' bool trie@(Node stored tries)
            | M.null tries      = bool || isJust stored
            | otherwise         = M.foldr (\t b -> b && valid' False t) True tries

-- Insert a value in the trie
insert :: String -> a -> Trie a -> Trie a
insert []       value (Node _ tries)        = Node (Just value) tries
insert (k:key)  value (Node stored tries)   = case M.lookup k tries of
                                                Just trie   ->  let newtrie = Tries.insert key value trie in
                                                                let newtries = M.insert k newtrie tries in
                                                                    Node stored newtries
                                                Nothing     ->  let newtrie = Tries.insert key value Tries.empty in
                                                                let newtries = M.insert k newtrie tries in
                                                                    Node stored newtries

-- Lookup a value in the trie
lookup :: String -> Trie a -> Maybe a
lookup [] (Node stored _)       = stored
lookup (k:key) (Node _ tries)   = case M.lookup k tries of
                                    Just trie   -> Tries.lookup key trie
                                    Nothing     -> Nothing

-- Delete the key in the trie
delete :: String -> Trie a -> Trie a
delete key trie = fromMaybe Tries.empty $ delete' key trie
    where delete' :: String -> Trie a -> Maybe (Trie a)
          delete' [] (Node _ tries)
            | M.null tries  = Nothing
            | otherwise     = Just $ Node Nothing tries
          delete' (k:key) trie@(Node stored tries) =
                case M.lookup k tries of
                      Just trie   -> do
                            newtrie <- delete' key trie
                            let newtries = M.insert k newtrie tries
                            return $ Node stored newtries
                      Nothing     ->  Just trie
