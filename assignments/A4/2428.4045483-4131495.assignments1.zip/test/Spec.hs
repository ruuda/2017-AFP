import Prelude hiding (allPos)
import Test.QuickCheck
import Data.Maybe
import qualified Data.Map.Strict as M

import qualified Contracts as C
import qualified Tries as T
import qualified PartialityMonad as P

main :: IO ()
main = do
    --- Tries
    quickCheck testEmptyNull
    quickCheck testInsertValid
    quickCheck testDeleteValid
    quickCheck testLookup
    quickCheck testDelete
    --- Contracts
    quickCheck testPos
    quickCheck testTrue
    quickCheck testAddOne
    quickCheck testListIndex
    quickCheck testPreservesLengthReverse
    quickCheck testPreservesLengthTake
    quickCheck $ expectFailure testPreservesLengthCrash
    quickCheck preservePos
    quickCheck allPos
    --- PartialityMonad
    quickCheck testMerge1
    quickCheck testMerge2
    quickCheck testRunPartial

--- Trie test functies ---
testEmptyNull :: Bool
testEmptyNull = T.null T.empty

testInsertValid :: [(String,Int)] -> Bool
testInsertValid list = T.valid $ trieFromList list

testDeleteValid :: [(String,Int)] -> Bool
testDeleteValid [] = True
testDeleteValid list@((key,_):_) = T.valid $ T.delete key $ trieFromList list

testLookup :: [(String,Int)] -> Bool
testLookup list = Prelude.foldr (\(key, _) bool -> bool && M.lookup key (mapFromList list) == T.lookup key (trieFromList list)) True list

testDelete :: [(String,Int)] -> Bool
testDelete [] = True
testDelete list@((key,_):_) = isNothing $ T.lookup key $ T.delete key $ trieFromList list

--- Trie helper functies ---
trieFromList :: [(String,a)] -> T.Trie a
trieFromList [] = T.empty
trieFromList ((key, value):xs) = T.insert key value $ trieFromList xs

-- Inserting happens in the same order as trieFromList, M.fromList inserts the other way around
mapFromList :: [(String,a)] -> M.Map String a
mapFromList [] = M.empty
mapFromList ((key, value):xs) = M.insert key value $ mapFromList xs

--- Contract test functies ---
testPos :: Int -> Bool
testPos x = (x <= 0) || (x == C.assert C.pos x) -- first test removes runtime crashes

testTrue :: Int -> Property
testTrue x = x === C.assert C.true x

testAddOne :: Int -> Property
testAddOne x = x + 1 === C.assert (C.DFun C.true (\a -> C.Pred (==a+1))) (+1) x

testListIndex :: [Int] -> Int -> Bool
testListIndex xs x = (x < 0) || (x >= length xs) || xs !! x == C.assert C.listIndex (!!) xs x


-- assert (preserves length) reverse "Hello" => "olleH"
-- assert (preserves length) (take 5) "Hello" => "Hello"
-- assert (preserves length) (take 1) "Hello" => error "contract violation"
testPreservesLengthReverse, testPreservesLengthTake, testPreservesLengthCrash :: Bool
testPreservesLengthReverse = "olleH" == C.assert (C.preserves length) reverse "Hello"
testPreservesLengthTake = "Hello" == C.assert (C.preserves length) (take 5) "Hello"
testPreservesLengthCrash = "H" == C.assert (C.preserves length) (take 1) "Hello"

preservePos :: Int -> Bool
preservePos x = (x <= 0) || C.assert C.preservesPos (+1) x == C.assert C.preservesPos' (+1) x

allPos :: [Int] -> Property
allPos xs = let positives = Prelude.filter (>0) xs in C.assert C.allPos positives === C.assert C.allPos' positives

--- Partially Monad ---
testMerge1, testMerge2 :: Bool
testMerge1 = () == P.unsafeRunPartial (P.merge P.tick P.loop)
testMerge2 = () == P.unsafeRunPartial (P.merge P.loop P.tick)

testRunPartial :: Bool
testRunPartial = let p1 = P.runPartial 200 $ P.firstsum (cycle [repeat 1,[1,2,3],[4,5],[6,7,8],cycle [5,6]])
                     p2 = P.runPartial 200 $ P.firstsum (replicate 100 (repeat 1)++[[1]]++repeat (repeat 1))
                 in  p1 == Just 6 && p2 == Just 1