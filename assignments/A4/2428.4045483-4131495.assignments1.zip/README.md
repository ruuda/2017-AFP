Assignment 4
============

The following solutions have their own module in the `src` directory:

 - 2.10.5 - 2.10.7 Unsafe IO
 - 2.2.4 Tries
 - 2.2.6 Partially monad
 - 2.6.1 Contracts

Not implemented:

 - 2.11.2 Generics
