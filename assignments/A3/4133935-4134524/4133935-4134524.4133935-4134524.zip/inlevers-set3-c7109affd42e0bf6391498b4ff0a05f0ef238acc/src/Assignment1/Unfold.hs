-- |Our solution to Exercise 2.2.2.
module Assignment1.Unfold where

import Prelude hiding (iterate, map) -- Since we want to implement them.
import Data.List (unfoldr)

-- *Unfolding lists

-- |Given 'f' and 'x', generate '[x, f x, f (f x), ...]'.
-- Equivalent to 'Prelude.iterate'.
-- A translation of iterate 'f x = x : iterate f (f x)' into 'unfoldr'.
iterate :: (a -> a) -> a -> [a]
iterate f = unfoldr $ \x -> Just (x, f x)

-- |Apply a function to each element of a list seperately.
-- Equivalent to 'Prelude.map'.
map :: (a -> b) -> [a] -> [b]
map f = unfoldr next
    where
    next  []    = Nothing
    next (x:xs) = Just (f x, xs)

-- *Unfolding trees

-- |The datatype for leaf-labelled binary trees given in the exercise.
data Tree a = Leaf a
            | Node (Tree a) (Tree a)
    deriving (Eq, Show)

-- |The unfold for trees given in the exercise.
unfoldTree :: (s -> Either a (s, s)) -> s -> Tree a
unfoldTree next x = case next x of
    Left y -> Leaf y
    Right (l, r) -> Node (unfoldTree next l) (unfoldTree next r)

-- |Generate a balanced tree of the given depth.
-- Depth should be a natural number.
balanced :: Int -> Tree ()
balanced = unfoldTree next
    where
    next n | n < 0 = error "tree depth must be a natural number"
    next 0 = Left ()
    next n = Right (n - 1, n - 1)

-- |Generate a tree with the given number of nodes and unique labels.
-- Size should be a natural number.
-- In this case, we just use the degenerate case of a linked list.
sized :: Int -> Tree Int
sized size = unfoldTree next (size, 1)
    where
    -- Takes two values: the number of nodes in this tree (>= 0)
    -- and the base label for all values in the tree (>= 1).
    -- Uses binary encoding to represent the path to the leaf.
    -- Since a path uniquely determines a leaf, these labels are unique.
    next :: (Int, Int) -> Either Int ((Int, Int), (Int, Int))
    next (n, _) | n < 0 = error "tree size must be a natural number"
    next (0, l) = Left l
    next (n, l) = let left = (n-1) `div` 2 in -- we already have a node here
        Right ((left, l*2), (n - 1 - left, l*2+1))
