{-# LANGUAGE MultiParamTypeClasses #-}

-- |Our solution to exercise 2.2.8.
module Assignment2.Teletype where

import Control.Monad
import Control.Monad.State

-- |From the exercise:
-- A program that reads and writes integer values before it returns some value.
data GP a = End a -- ^The program ends immediately.
          | Get (Int -> GP a) -- ^The program reads an integer.
          | Put Int (GP a) -- ^The program writes an integer.

-- |From the exercise:
-- A program that continuously reads integers and prints them.
echo :: GP a
echo = Get (\n -> Put n echo)

-- |From the exercise.
instance Functor GP where
  fmap f (End a) = End $ f a
  fmap f (Get g) = Get $ fmap f . g
  fmap f (Put n ma) = Put n $ f `fmap` ma

-- *Task 1
-- |Run a GP program on the command line.
-- Each Get reads a line from stdin and converts it to Int,
-- each Put writes a line to stdout.
-- Throws an error if the read line is not in the right format.
run :: GP a -> IO a
run (End a) = pure a
run (Get f) = getLine >>= (run . f . read)
run (Put n ma) = print n >> run ma

-- *Task 2
-- |A program that reads two integers, writes the sum of the two integers
-- and ultimately returns ().
add, add' :: GP ()
-- |This implementation uses the 'MonadState' instance defined below,
-- because this is a lot easier to read.
add = do
  a <- get
  b <- get
  put $ a + b
-- |This implementation doesn't uses the 'MonadState' instance.
add' = Get $ \a -> Get $ \b -> Put (a + b) $ End ()

-- *Task 3
-- |A program that reads an integer.
-- If the integer is 0, it returns the current total.
-- If the integer is not 0, it adds the integer to the current total,
-- prints the current total, and starts from the beginning.
accum, accum' :: GP Int
-- |This implementation uses the 'MonadState' instance defined below,
-- because this is a lot easier to read.
accum = accumT 0 -- Use an accumulating parameter
  where
  -- Given a subtotal, accumulate.
  accumT total = do
    n <- get
    case n of
      0 -> End total
      n -> do
        let total' = n + total
        Put total' $ accumT total'
-- |This implementation doesn't uses the 'MonadState' instance.
accum' = Get (accumT 0)
  where
  -- Given a subtotal and the last read value, accumulate.
  accumT total 0 = End total
  accumT total n = let total' = n + total in Put total' $ Get $ accumT total'

-- *Task 4
-- |Simulate a program that may run out of input.
-- Useful for testing programs that take an infinite list of input values.
simulate' :: GP a -> [Int] -> (Maybe a, [Int])
simulate' (End a) _ = (Just a, [])
simulate' (Get f)  []    = (Nothing, [])
simulate' (Get f) (n:ns) = simulate' (f n) ns
simulate' (Put n ma) ns = let (a, os) = simulate' ma ns in (a, n:os)

-- |Simulate a program that never runs out of input.
-- If a 'Get' needs to be executed on an empty input list, throws an error.
simulate :: GP a -> [Int] -> (a, [Int])
simulate ma ns = case simulate' ma ns of
  (Just a, os) -> (a, os)
  (Nothing, _) -> error "simulate: insufficient input values"

-- *Task 5
-- |First read in the function, then the argument.
instance Applicative GP where
  pure = End
  (End f) <*> ma = f <$> ma
  (Get mf) <*> ma = Get (\n -> mf n <*> ma)
  (Put n mf) <*> ma = Put n (mf <*> ma)

-- |Read in the argument, then the function.
-- Note that this nicely corresponds with the intuitive usage in 'add' and 'accum'.
instance Monad GP where
  (End a) >>= f = f a
  (Get g) >>= f = Get (g >=> f)
  (Put n ma) >>= f = Put n (ma >>= f)

-- |'Put' and 'Get' map to 'put' and 'get' quite easily.
-- Note that this works differently from 'State',
-- where get after put always gives the value that was put,
-- while the GP instance may return drastically different values.
instance MonadState Int GP where
  put n = Put n (End ())
  get = Get End

