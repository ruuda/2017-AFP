{-# LANGUAGE FlexibleContexts, RankNTypes, PolymorphicComponents #-}
-- |Our solution to exercise 2.5.3.
module Assignment3.EvidenceTranslation where

import Control.Monad.Reader
import System.Random

-- |The number 1.
one :: Int
one = 1

-- |The number 2.
two :: Int
two = 2

-- |Give a random number in the range [-n, n].
randomN :: (RandomGen g) => Int -> g -> Int
randomN n g = (fst (next g) `mod` (two * n + one)) - n

-- |'sizedInt' with the most general type we could come up with.
-- Fun fact: you can use 'a => b => c => ...' instead of '(a,b,c) => ...'
-- due to a bug in the GHC parser. It is not in the Haskell language spec.
-- Of course, we (ab)use this to make it resemble the translated version more.
sizedInt
  :: RandomGen g
  => MonadReader g m
  => MonadReader Int (t m)
  => MonadTrans t
  => t m Int
sizedInt = do
  n <- ask
  g <- lift ask
  pure (randomN n g)

-- |Desugared version of 'sizedInt', using 'Applicative'.
sizedInt_desugared
  :: RandomGen g
  => MonadReader g m
  => MonadReader Int (t m)
  => MonadTrans t
  => t m Int
sizedInt_desugared = randomN <$> ask <*> lift ask

-- |Dictionary version of 'RandomGen' typeclass.
data RandomGen' g = RandomGen'
  { next' :: g -> (Int, g)
  }

-- |Dictionary version of 'MonadReader' typeclass.
data MonadReader' r m = MonadReader'
  { ask' :: m r
  }

-- |Dictionary version of 'MonadTrans' typeclass.
data MonadTrans' t = MonadTrans'
  { lift' :: forall a m. Functor' m -> Applicative' m -> m a -> t m a
  }

-- |Dictionary version of 'Functor' typeclass.
data Functor' f = Functor'
  { map' :: forall a b. (a -> b) -> f a -> f b
  }

-- | Dictionary version of 'Applicative' typeclass.
-- We did not use 'pure' so it was omitted.
data Applicative' f = Applicative'
  { ap' :: forall a b. f (a -> b) -> f a -> f b
  }

-- |Given a 'RandomGen'' dictionary, generate a random integer in the range [-n, n].
-- Dictionary version of 'randomN''.
randomN' :: RandomGen' g -> Int -> g -> Int
randomN' rng n g = (fst (next g) `mod` (two * n + one)) - n
  where
    next = next' rng

-- |Dictionary version of 'sizedInt_desugared'.
sizedInt_ev
  :: RandomGen' g
  -> MonadReader' g m
  -> MonadReader' Int (t m)
  -> MonadTrans' t
  -> Functor' m
  -> Applicative' m
  -> Functor' (t m)
  -> Applicative' (t m)
  -> t m Int
sizedInt_ev randomGen reader1 reader2 trans f1 a1 f2 a2 =
  randomN `map2` ask2 `ap2` lift ask1
  where
    randomN = randomN' randomGen
    map2 = map' f2
    ap2 = ap' a2
    lift = lift' trans f1 a1
    ask1 = ask' reader1
    ask2 = ask' reader2
