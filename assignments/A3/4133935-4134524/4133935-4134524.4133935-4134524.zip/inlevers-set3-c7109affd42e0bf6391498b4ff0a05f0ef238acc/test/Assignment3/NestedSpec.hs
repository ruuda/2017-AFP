module Assignment3.NestedSpec where

import Test.Hspec

import Assignment3.Nested

matrix2PlusOne = Succ $ Succ $ Succ $ Zero $
  (2 `Cons` 3 `Cons` 4 `Cons` Nil) `Cons`
  (5 `Cons` 6 `Cons` 7 `Cons` Nil) `Cons`
  (8 `Cons` 9 `Cons` 10 `Cons` Nil) `Cons`
  Nil

spec :: Spec
spec = do
  describe "eqSquare" $ do
    it "compares the same matrices as equal" $ do
      -- Note that we can't do matrix1 `shouldBe` matrix1,
      -- since we would need a Show instance.
      matrix1 == matrix1 `shouldBe` True
      matrix2 == matrix2 `shouldBe` True
    it "compares different matrices as different" $ do
      matrix1 == matrix2 `shouldBe` False
      matrix2 == matrix1 `shouldBe` False
  describe "fmapSquare" $ do
    it "fmaps (+1) correctly" $ do
      fmap (+1) matrix2 == matrix2PlusOne `shouldBe` True

