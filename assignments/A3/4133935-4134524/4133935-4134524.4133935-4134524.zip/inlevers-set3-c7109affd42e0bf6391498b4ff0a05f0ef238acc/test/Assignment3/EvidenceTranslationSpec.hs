module Assignment3.EvidenceTranslationSpec where

import Control.Category
import Test.Hspec
import Test.Hspec.QuickCheck
import Test.QuickCheck
import System.Random
import Control.Monad.Reader

import Assignment3.EvidenceTranslation

spec :: Spec
spec =
  describe "dictionary passing style" $ do
    -- we instantiate the dictionaries with typeclass implementations
    let randomGen = RandomGen' next :: RandomGen' StdGen
    let reader1 = MonadReader' ask :: MonadReader' StdGen (Reader StdGen)
    let reader2 = MonadReader' ask :: MonadReader' Int (ReaderT Int (Reader StdGen))
    let func1 = Functor' fmap :: Functor' (Reader StdGen)
    let ap1 = Applicative' (<*>) :: Applicative' (Reader StdGen)
    let trans = MonadTrans' (\f a m -> ReaderT (const m)) :: MonadTrans' (ReaderT Int)
    let func2 = Functor' fmap :: Functor' (ReaderT Int (Reader StdGen))
    let ap2 = Applicative' (<*>) :: Applicative' (ReaderT Int (Reader StdGen))

    -- we make sure that the typeclass and the dictionary implementations behave the same
    prop "randomN' == randomN" $ \seed i ->
      let
        stdGen = mkStdGen seed
      in
        i > 0 ==> randomN i stdGen === randomN' randomGen i stdGen

    prop "sizedInt == sizedInt_desugared" $ \seed size ->
      let
        stdGen = mkStdGen seed
      in
        flip runReader stdGen (flip runReaderT size sizedInt)
        ===
        flip runReader stdGen (flip runReaderT size sizedInt_desugared)

    prop "sizedInt_ev == sizedInt_desugared" $ \seed size ->
      let
        stdGen = mkStdGen seed
      in
        flip runReader stdGen (flip runReaderT size $ sizedInt_ev randomGen reader1 reader2 trans func1 ap1 func2 ap2)
        ===
        flip runReader stdGen (flip runReaderT size sizedInt_desugared)
