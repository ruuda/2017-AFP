module Assignment2.FoldableSpec where
import Prelude hiding (Foldable, fold, foldr, foldMap)
import Test.Hspec
import Test.Hspec.QuickCheck
import Test.QuickCheck

import Assignment2.Foldable

spec :: Spec
spec = do
  let
    equalForInts :: ([Int] -> Int) -> ([Int] -> Int) -> [Int] -> Property
    equalForInts a b xs = a xs === b xs

  describe "fproduct" $ do
    it "makes a product" $ do
      30 `shouldBe` fproduct [5,2,3]
    prop "is equivalent to the one haskell provides" $
      equalForInts fproduct product
  describe "fsum" $ do
    it "makes a sum" $ do
      10 `shouldBe` fsum [1,2,3,4]
    prop "is equivalent to the one haskell provides" $
      equalForInts fsum sum
