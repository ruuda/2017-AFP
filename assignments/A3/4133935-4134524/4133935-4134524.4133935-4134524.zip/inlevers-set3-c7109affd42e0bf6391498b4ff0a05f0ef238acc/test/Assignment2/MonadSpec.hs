module Assignment2.MonadSpec where

import Test.Hspec

import Control.Monad.State
import Assignment2.Monad

spec :: Spec
spec = do
  describe "diagnostics" $ do
    it "includes the call to itself" $ do
      flip shouldBe (Right "[diagnostics=1]") $ runStateMonadPlus diagnostics ()
    it "does the first example" $ do
      flip shouldBe (Right "[bind=3, diagnostics=1, return=3]") $ flip runStateMonadPlus () $ do
        pure 3 >> pure 4
        pure 5
        diagnostics
    it "does the second example" $ do
      flip shouldBe (Right "[A=1, bind=3, diagnostics=1, return=3]") $ flip runStateMonadPlus () $ do
        annotate "A" (pure 3 >> pure 4)
        pure 5
        diagnostics
  describe "fail" $ do
    it "doesn't throw an exception but cancels computation" $ do
      flip shouldBe (Left "[1=1, 2=1, bind=2, diagnostics=1, return=1]") $ flip runStateMonadPlus () $ do
        annotate "1" $ pure 37
        message <- annotate "2" diagnostics
        annotate "3" $ fail message
        annotate "4" $ pure "B"

  describe "history" $ do
    it "stores history in the stack" $ do
      flip shouldBe (Right (1, 2, 4, 2, 1)) $ flip runStateMonadPlus 1 $ do
        i1 <- get; saveState
        modify (*2)
        i2 <- get; saveState
        modify (*2)
        i3 <- get; loadState
        i4 <- get; loadState
        i5 <- get
        return (i1, i2, i3, i4, i5)
    it "nicely handles missing states" $ do
      flip shouldBe (Left "loadState: no state saved") $ flip runStateMonadPlus 1 $ do
        i1 <- get
        modify (*2)
        i2 <- get
        modify (*2)
        i3 <- get
        i3 <- get; loadState
        i4 <- get; loadState
        i5 <- get
        return (i1, i2, i3, i4, i5)

