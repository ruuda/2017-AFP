type Square a     = Square' Nil a
data Square' t a  = Zero (t (t a)) | Succ (Square' (Cons t) a)
data Nil a        = Nil
data Cons t a     = Cons a (t a)

firstMatrix :: Num a => Square a
firstMatrix = Succ $ Succ $ Zero
  $ Cons (Cons 1 (Cons 0 Nil))
  $ Cons (Cons 0 (Cons 1 Nil))
  Nil

secondMatrix :: Num a => Square a
secondMatrix = Succ $ Succ $ Succ $ Zero
  $ Cons (Cons 1 (Cons 2 (Cons 3 Nil)))
  $ Cons (Cons 4 (Cons 5 (Cons 6 Nil)))
  $ Cons (Cons 5 (Cons 6 (Cons 7 Nil)))
  Nil