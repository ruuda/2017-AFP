{- Exercise 2.5.3 - Evidence translation
   for the first part, see evidence-translation-type.hs -}

{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE RankNTypes #-}

import Prelude hiding (return, Monad) -- Allows us to define our own Monad

data Monad m = Monad {
    return :: forall a. a -> m a, -- forall is required by the compiler
    bind   :: forall a b. m a -> (a -> m b) -> m b
}

data RandomGen g = RandomGen {
    next :: g -> (Int, g)
}

data MonadTrans t = MonadTrans {
    lift :: forall m a. Monad m -> m a -> t m a
}

data MonadReader r m = MonadReader {
    ask :: m r
}

one :: Int
one = 1

two :: Int
two = 2

randomN :: RandomGen g -> Int -> g -> Int
randomN randomGen n g = (fst (next randomGen g) `mod` (two * n + one)) - n

sizedInt :: Monad m -> Monad (t m) -> RandomGen g -> MonadTrans t -> MonadReader Int (t m) -> MonadReader g m -> t m Int
sizedInt monadM monadTM randomGenG monadTransT monadReaderIntTM monadReaderRandGM =
    bind monadTM (ask monadReaderIntTM) (
        \n -> bind monadTM (lift monadTransT monadM (ask monadReaderRandGM)) (
            \g -> return monadTM (randomN randomGenG n g)))