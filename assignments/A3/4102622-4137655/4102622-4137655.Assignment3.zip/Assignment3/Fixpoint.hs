data F a = F {unF :: F a -> a}

y :: (a -> a) -> a
y f = (\x -> f (unF x x)) (F (\x -> f (unF x x)))
