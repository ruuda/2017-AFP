{- Exercise 2.5.3 - Most general type of sizedInt
   for the second part, see evidence-translation.hs -}

{-# LANGUAGE FlexibleContexts #-}

import Control.Monad.Reader
import System.Random

one :: Int
one = 1

two :: Int
two = 2

randomN :: (RandomGen g) => Int -> g -> Int
randomN n g = (fst (next g) `mod` (two * n + one)) - n


-- The most general type of sizedInt:
sizedInt :: (RandomGen g, MonadTrans t, MonadReader Int (t m), MonadReader g m) => t m Int
-- To compile, this definition requires the FlexibleContexts extension.
-- Explanation (which will refer to the variables as defined in the implementation of sizedInt):
--   First, sizedInt will return a monad of a wrapped Int, because randomN returns an Int.
--   By the definition of randomN, n has type Int, and g has as type an instance of RandomGen.
--   The type of lift is lift :: Monad m => m a -> t m a, where t is a MonadTrans.
--   So actually the returned monad is made up from a MonadTrans applied to a monad.
--   These are named t and m in our definition.
--   `ask` is a method of the MonadReader class. It's definition is:
--       class Monad n => MonadReader r n | n -> r
--         ask :: n r
--   So in the statement `n <- ask`, we see that n must equal `t m`, and r must be Int.
--   Therefore we require `MonadReader Int (t m)`. In the statement `g <- lift ask`, we have that
--   `ask` has type `ask :: m a` where `a` must be an instance of RandomGen because of g. This
--   adds the requirement `MonadReader x m` where `x` is a RandomGen.

sizedInt = do
    n <- ask
    g <- lift ask
    return (randomN n g)