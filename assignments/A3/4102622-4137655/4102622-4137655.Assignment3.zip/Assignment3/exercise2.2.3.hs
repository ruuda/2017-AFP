fix :: (a -> a) -> a
fix f = f (fix f)

foldr :: (a -> b -> b) -> b -> [a] -> b
foldr f z = fix g
    where g h [] = z
          g h (x:xs) = x `f` h xs

