data Tree a = Leaf a | Node (Tree a) (Tree a) deriving Show

-- Helper function taking an extra function f to build the tree.
splitleft' :: (Maybe (Tree a) -> Maybe (Tree a)) -> Tree a -> (a, Maybe (Tree a))
splitleft' f (Leaf a) = (a, f Nothing)
splitleft' f (Node l r) = splitleft' g l
    where g (Just n) = f (Just (Node n r))
          g Nothing  = f (Just r)

splitleft :: Tree a -> (a, Maybe (Tree a))
splitleft = splitleft' id
