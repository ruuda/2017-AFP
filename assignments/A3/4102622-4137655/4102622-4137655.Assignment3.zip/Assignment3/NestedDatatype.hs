{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE FlexibleInstances #-}

type Square         = Square' Nil
data Square' t a    = Zero (t (t a)) | Succ (Square' (Cons t) a)
data Nil a          = Nil
data Cons t a       = Cons a (t a)

eqNil :: (a -> a -> Bool) -> (Nil a -> Nil a -> Bool)
eqNil eqA Nil Nil = True

eqCons :: (forall b . (b -> b -> Bool) -> (t b -> t b -> Bool)) -> (a -> a -> Bool) -> (Cons t a -> Cons t a -> Bool)
eqCons eqT eqA (Cons x xs) (Cons y ys) = eqA x y && eqT eqA xs ys

{-  Answer to Task 1:
    The difference between the type signature with and without `forall` is that the first requires a function which 
    is polymorphic _itself_, while the latter makes the _function which the signature describes_ polymorphic.
    
    It is possible to create a type signature without `forall` that type checks, by replacing all `b`'s with `a`'s:
    eqCons :: ((a -> a -> Bool) -> (t a -> t a -> Bool)) -> (a -> a -> Bool) -> (Cons t a -> Cons t a -> Bool)

    This is however not the same, since it puts additional constraints on the first term. The `eqT` parameter would
    have to have the same type for its function as eqA, while in reality we want to have it more broadly defined.
-}

eqSquare' :: (forall b . (b -> b -> Bool) -> (t b -> t b -> Bool)) -> (a -> a -> Bool) -> (Square' t a -> Square' t a -> Bool)
eqSquare' eqT eqA (Zero xs) (Zero ys)   = eqT (eqT eqA) xs ys
eqSquare' eqT eqA (Succ xs) (Succ ys)   = eqSquare' (eqCons eqT) eqA xs ys
eqSquare' eqT eqA _         _           = False

{- Answer to Task 2:
    Now it is not longer possible to exchange b's for a's. The reason for this is the nesting of eqT in 
    the definition for the Zero constructor. The compiler expects a function of type 
    (a -> a -> Bool), while the application of eqT to eqA produces:

        -   eqA             ::    (a -> a -> Bool)
        -   eqT             ::    (b -> b -> Bool) -> (t b -> t b -> Bool)
        -   eqT eqA         ::    (t a -> t a -> Bool) 

    This means that eqT has to work for both (b -> b -> Bool) and (t b -> t b -> Bool). Functions that are provided
    as a parameter can however not be polymorphic - unless explicitly stated using the `forall` predicate and the
    RankNTypes language pragma. Note that this is very similar to using generic objects as arguments in OO-languages. 
-}

eqSquare :: (a -> a -> Bool) -> Square a -> Square a -> Bool
eqSquare = eqSquare' eqNil


-- NB: The TypeSynonymInstances pragma is no longer required, however the FlexibleInstances is.
instance Eq a => Eq (Square a) where
    (==) = eqSquare (==)

-- Task 3:

mapNil :: (a -> b) -> (Nil a -> Nil b)
mapNil _ Nil = Nil


mapCons :: (forall a b . (a -> b) -> (t a -> t b)) -> (c -> d) -> (Cons t c -> Cons t d)
mapCons mapT f (Cons x xs) = Cons (f x) (mapT f xs)

mapSquare' :: (forall a b . (a -> b) -> (t a -> t b)) -> (c -> d) -> (Square' t c -> Square' t d)
mapSquare' mapT f (Zero xs) = Zero $ mapT (mapT f) xs
mapSquare' mapT f (Succ xs) = Succ $ mapSquare' (mapCons mapT) f xs

mapSquare :: (a -> b) -> Square a -> Square b
mapSquare = mapSquare' mapNil

instance Functor Square where
    fmap = mapSquare