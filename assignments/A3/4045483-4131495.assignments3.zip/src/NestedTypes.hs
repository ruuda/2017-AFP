{-# LANGUAGE FlexibleInstances, RankNTypes, TypeSynonymInstances #-}

module NestedTypes where

-- 2.4.1
data F a = F { unF :: F a -> a }
-- y = \f -> (\x -> f (x x)) (\x -> f (x x))
y = \f -> (\x -> x $ F x) (\x -> f . unF x $ x)


-- 2.4.2
type Square       = Square' Nil
data Square' t a  = Zero (t (t a)) | Succ (Square' (Cons t) a)
data Nil a        = Nil
data Cons t a     = Cons a (t a)

identity, other :: Square Int
identity = Succ $ Succ (Zero (Cons (Cons 1 (Cons 0 Nil))
                             (Cons (Cons 0 (Cons 1 Nil)) Nil)))
other = Succ $ Succ $ Succ (Zero (Cons (Cons 1 (Cons 2 (Cons 3 Nil)))
                                 (Cons (Cons 4 (Cons 5 (Cons 6 Nil)))
                                 (Cons (Cons 7 (Cons 8 (Cons 9 Nil))) Nil))))

-- 2.4.3

eqNil :: (a -> a -> Bool) -> (Nil a -> Nil a -> Bool)
eqNil eqA Nil Nil = True

eqCons :: (forall b. (b -> b -> Bool) -> (t b -> t b -> Bool)) ->
          (a -> a -> Bool) ->
          (Cons t a -> Cons t a -> Bool)
eqCons eqT eqA (Cons x xs) (Cons y ys) = eqA x y&&eqT eqA xs ys

{-

Q: Can you omit the ∀ in the case of eqCons and does the function still work?
A: If we remove the ∀ the program will no longer compile. However, if we remove the type
   signature alltogether Haskell itself will infer a suitable type for the function:

   eqCons :: ((t3 -> t2 -> Bool) -> t1 t3 -> t t2 -> Bool)
          -> (t3 -> t2 -> Bool) -> Cons t1 t3 -> Cons t t2 -> Bool

   The type inferred by Haskell is unfortunately too restrictive. As you can see, the boolean
   function takes two parameters of different types, while that is not the case in the version
   that uses forall.

-}

eqSquare' :: (forall b. (b -> b -> Bool) -> (t b -> t b -> Bool)) ->
             (a -> a -> Bool) ->
             (Square' t a -> Square' t a->Bool)
eqSquare' eqT eqA (Zero xs) (Zero ys) = eqT (eqT eqA) xs ys
eqSquare' eqT eqA (Succ xs) (Succ ys) = eqSquare' (eqCons eqT) eqA xs ys
eqSquare' eqT eqA _ _ = False

{-

Q: Again, try removing the ∀ from the type of eqSquare’. Does the function still typecheck?
A: If we remove the ∀, the function no longer typechecks. This happens because the 'eqT' function
   is applied on different types. Haskell gets confused because it tries to come up with a single
   type 'b' for the '(b -> b -> Bool) -> (t b -> t b -> Bool))' part of the signature. In reality,
   there are multiple possible types 'b' that fit the type signature, hence the use of ∀.

-}

eqSquare :: (a -> a -> Bool) -> Square a -> Square a -> Bool
eqSquare = eqSquare' eqNil

instance Eq a => Eq (Square a) where
    (==) = eqSquare (==)

{- Functor instance -}

instance Functor Square where
    fmap = mapSquare' mapNil

mapNil :: (a -> b) -> Nil a -> Nil b
mapNil f Nil = Nil

mapCons :: ((a -> b) -> (t a -> t b)) ->
           (a -> b) ->
           Cons t a -> Cons t b
mapCons lift f (Cons x xs) = Cons (f x) (lift f xs)

mapSquare' :: (forall a b. (a -> b) -> (t a -> t b)) ->
              (a -> b) ->
              Square' t a -> Square' t b
mapSquare' lift f (Zero xs) = Zero $ lift (lift f) xs
mapSquare' lift f (Succ xs) = Succ $ mapSquare' (mapCons lift) f xs

{- A simple property to check that fmap works. You can check it using GHCI -}

matrixFmapWorks :: Bool
matrixFmapWorks = identityPlusOne == fmap (+1) identity
    where identityPlusOne = Succ $ Succ (Zero (Cons (Cons 2 (Cons 1 Nil))
                                              (Cons (Cons 1 (Cons 2 Nil)) Nil)))
