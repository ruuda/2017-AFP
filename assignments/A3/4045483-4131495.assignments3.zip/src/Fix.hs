module Fix (myFoldr) where

import Data.Function

myFoldr :: (a -> b -> b) -> b -> [a] -> b
myFoldr f acc xs = snd $ fix step (xs, acc)
    where step _ ([], acc') = ([], acc')
          step rec (y : ys, acc') = rec (ys, f y acc')
