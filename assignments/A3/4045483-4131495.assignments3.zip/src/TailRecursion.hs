module TailRecursion (
    Tree(..),
    splitleft
) where

data Tree a = Leaf a | Node (Tree a) (Tree a) deriving (Eq, Show)

-- This function does two things:
-- * Get the leftmost leaf of the tree
-- * Return a new tree with the leftmost leaf removed (note: removal = replace last node by a Tree r)
splitleft :: Tree a -> (a, Maybe (Tree a))
splitleft (Leaf a)     = (a, Nothing)
splitleft (Node l r)   = splitleft' (treecreate r) l
    where
    treecreate right (Nothing)      = Just right
    treecreate right (Just left)    = Just $ Node left right
    splitleft' create (Leaf a)     = (a, create Nothing)
    splitleft' create (Node l r)   = splitleft' (create . treecreate r) l
