{-# LANGUAGE FlexibleContexts #-}
{-# LANGUAGE AllowAmbiguousTypes #-}
{-# LANGUAGE PolymorphicComponents #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-} -- http://stackoverflow.com/questions/6928884/type-signature-in-a-where-clause -> https://downloads.haskell.org/~ghc/7.0-latest/docs/html/users_guide/other-type-extensions.html#scoped-type-variables

module EvidenceTranslation where
import Control.Monad.Reader
import System.Random

one :: Int
one = 1

two :: Int
two = 2

randomN :: (RandomGen g) => Int -> g -> Int
randomN n g = (fst (next g) `mod` (two * n + one)) - n

-- > stack build --ghc-options -fprint-potential-instances
-- Ambiguous type variables `t0', `m0' arising from a do statement prevents the constraint `(Monad (t0 m0))' from being solved.
--     instance [safe] (Monad m, Control.Monad.Trans.* t) => Monad (Control.Monad.Trans.* t m)
-- Ambiguous type variables `t0', `m0' arising from a use of `ask' prevents the constraint `(MonadReader Int (t0 m0))' from being solved.
-- Ambiguous type variable `g0' arising from a use of `randomN' prevents the constraint `(RandomGen g0)' from being solved.
-- > stack build
-- Could not deduce (MonadReader g0 m) arising from a use of `ask' from the context: (Monad m, MonadTrans t, MonadReader Int (t m), RandomGen g)
sizedInt :: (Monad m, MonadTrans t, MonadReader Int (t m), RandomGen g, MonadReader g m) => t m Int
sizedInt = do
    n <- ask
    g <- lift ask
    return (randomN n g)

-- desugared functions
dsRandomN :: (RandomGen g) => Int -> g -> Int
dsRandomN n g = mod (fst (next g)) (two * n + one) - n
dsSizedInt :: (Monad m, MonadTrans t, MonadReader Int (t m), RandomGen g, MonadReader g m) => t m Int
dsSizedInt = (>>=) ask (\n -> (>>=) (lift ask) (return . dsRandomN n) )

-- record types (rt)
-- class Monad m where
--     (>>=) :: m a -> (a -> m b) -> m b
--     return :: a -> m a
data RTMonad m = RTMonad {
    rtcompose :: forall a b . m a -> (a -> m b) -> m b,
    rtreturn :: forall a . a -> m a
}
-- class MonadTrans t where
--     lift :: Monad m => m a -> t m a
data RTMonadTrans t = RTMonadTrans {
    rtlift :: forall m a . RTMonad m -> m a -> t m a
}
-- class MonadReader Int (t m) where
--     ask :: (t m) Int
-- class MonadReader g m where
--     ask :: m g
data RTMonadReader r m = RTMonadReader {
    rtask :: m r,
    rtmonad :: RTMonad m
}
-- class RandomGen g where
--     next :: g -> (Int, g)
data RTRandomGen g = RTRandomGen {
    rtnext :: g -> (Int, g)
}

-- translation (tr)
tmonad :: Monad m => RTMonad m
tmonad = RTMonad (>>=) return
tmonadtrans :: MonadTrans r => RTMonadTrans r
tmonadtrans = undefined
--tmonadtrans = RTMonadTrans lift
tmonadreader :: MonadReader t m => RTMonad m -> RTMonadReader t m
tmonadreader = RTMonadReader ask

tRandomN :: RTRandomGen g -> Int -> g -> Int
tRandomN rndgen n g = mod (fst (nextrnd g)) (two * n + one) - n
    where   nextrnd = rtnext rndgen

tSizedInt :: RTMonad m -> RTMonadTrans t -> RTMonadReader Int (t m) -> RTRandomGen g -> RTMonadReader g m -> t m Int
tSizedInt rtMonad rtMonadTrans rtMonadReaderInt rtRandomGen rtMonadReaderRand
    = monadCompose askInt (\n -> monadCompose liftAskRand (returnReadInt . generateRandInt n))
  where
    monadCompose = rtcompose (rtmonad rtMonadReaderInt)
    askInt = rtask rtMonadReaderInt
    liftAskRand = rtlift rtMonadTrans (rtmonad rtMonadReaderRand) (rtask rtMonadReaderRand)
    generateRandInt = tRandomN rtRandomGen
    returnReadInt = rtreturn (rtmonad rtMonadReaderInt)
