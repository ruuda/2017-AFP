import Test.QuickCheck
import EvidenceTranslation
import Fix
import NestedTypes
import TailRecursion

main :: IO ()
main = do
    quickCheck myFoldrWorks
    quickCheck splitleftWorks

myFoldrWorks :: Bool
myFoldrWorks = 15 == myFoldr (+) 0 [1..5]

splitleftWorks :: [Int] -> Property
splitleftWorks elems = let len = length elems
                           tree = createTree elems
                       in not (null elems) && even len ==> (splitleft tree === splitleftSpec tree)

{- QuickCheck boilerplate to check that splitleft works properly -}

splitleftSpec :: Tree a -> (a, Maybe (Tree a))
splitleftSpec (Leaf a) = (a, Nothing)
splitleftSpec (Node l r) = case splitleft l of
                              (a, Nothing) -> (a, Just r)
                              (a, Just l') -> (a, Just (Node l' r))

createTree :: [a] -> Tree a
createTree [] = error "createTree without elements"
createTree [x] = Leaf x
createTree elements = let len = length elements
                          (xs, ys) = splitAt (len `div` 2) elements
                       in Node (createTree xs) (createTree ys)
