Assignment 3
============

The following solutions have their own module in the `src` directory:

 - 2.2.1 Tail recursion
 - 2.2.3 Fix
 - 2.4.1 - 2.4.3 Nested types
 - 2.5.3 Evidence translation

Note: there is a compiler bug when compiling NestedTypes.hs, but the code
does run perfectly on GHCi.
