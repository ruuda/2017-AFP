module Assignment3 where
import Control.Monad.Fix

-- Exercise 2.2.1 - Defining a Tail Recursive splileft
data Tree a = Leaf a | Node (Tree a) (Tree a) deriving (Show)

spliffins :: Tree a -> (a, Maybe (Tree a))
--idea is to build the tree off this list, then we gonna fold it
spliffins = run []
  where
    -- base case , list does not matter, find a leaf, push value.
    run _ (Leaf a) = (a, Nothing)
    -- this is where the mindfuck happens
    -- when we pattern match something with a leaf on the left side, means we
    -- reached the leftmost value
    run t (Node (Leaf a) r) = (a, Just(foldl go r t))
    -- 
      where go l (Node _ r) = (Node l r)

    -- visit left branch, we dont need the right branch, so
    -- cons the tree to the list, reversed so thats why foldl
    run t (Node l r) = run ((Node l r):t) l
    

-- Exercise 2.2.3 - Fix
foldr' = fix (\rec f acc l -> if null l then acc else (head l) `f` rec f acc (tail l)) (+) 0 [1,2]

-- Exercise 2.4.1 - Defining the Y combinator
-- Using a recursive type F
--
data F a = F {unF :: F a -> a}

y = \f -> (\x -> f ((unF x) x)) (F (\x -> f ((unF x) x)))


