# Assignment 3 - Jasper Robeer (3802337)

The `src/Assignment3` directory contains the Haskell code files for the assignments:

 * Exercise 2.2.1 (Tail Recursion): `TailRecursion.hs`
 * Exercise 2.2.3 (Fix): `Fix.hs`
 * Exercise 2.4.1-2.4.3 (Nested Types): `NestedTypes.hs`
 * Exercise 2.5.3 (Evidence Traits): `EvidenceTraits.hs`

The `test/Assignment3` directory contains unit tests and QuickCheck tests for
the exercises. The unit tests use [Hspec](http://hspec.github.io/). The files
containing the tests are named in line with the original code files.

Unfortunately, due to time constraints I was not able to finish all set
assignments. The Tail Recursion and Fix assignment are completed. The NestedTypes
assignment not fully.

## Running the assignments

The assignments are built using [Stack](https://www.haskellstack.org/). Run the
following commands to setup, build and test the assignments.

```
$ stack setup
$ stack build
$ stack test
```
