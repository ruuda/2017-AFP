{-# LANGUAGE RankNTypes, TypeSynonymInstances, FlexibleInstances #-}

module Assignment3.NestedTypes where

{-- Exercise 2.4.1 --}

-- The Y combinator as given in the exericise
-- y = \f -> (\x -> f (x x)) (\x -> f (x x))

data F a = F { unF :: F a -> a }

-- | The Y combinator, which by beta reduction (according to Wikipedia):
--   Y g = g (Y g).
--   Unfortunately, when GHC tries to inline the function it gets stuck in an
--   'infinite' inlining loop and returns on my machine:
--      ghc: panic! (the 'impossible' happened)
--          (GHC version 8.0.2 for x86_64-unknown-linux):
--              Simplifier ticks exhausted
y f = g (F g)
    where g x = f (unF x x)

{-- Exercise 2.4.2 --}

-- Square :: * -> *
type Square = Square' Nil

-- Zero :: t (t a) -> Square' t a
-- Succ :: Square' (Cons t) a -> Square' t a
data Square' t a = Zero (t (t a))
                 | Succ (Square' (Cons t) a)

-- Nil :: Nil a
data Nil    a = Nil deriving Show
-- Cons :: a -> t a -> Cons t a
data Cons t a = Cons a (t a) deriving Show

-- | Make the `Cons` constructor work like the list cons `:` constructor.
--   See: https://www.haskell.org/onlinereport/decls.html#fixity
infixr 5 `Cons`

-- | The matrices are represented in row-major order. Thus, when representing
--   the small 2x2 matrix we could write it as [[1,0],[0,1]].
matrix1 :: Square Int
matrix1 = Succ (Succ (Zero (
    (1 `Cons` 0 `Cons` Nil) `Cons`      -- [1,0]
    (0 `Cons` 1 `Cons` Nil) `Cons` Nil  -- [0,1]
    )))

matrix2 :: Square Int
matrix2 = Succ (Succ (Succ (Zero (
    (1 `Cons` 2 `Cons` 3 `Cons` Nil) `Cons`     -- [1,2,3]
    (4 `Cons` 5 `Cons` 6 `Cons` Nil) `Cons`     -- [4,5,6]
    (7 `Cons` 8 `Cons` 9 `Cons` Nil) `Cons` Nil -- [7,8,9]
    ))))

{-- Exercise 2.4.3 --}

eqNil :: (a -> a -> Bool) -> (Nil a -> Nil a -> Bool)
eqNil eqA Nil Nil = True

eqCons :: (forall b. (b -> b -> Bool) -> (t b -> t b -> Bool)) ->
          (a -> a -> Bool) ->
          (Cons t a -> Cons t a -> Bool)
eqCons eqT eqA (Cons x xs) (Cons y ys) = eqA x y && eqT eqA xs ys

eqSquare':: (forall b. (b -> b -> Bool) -> (t b -> t b -> Bool)) ->
            (a -> a -> Bool) ->
            (Square' t a -> Square' t a -> Bool)
eqSquare' eqT eqA (Zero xs) (Zero ys) = eqT (eqT eqA) xs ys
eqSquare' eqT eqA (Succ xs) (Succ ys) = eqSquare' (eqCons eqT) eqA xs ys
eqSquare' eqT eqA _         _         = False

eqSquare :: (a -> a -> Bool) -> Square a -> Square a -> Bool
eqSquare = eqSquare' eqNil

instance Eq a => Eq (Square a) where
    (==) = eqSquare (==)
