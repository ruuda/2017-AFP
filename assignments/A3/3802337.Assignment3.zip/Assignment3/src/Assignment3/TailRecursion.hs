module Assignment3.TailRecursion where

{-- Exercise 2.2.1 --}

data Tree a = Leaf a
            | Node (Tree a) (Tree a)
            deriving (Show, Eq)

-- | Splits off the left-most entry of the tree and returns that entry as well
--   as the remaining tree.
--   
--   To implement the tail recursion, we introduce an auxiliary parameter which
--   acts as an accumulator. We distinguish two cases:
--     1. If the tree is only `Leaf a` we can return immediately;
--     2. If the tree is a `Node l r` we have two sub-cases:
--          a. If the left node is a `Leaf`, then we are at the left-most entry
--             of the tree. We can take the auxiliary parameter and fold it
--             'back' into a tree.
--          b. Otherwise, we add the complete node to the front of the auxiliary
--             list, and recurse in the left-hand side of the tree.
--   The list which we gradually build contains all the right-hand sides of the
--   tree through which we recurse. However, we need to keep the whole nodes,
--   as the right-hand side could include the root.
splitLeft :: Tree a -> (a, Maybe (Tree a))
splitLeft = go [] 
    where 
        -- Case: Leaf a
        go _  (Leaf a)          = (a, Nothing)
        
        -- Case: Node l r
        go xs (Node (Leaf a) r) = (a, Just (foldl f r xs))
        go xs node@(Node l _)   = go (node:xs) l
        
        -- When folding we only take the right-hand sides of the nodes
        f l (Node _ r)          = Node l r
