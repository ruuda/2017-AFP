module Assignment3.Fix where

import Prelude hiding (foldr)

{-- Exercise 2.2.3 --}

-- | Fixpoint combinator which 'computes' the fixpoint of other functions. Taken
--   from the assignment.
fix :: (a -> a) -> a
fix f = f (fix f)

-- From the slides:
--
--  fac :: Int -> Int
--  fac 0 = 1
--  fac n = n * fac (n-1)
--
-- Fixpoint implementation from the slides:
--
--  fac :: Int -> Int
--  fac = fix fac'
--      where fac' f 0 = 1
--            fac' f n = n * f (n-1)
--
-- From wiki.haskell.org/Fold:
-- 
--  foldr f z []     = z 
--  foldr f z (x:xs) = f x (foldr f z xs)
--
-- We can see that the `foldr` implementation above can be likewise transformed
-- as with the factorial example from the slides.

foldr :: (a -> b -> b) -> b -> [a] -> b
foldr = fix go
    where
        go _ g z []     = z
        go f g z (x:xs) = g x (f g z xs)
