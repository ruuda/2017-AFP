module Assignment3.TailRecursionSpec where

import Test.Hspec
import Test.QuickCheck
import Assignment3.TailRecursion

-- | Reference implementation from the assignment.
refSplitLeft :: Tree a -> (a, Maybe (Tree a))
refSplitLeft (Leaf a)   = (a, Nothing)
refSplitLeft (Node l r) =
    case refSplitLeft l of
        (a, Nothing) -> (a, Just r)
        (a, Just l') -> (a, Just (Node l' r))

-- | Utility function to generate trees of size n.
constructTree :: Int -> Tree Int
constructTree n
    | n <= 0    = error "cannot build a tree with less than a single leaf"
    | otherwise = f [0..n-1]
    where f [x] = Leaf x
          f xs  = let (l, r) = splitAt (length xs `div` 2) xs
                  in Node (f l) (f r)

-- | Generates positive integers only
genP :: Gen Int
genP = (arbitrary :: Gen Int) `suchThat` (>0)

spec :: Spec
spec = do
    it "output is the same as the reference implementation" $ property $
        forAll genP $ \xs ->
            let t = constructTree xs
            in refSplitLeft t == splitLeft t
