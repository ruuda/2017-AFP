module Assignment3.FixSpec where

import Test.Hspec
import Test.QuickCheck
import qualified Assignment3.Fix as Fix


spec :: Spec
spec = do
    it "foldr (+) 0 == Fix.foldr (+) 0" $ property $
        \xs -> foldr (+) (0 :: Int) xs == Fix.foldr (+) 0 xs
    
    it "foldr (*) 1 == Fix.foldr (*) 1" $ property $
        \xs -> foldr (*) (1 :: Int) xs == Fix.foldr (*) 1 xs
